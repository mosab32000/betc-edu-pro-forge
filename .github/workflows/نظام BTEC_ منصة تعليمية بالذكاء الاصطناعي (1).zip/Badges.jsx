import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  HomeIcon,
  ArrowLeftIcon,
  CheckCircleIcon,
  LockIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';

const Badges = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [userPoints, setUserPoints] = useState(0);
  const [userLevel, setUserLevel] = useState(0);
  const [levelProgress, setLevelProgress] = useState(0);
  const [badges, setBadges] = useState([]);

  useEffect(() => {
    // محاكاة تحميل البيانات
    const loadData = async () => {
      setIsLoading(true);
      try {
        // محاكاة تأخير الشبكة
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // بيانات وهمية للعرض
        setUserPoints(230);
        setUserLevel(4);
        setLevelProgress(65);
        
        setBadges([
          {
            id: 1,
            name: 'بترا',
            description: 'أكملت 5 مهام بنجاح',
            image: '/src/assets/images/eduverse_btec_badges_screen.png',
            progress: 100,
            earned: true,
            category: 'إنجاز'
          },
          {
            id: 2,
            name: 'تاج',
            description: 'حصلت على تقييم ممتاز في 3 مهام متتالية',
            image: '/src/assets/images/eduverse_btec_badges_screen.png',
            progress: 80,
            earned: true,
            category: 'تميز'
          },
          {
            id: 3,
            name: 'النجم الثلاثي',
            description: 'أكملت جميع المهام في وحدة دراسية',
            image: '/src/assets/images/eduverse_btec_badges_screen.png',
            progress: 100,
            earned: true,
            category: 'إكمال'
          },
          {
            id: 4,
            name: 'جرش',
            description: 'شاركت في 10 مناقشات',
            image: '/src/assets/images/eduverse_btec_badges_screen.png',
            progress: 40,
            earned: false,
            category: 'مشاركة'
          },
          {
            id: 5,
            name: 'عجلون',
            description: 'أكملت 3 تجارب تعلم غامرة',
            image: '/src/assets/images/eduverse_btec_badges_screen.png',
            progress: 30,
            earned: false,
            category: 'استكشاف'
          },
          {
            id: 6,
            name: 'النجم الذهبي',
            description: 'حصلت على الدرجة الكاملة في تقييم',
            image: '/src/assets/images/eduverse_btec_badges_screen.png',
            progress: 0,
            earned: false,
            category: 'تميز'
          }
        ]);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadData();
  }, []);

  // تأثيرات الحركة للبطاقات
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100
      }
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* شريط التنقل العلوي */}
      <header className="bg-primary text-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <Link to="/" className="ml-2">
              <Button variant="ghost" size="icon" className="text-white hover:bg-primary-foreground/10">
                <ArrowLeftIcon className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-bold">الأوسمة والإنجازات</h1>
          </div>
          
          <Link to="/">
            <Button variant="ghost" size="icon" className="text-white hover:bg-primary-foreground/10">
              <HomeIcon className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
              <p className="mt-4 text-muted-foreground">جاري تحميل الإنجازات...</p>
            </div>
          </div>
        ) : (
          <>
            {/* ملخص النقاط والمستوى */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="bg-primary text-white rounded-lg p-6 mb-8 shadow-md"
            >
              <div className="flex flex-col md:flex-row items-center justify-between">
                <div className="flex items-center mb-4 md:mb-0">
                  <div className="bg-accent text-accent-foreground rounded-full h-16 w-16 flex items-center justify-center text-2xl font-bold">
                    {userPoints}
                  </div>
                  <div className="mr-4 text-center md:text-right">
                    <h3 className="text-lg font-bold">مجموع النقاط</h3>
                  </div>
                </div>
                
                <div className="flex flex-col items-center md:items-end">
                  <h3 className="text-lg font-bold mb-2">المستوى {userLevel}</h3>
                  <div className="w-full max-w-xs">
                    <Progress value={levelProgress} className="h-2 bg-white/20" indicatorClassName="bg-accent" />
                  </div>
                  <p className="text-xs mt-1">{levelProgress}% إلى المستوى التالي</p>
                </div>
              </div>
            </motion.div>
            
            {/* الأوسمة */}
            <h3 className="text-xl font-bold text-primary mb-4">الأوسمة</h3>
            
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="grid grid-cols-2 md:grid-cols-3 gap-4"
            >
              {badges.map((badge) => (
                <motion.div
                  key={badge.id}
                  variants={itemVariants}
                  whileHover={{ scale: 1.03 }}
                  className={`bg-white rounded-lg shadow-md overflow-hidden transition-all hover:shadow-lg p-4 flex flex-col items-center text-center ${!badge.earned && 'opacity-70'}`}
                >
                  <div className="relative mb-2">
                    <div className={`w-20 h-20 rounded-full overflow-hidden border-4 ${badge.earned ? 'border-accent' : 'border-muted'}`}>
                      {badge.earned ? (
                        <img 
                          src="/src/assets/images/eduverse_btec_badges_screen.png" 
                          alt={badge.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full bg-muted flex items-center justify-center">
                          <LockIcon className="h-8 w-8 text-muted-foreground" />
                        </div>
                      )}
                    </div>
                    
                    {badge.earned && (
                      <div className="absolute -bottom-1 -left-1 bg-accent rounded-full p-1">
                        <CheckCircleIcon className="h-4 w-4 text-white" />
                      </div>
                    )}
                  </div>
                  
                  <h4 className="font-bold text-primary">{badge.name}</h4>
                  <p className="text-xs text-muted-foreground mt-1 mb-2">{badge.description}</p>
                  
                  <Progress 
                    value={badge.progress} 
                    className="h-1.5 w-full bg-muted" 
                    indicatorClassName={badge.earned ? 'bg-accent' : 'bg-muted-foreground'} 
                  />
                  <p className="text-xs mt-1">{badge.progress}%</p>
                </motion.div>
              ))}
            </motion.div>
            
            {/* التحقق من البلوكتشين */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.5 }}
              className="mt-8 bg-white rounded-lg p-4 shadow-sm border border-border flex items-center justify-center"
            >
              <CheckCircleIcon className="h-5 w-5 text-secondary ml-2" />
              <p className="text-sm">تم التحقق عبر تقنية البلوكتشين</p>
            </motion.div>
          </>
        )}
      </main>

      <footer className="bg-primary/80 text-white p-4 text-center">
        <p className="text-sm">© 2025 EduverseAI - قلعة BTEC. جميع الحقوق محفوظة.</p>
      </footer>
    </div>
  );
};

export default Badges;

