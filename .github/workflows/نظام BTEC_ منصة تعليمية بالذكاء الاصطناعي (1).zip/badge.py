"""
نموذج الأوسمة والإنجازات في منصة EduverseAI - قلعة BTEC
"""
from datetime import datetime
from bson import ObjectId

class Badge:
    """
    نموذج الوسام أو الإنجاز في المنصة
    """
    def __init__(self, name, description, image_url, category, requirements=None, 
                 points=0, created_at=None, updated_at=None, _id=None):
        """
        تهيئة كائن الوسام
        
        المعلمات:
            name (str): اسم الوسام
            description (str): وصف الوسام
            image_url (str): مسار صورة الوسام
            category (str): فئة الوسام (academic, participation, achievement)
            requirements (dict): متطلبات الحصول على الوسام
            points (int): النقاط المكتسبة عند الحصول على الوسام
            created_at (datetime): تاريخ إنشاء الوسام
            updated_at (datetime): تاريخ آخر تحديث للوسام
            _id (ObjectId): معرف الوسام في قاعدة البيانات
        """
        self._id = _id if _id else ObjectId()
        self.name = name
        self.description = description
        self.image_url = image_url
        self.category = category
        self.requirements = requirements if requirements else {}
        self.points = points
        self.created_at = created_at if created_at else datetime.utcnow()
        self.updated_at = updated_at if updated_at else datetime.utcnow()
        
        # بيانات إضافية للوسام
        self.rarity = "common"  # ندرة الوسام (common, uncommon, rare, epic, legendary)
        self.is_hidden = False  # هل الوسام مخفي حتى يتم الحصول عليه
        self.jordanian_theme = ""  # الموضوع الأردني المرتبط بالوسام
        
    def to_dict(self):
        """
        تحويل كائن الوسام إلى قاموس
        
        العائد:
            dict: قاموس يمثل الوسام
        """
        return {
            "_id": str(self._id),
            "name": self.name,
            "description": self.description,
            "image_url": self.image_url,
            "category": self.category,
            "requirements": self.requirements,
            "points": self.points,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "rarity": self.rarity,
            "is_hidden": self.is_hidden,
            "jordanian_theme": self.jordanian_theme
        }
    
    @classmethod
    def from_dict(cls, data):
        """
        إنشاء كائن وسام من قاموس
        
        المعلمات:
            data (dict): قاموس يحتوي على بيانات الوسام
            
        العائد:
            Badge: كائن الوسام
        """
        _id = ObjectId(data["_id"]) if "_id" in data else None
        created_at = datetime.fromisoformat(data["created_at"]) if "created_at" in data else None
        updated_at = datetime.fromisoformat(data["updated_at"]) if "updated_at" in data else None
        
        badge = cls(
            name=data.get("name"),
            description=data.get("description"),
            image_url=data.get("image_url"),
            category=data.get("category"),
            requirements=data.get("requirements", {}),
            points=data.get("points", 0),
            created_at=created_at,
            updated_at=updated_at,
            _id=_id
        )
        
        badge.rarity = data.get("rarity", "common")
        badge.is_hidden = data.get("is_hidden", False)
        badge.jordanian_theme = data.get("jordanian_theme", "")
        
        return badge


class UserBadge:
    """
    نموذج العلاقة بين المستخدم والوسام
    """
    def __init__(self, user_id, badge_id, earned_at=None, _id=None):
        """
        تهيئة كائن العلاقة بين المستخدم والوسام
        
        المعلمات:
            user_id (ObjectId): معرف المستخدم
            badge_id (ObjectId): معرف الوسام
            earned_at (datetime): تاريخ الحصول على الوسام
            _id (ObjectId): معرف العلاقة في قاعدة البيانات
        """
        self._id = _id if _id else ObjectId()
        self.user_id = user_id
        self.badge_id = badge_id
        self.earned_at = earned_at if earned_at else datetime.utcnow()
        
        # بيانات إضافية للعلاقة
        self.progress = 100  # نسبة التقدم نحو الحصول على الوسام
        self.blockchain_verification = {}  # معلومات التحقق من البلوكتشين
        
    def to_dict(self):
        """
        تحويل كائن العلاقة إلى قاموس
        
        العائد:
            dict: قاموس يمثل العلاقة
        """
        return {
            "_id": str(self._id),
            "user_id": str(self.user_id),
            "badge_id": str(self.badge_id),
            "earned_at": self.earned_at.isoformat(),
            "progress": self.progress,
            "blockchain_verification": self.blockchain_verification
        }
    
    @classmethod
    def from_dict(cls, data):
        """
        إنشاء كائن علاقة من قاموس
        
        المعلمات:
            data (dict): قاموس يحتوي على بيانات العلاقة
            
        العائد:
            UserBadge: كائن العلاقة
        """
        _id = ObjectId(data["_id"]) if "_id" in data else None
        user_id = ObjectId(data["user_id"]) if "user_id" in data else None
        badge_id = ObjectId(data["badge_id"]) if "badge_id" in data else None
        earned_at = datetime.fromisoformat(data["earned_at"]) if "earned_at" in data else None
        
        user_badge = cls(
            user_id=user_id,
            badge_id=badge_id,
            earned_at=earned_at,
            _id=_id
        )
        
        user_badge.progress = data.get("progress", 100)
        user_badge.blockchain_verification = data.get("blockchain_verification", {})
        
        return user_badge

