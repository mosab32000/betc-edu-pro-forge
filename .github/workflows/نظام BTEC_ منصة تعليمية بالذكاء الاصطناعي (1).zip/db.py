"""
إدارة قاعدة البيانات MongoDB لمنصة EduverseAI - قلعة BTEC
"""
import os
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure
from dotenv import load_dotenv

# تحميل متغيرات البيئة
load_dotenv()

class Database:
    """
    فئة إدارة قاعدة البيانات MongoDB
    """
    _instance = None
    
    def __new__(cls):
        """
        تطبيق نمط Singleton لضمان وجود نسخة واحدة فقط من الاتصال بقاعدة البيانات
        """
        if cls._instance is None:
            cls._instance = super(Database, cls).__new__(cls)
            cls._instance._initialize_db()
        return cls._instance
    
    def _initialize_db(self):
        """
        تهيئة الاتصال بقاعدة البيانات
        """
        # الحصول على معلومات الاتصال من متغيرات البيئة
        mongo_uri = os.getenv("MONGO_URI", "mongodb://localhost:27017")
        db_name = os.getenv("DB_NAME", "eduverse_btec")
        
        try:
            # إنشاء اتصال بقاعدة البيانات
            self.client = MongoClient(mongo_uri)
            self.db = self.client[db_name]
            
            # التحقق من الاتصال
            self.client.admin.command('ping')
            print(f"تم الاتصال بقاعدة البيانات {db_name} بنجاح")
            
            # تعريف المجموعات
            self.users = self.db.users
            self.tasks = self.db.tasks
            self.assessments = self.db.assessments
            self.badges = self.db.badges
            self.user_badges = self.db.user_badges
            self.xr_experiences = self.db.xr_experiences
            self.user_xr_experiences = self.db.user_xr_experiences
            
            # إنشاء الفهارس
            self._create_indexes()
            
        except ConnectionFailure:
            print("فشل الاتصال بقاعدة البيانات MongoDB")
            self.client = None
            self.db = None
    
    def _create_indexes(self):
        """
        إنشاء الفهارس اللازمة لتحسين الأداء
        """
        # فهارس المستخدمين
        self.users.create_index("username", unique=True)
        self.users.create_index("email", unique=True)
        
        # فهارس المهام
        self.tasks.create_index("subject")
        self.tasks.create_index("created_by")
        
        # فهارس التقييمات
        self.assessments.create_index([("task_id", 1), ("user_id", 1)], unique=True)
        self.assessments.create_index("status")
        
        # فهارس الأوسمة
        self.badges.create_index("name", unique=True)
        self.badges.create_index("category")
        
        # فهارس علاقات المستخدم والأوسمة
        self.user_badges.create_index([("user_id", 1), ("badge_id", 1)], unique=True)
        
        # فهارس تجارب التعلم الغامرة
        self.xr_experiences.create_index("subject")
        self.xr_experiences.create_index("type_xr")
        
        # فهارس علاقات المستخدم وتجارب التعلم الغامرة
        self.user_xr_experiences.create_index([("user_id", 1), ("experience_id", 1)], unique=True)
    
    def close(self):
        """
        إغلاق الاتصال بقاعدة البيانات
        """
        if self.client:
            self.client.close()
            print("تم إغلاق الاتصال بقاعدة البيانات")


# إنشاء كائن قاعدة البيانات للاستخدام في جميع أنحاء التطبيق
db = Database()

# تصدير كائن قاعدة البيانات
__all__ = ['db']

