import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  HomeIcon,
  ArrowLeftIcon,
  SaveIcon,
  SendIcon,
  HelpCircleIcon,
  FileTextIcon,
  ClockIcon,
  BrainIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';

const Assessment = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [task, setTask] = useState(null);
  const [answer, setAnswer] = useState('');
  const [timeRemaining, setTimeRemaining] = useState(3600); // 60 minutes in seconds
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showAIHelp, setShowAIHelp] = useState(false);
  const [aiSuggestion, setAiSuggestion] = useState('');

  useEffect(() => {
    // محاكاة تحميل البيانات
    const loadData = async () => {
      setIsLoading(true);
      try {
        // محاكاة تأخير الشبكة
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // بيانات وهمية للعرض
        setTask({
          id: 2,
          title: 'تحليل SWOT لشركة ناشئة',
          description: 'قم بإجراء تحليل SWOT لشركة ناشئة في مجال التكنولوجيا. يجب أن يتضمن التحليل نقاط القوة والضعف والفرص والتهديدات، مع شرح كيفية استفادة الشركة من هذا التحليل في تطوير استراتيجياتها.',
          instructions: [
            'اختر شركة ناشئة حقيقية في مجال التكنولوجيا',
            'قم بتحليل البيئة الداخلية (نقاط القوة والضعف)',
            'قم بتحليل البيئة الخارجية (الفرص والتهديدات)',
            'اشرح كيفية استفادة الشركة من هذا التحليل',
            'قدم توصيات لتحسين وضع الشركة'
          ],
          criteria: [
            'دقة التحليل وشموليته',
            'استخدام أمثلة واقعية',
            'جودة التوصيات المقدمة',
            'التنظيم وسلامة اللغة'
          ],
          resources: [
            {
              title: 'دليل تحليل SWOT',
              type: 'pdf',
              url: '#'
            },
            {
              title: 'أمثلة على تحليل SWOT لشركات تكنولوجية',
              type: 'website',
              url: '#'
            },
            {
              title: 'فيديو توضيحي لتحليل SWOT',
              type: 'video',
              url: '#'
            }
          ],
          dueDate: '2025-06-20',
          subject: 'إدارة الأعمال',
          progress: 60
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    loadData();
    
    // محاكاة العد التنازلي
    const timer = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 0) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);

  // تنسيق الوقت المتبقي
  const formatTime = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // محاكاة حفظ المسودة
  const handleSaveDraft = () => {
    // في التطبيق الحقيقي، سيتم حفظ المسودة في قاعدة البيانات
    alert('تم حفظ المسودة بنجاح');
  };

  // محاكاة تقديم الإجابة
  const handleSubmit = () => {
    if (!answer.trim()) {
      alert('الرجاء كتابة إجابتك قبل التقديم');
      return;
    }
    
    setIsSubmitting(true);
    
    // محاكاة تأخير الشبكة
    setTimeout(() => {
      setIsSubmitting(false);
      // في التطبيق الحقيقي، سيتم إرسال الإجابة إلى الخادم
      alert('تم تقديم إجابتك بنجاح');
      // التوجيه إلى صفحة التغذية الراجعة
      window.location.href = '/feedback';
    }, 2000);
  };

  // محاكاة طلب المساعدة من الذكاء الاصطناعي
  const handleAIHelp = () => {
    setShowAIHelp(true);
    
    // محاكاة تأخير الشبكة
    setTimeout(() => {
      setAiSuggestion(`
يمكنك اتباع الهيكل التالي لتحليل SWOT:

1. المقدمة:
   - تقديم الشركة الناشئة التي اخترتها
   - شرح موجز عن مجال عملها وأهمية تحليل SWOT

2. نقاط القوة (Strengths):
   - الميزات التنافسية للشركة
   - الموارد والكفاءات المتميزة
   - التكنولوجيا المبتكرة

3. نقاط الضعف (Weaknesses):
   - التحديات الداخلية
   - نقص الموارد أو الخبرات
   - مشكلات في نموذج العمل

4. الفرص (Opportunities):
   - اتجاهات السوق الإيجابية
   - احتياجات العملاء غير الملباة
   - التطورات التكنولوجية الجديدة

5. التهديدات (Threats):
   - المنافسة الحالية والمحتملة
   - التغيرات التنظيمية
   - التحديات الاقتصادية

6. الاستنتاجات والتوصيات:
   - كيفية الاستفادة من نقاط القوة لاغتنام الفرص
   - كيفية معالجة نقاط الضعف وتجنب التهديدات
   - استراتيجيات مقترحة للنمو المستقبلي
      `);
    }, 1500);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* شريط التنقل العلوي */}
      <header className="bg-primary text-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <Link to="/task-hall" className="ml-2">
              <Button variant="ghost" size="icon" className="text-white hover:bg-primary-foreground/10">
                <ArrowLeftIcon className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-bold">التقييم</h1>
          </div>
          
          <div className="flex items-center">
            <div className="bg-white/20 text-white text-sm px-3 py-1 rounded-full flex items-center ml-2">
              <ClockIcon className="h-4 w-4 ml-1" />
              <span>{formatTime(timeRemaining)}</span>
            </div>
            
            <Link to="/">
              <Button variant="ghost" size="icon" className="text-white hover:bg-primary-foreground/10">
                <HomeIcon className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
              <p className="mt-4 text-muted-foreground">جاري تحميل التقييم...</p>
            </div>
          </div>
        ) : (
          <>
            {/* عنوان المهمة والتقدم */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mb-6"
            >
              <h2 className="text-2xl font-bold text-primary">{task.title}</h2>
              <p className="text-muted-foreground mt-1">{task.subject}</p>
              
              <div className="mt-2">
                <div className="flex justify-between text-xs text-muted-foreground mb-1">
                  <span>التقدم</span>
                  <span>{task.progress}%</span>
                </div>
                <Progress value={task.progress} className="h-1.5" />
              </div>
            </motion.div>
            
            {/* علامات التبويب للمعلومات والإجابة */}
            <Tabs defaultValue="instructions" className="mb-6">
              <TabsList className="bg-muted w-full justify-start">
                <TabsTrigger value="instructions">التعليمات</TabsTrigger>
                <TabsTrigger value="criteria">معايير التقييم</TabsTrigger>
                <TabsTrigger value="resources">الموارد</TabsTrigger>
                <TabsTrigger value="answer">الإجابة</TabsTrigger>
              </TabsList>
              
              <TabsContent value="instructions" className="mt-4">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  className="bg-white rounded-lg shadow-md p-6"
                >
                  <h3 className="text-lg font-bold text-primary mb-4">وصف المهمة</h3>
                  <p className="text-muted-foreground mb-4">{task.description}</p>
                  
                  <h4 className="font-medium text-primary mb-2">خطوات التنفيذ:</h4>
                  <ol className="list-decimal pr-5 space-y-2 text-muted-foreground">
                    {task.instructions.map((instruction, index) => (
                      <li key={index}>{instruction}</li>
                    ))}
                  </ol>
                </motion.div>
              </TabsContent>
              
              <TabsContent value="criteria" className="mt-4">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  className="bg-white rounded-lg shadow-md p-6"
                >
                  <h3 className="text-lg font-bold text-primary mb-4">معايير التقييم</h3>
                  <ul className="list-disc pr-5 space-y-2 text-muted-foreground">
                    {task.criteria.map((criterion, index) => (
                      <li key={index}>{criterion}</li>
                    ))}
                  </ul>
                </motion.div>
              </TabsContent>
              
              <TabsContent value="resources" className="mt-4">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  className="bg-white rounded-lg shadow-md p-6"
                >
                  <h3 className="text-lg font-bold text-primary mb-4">الموارد المساعدة</h3>
                  <div className="space-y-3">
                    {task.resources.map((resource, index) => (
                      <div key={index} className="flex items-center">
                        <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center ml-3">
                          {resource.type === 'pdf' && <FileTextIcon className="h-4 w-4 text-primary" />}
                          {resource.type === 'website' && <LinkIcon className="h-4 w-4 text-primary" />}
                          {resource.type === 'video' && <VideoIcon className="h-4 w-4 text-primary" />}
                        </div>
                        <div>
                          <a href={resource.url} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                            {resource.title}
                          </a>
                          <p className="text-xs text-muted-foreground">{resource.type}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              </TabsContent>
              
              <TabsContent value="answer" className="mt-4">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  className="bg-white rounded-lg shadow-md p-6"
                >
                  <h3 className="text-lg font-bold text-primary mb-4">إجابتك</h3>
                  
                  <div className="mb-4">
                    <Textarea
                      placeholder="اكتب إجابتك هنا..."
                      value={answer}
                      onChange={(e) => setAnswer(e.target.value)}
                      className="min-h-[300px] text-right"
                    />
                  </div>
                  
                  <div className="flex justify-between">
                    <div>
                      <Button
                        variant="outline"
                        onClick={() => setShowAIHelp(!showAIHelp)}
                        className="flex items-center"
                      >
                        <BrainIcon className="h-4 w-4 ml-2" />
                        {showAIHelp ? 'إخفاء المساعدة' : 'مساعدة الذكاء الاصطناعي'}
                      </Button>
                    </div>
                    
                    <div className="flex">
                      <Button
                        variant="outline"
                        onClick={handleSaveDraft}
                        className="flex items-center ml-2"
                      >
                        <SaveIcon className="h-4 w-4 ml-2" />
                        حفظ كمسودة
                      </Button>
                      
                      <Button
                        onClick={handleSubmit}
                        disabled={isSubmitting}
                        className="flex items-center"
                      >
                        {isSubmitting ? (
                          <>
                            <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin ml-2"></div>
                            جاري التقديم...
                          </>
                        ) : (
                          <>
                            <SendIcon className="h-4 w-4 ml-2" />
                            تقديم الإجابة
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                  
                  {showAIHelp && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="mt-4 bg-muted/20 p-4 rounded-lg border border-muted"
                    >
                      <div className="flex items-center mb-2">
                        <BrainIcon className="h-5 w-5 ml-2 text-primary" />
                        <h4 className="font-medium text-primary">اقتراحات المساعد الذكي</h4>
                      </div>
                      
                      {aiSuggestion ? (
                        <pre className="text-sm text-muted-foreground whitespace-pre-wrap">{aiSuggestion}</pre>
                      ) : (
                        <div className="flex items-center justify-center py-4">
                          <div className="h-5 w-5 border-2 border-primary border-t-transparent rounded-full animate-spin ml-2"></div>
                          <span className="text-sm text-muted-foreground">جاري تحليل المهمة...</span>
                        </div>
                      )}
                      
                      <div className="mt-2 text-xs text-muted-foreground flex items-center">
                        <HelpCircleIcon className="h-3 w-3 ml-1" />
                        <span>هذه اقتراحات فقط. تأكد من كتابة إجابتك الخاصة.</span>
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              </TabsContent>
            </Tabs>
          </>
        )}
      </main>

      <footer className="bg-primary/80 text-white p-4 text-center">
        <p className="text-sm">© 2025 EduverseAI - قلعة BTEC. جميع الحقوق محفوظة.</p>
      </footer>
    </div>
  );
};

// أيقونات إضافية
const LinkIcon = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path>
    <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>
  </svg>
);

const VideoIcon = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polygon points="23 7 16 12 23 17 23 7"></polygon>
    <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
  </svg>
);

export default Assessment;

