# EduverseAI - قلعة BTEC API

واجهة برمجة التطبيقات (API) لمنصة "EduverseAI - قلعة BTEC" التعليمية، منصة تعليمية متكاملة تجمع بين أحدث تقنيات الذكاء الاصطناعي، تجارب التعلم الغامرة (XR)، والبلوكتشين.

## المميزات الرئيسية

- **الذكاء الاصطناعي**: تكامل مع نموذج Llama 3 المحلي لتوفير المساعدة الذكية والتغذية الراجعة للطلاب.
- **البلوكتشين**: نظام للتحقق من الشهادات والإنجازات باستخدام تقنية البلوكتشين.
- **تجارب التعلم الغامرة (XR)**: دعم لتجارب الواقع المعزز (AR) والواقع الافتراضي (VR) والواقع المختلط (MR).
- **نظام المستخدمين**: إدارة المستخدمين والأدوار والصلاحيات.
- **نظام المهام التعليمية**: إدارة المهام التعليمية ومعايير التقييم.
- **نظام التقييم**: تقييم إجابات الطلاب وتوفير التغذية الراجعة.
- **نظام الأوسمة**: منح الأوسمة للطلاب بناءً على إنجازاتهم.

## المتطلبات

- Python 3.8+
- MongoDB
- نموذج Llama 3 المحلي (8B أو 70B)

## التثبيت

1. استنساخ المستودع:

```bash
git clone https://github.com/your-username/eduverse-btec-api.git
cd eduverse-btec-api
```

2. إنشاء بيئة افتراضية وتفعيلها:

```bash
python -m venv venv
source venv/bin/activate  # على Linux/macOS
venv\Scripts\activate  # على Windows
```

3. تثبيت المتطلبات:

```bash
pip install -r requirements.txt
```

4. تنزيل نموذج Llama 3:

```bash
python scripts/download_llama_model.py
```

5. إنشاء ملف `.env` وتعديله حسب الحاجة:

```bash
cp .env.example .env
```

## التشغيل

1. تشغيل الخادم:

```bash
python wsgi.py
```

2. تشغيل الخادم باستخدام Docker:

```bash
docker-compose up
```

## واجهات برمجة التطبيقات (API)

### الذكاء الاصطناعي

- `GET /api/ai/health`: فحص صحة خدمة الذكاء الاصطناعي
- `POST /api/ai/chat`: إرسال رسالة إلى المساعد الذكي
- `POST /api/ai/feedback`: الحصول على تغذية راجعة ذكية على إجابة الطالب
- `POST /api/ai/generate-question`: توليد سؤال جديد بناءً على موضوع معين
- `POST /api/ai/analyze-answer`: تحليل إجابة الطالب وتقييمها

### البلوكتشين

- `GET /api/blockchain/health`: فحص صحة خدمة البلوكتشين
- `POST /api/blockchain/verify-certificate`: التحقق من صحة شهادة
- `POST /api/blockchain/issue-certificate`: إصدار شهادة جديدة
- `GET /api/blockchain/certificates/:userId`: الحصول على جميع شهادات المستخدم
- `POST /api/blockchain/verify-badge`: التحقق من صحة وسام

### تجارب التعلم الغامرة (XR)

- `GET /api/xr/experiences`: الحصول على جميع تجارب التعلم الغامرة
- `GET /api/xr/experiences/:experienceType`: الحصول على تجارب التعلم الغامرة حسب النوع
- `GET /api/xr/experience/:experienceId`: الحصول على تجربة تعلم غامرة حسب المعرف
- `POST /api/xr/experience`: إضافة تجربة تعلم غامرة جديدة
- `PUT /api/xr/experience/:experienceId`: تحديث تجربة تعلم غامرة
- `DELETE /api/xr/experience/:experienceId`: حذف تجربة تعلم غامرة
- `GET /api/xr/user-progress/:userId`: الحصول على تقدم المستخدم
- `POST /api/xr/user-progress/:userId/:experienceId`: تحديث تقدم المستخدم
- `GET /api/xr/recommended/:userId`: الحصول على تجارب التعلم الغامرة الموصى بها للمستخدم
- `GET /api/xr/content/:experienceId`: الحصول على محتوى تجربة التعلم الغامرة

### المستخدمين

- `POST /api/users/register`: تسجيل مستخدم جديد
- `POST /api/users/login`: تسجيل الدخول
- `GET /api/users/profile`: الحصول على الملف الشخصي للمستخدم
- `PUT /api/users/profile`: تحديث الملف الشخصي للمستخدم
- `GET /api/users/:userId`: الحصول على معلومات مستخدم
- `GET /api/users`: الحصول على جميع المستخدمين

### المهام التعليمية

- `GET /api/tasks`: الحصول على جميع المهام التعليمية
- `GET /api/tasks/:taskId`: الحصول على مهمة تعليمية حسب المعرف
- `POST /api/tasks`: إنشاء مهمة تعليمية جديدة
- `PUT /api/tasks/:taskId`: تحديث مهمة تعليمية
- `DELETE /api/tasks/:taskId`: حذف مهمة تعليمية
- `GET /api/tasks/user/:userId`: الحصول على مهام المستخدم

### التقييمات

- `GET /api/assessments`: الحصول على جميع التقييمات
- `GET /api/assessments/:assessmentId`: الحصول على تقييم حسب المعرف
- `POST /api/assessments`: إنشاء تقييم جديد
- `PUT /api/assessments/:assessmentId`: تحديث تقييم
- `DELETE /api/assessments/:assessmentId`: حذف تقييم
- `GET /api/assessments/user/:userId`: الحصول على تقييمات المستخدم
- `GET /api/assessments/task/:taskId`: الحصول على تقييمات المهمة

### الأوسمة

- `GET /api/badges`: الحصول على جميع الأوسمة
- `GET /api/badges/:badgeId`: الحصول على وسام حسب المعرف
- `POST /api/badges`: إنشاء وسام جديد
- `PUT /api/badges/:badgeId`: تحديث وسام
- `DELETE /api/badges/:badgeId`: حذف وسام
- `GET /api/badges/user/:userId`: الحصول على أوسمة المستخدم
- `POST /api/badges/award/:userId/:badgeId`: منح وسام للمستخدم

## المساهمة

نرحب بالمساهمات! يرجى اتباع الخطوات التالية:

1. استنساخ المستودع
2. إنشاء فرع جديد (`git checkout -b feature/amazing-feature`)
3. إجراء التغييرات
4. الالتزام بالتغييرات (`git commit -m 'إضافة ميزة رائعة'`)
5. دفع الفرع (`git push origin feature/amazing-feature`)
6. فتح طلب سحب

## الترخيص

هذا المشروع مرخص بموجب رخصة MIT - انظر ملف [LICENSE](LICENSE) للحصول على التفاصيل.

## الاتصال

- البريد الإلكتروني: info@eduverse-btec.com
- الموقع الإلكتروني: https://eduverse-btec.com

