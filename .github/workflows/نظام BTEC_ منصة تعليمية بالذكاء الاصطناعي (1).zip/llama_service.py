"""
خدمة الذكاء الاصطناعي باستخدام نموذج Llama 3 المحلي لمنصة EduverseAI - قلعة BTEC

توفر هذه الوحدة واجهة برمجية لاستخدام نموذج Llama 3 المحلي لتوفير:
1. المساعدة الذكية للطلاب
2. التغذية الراجعة الذكية على إجابات الطلاب
3. توليد المحتوى التعليمي
4. تحليل أداء الطلاب
"""

import os
import logging
import json
from typing import Dict, List, Optional, Union, Any
from pathlib import Path

# إعداد التسجيل
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class LlamaService:
    """خدمة الذكاء الاصطناعي باستخدام نموذج Llama 3 المحلي"""
    
    def __init__(self, model_path: Optional[str] = None, use_gpu: bool = False):
        """
        تهيئة خدمة Llama
        
        المعلمات:
            model_path: مسار ملف النموذج. إذا كان None، سيتم استخدام المسار الافتراضي
            use_gpu: استخدام GPU إذا كان متاحاً
        """
        self.model = None
        self.model_path = model_path or os.environ.get(
            'LLAMA_MODEL_PATH', 
            str(Path(__file__).parent.parent.parent / 'models' / 'gguf' / 'Meta-Llama-3-8B-Instruct.gguf')
        )
        self.use_gpu = use_gpu
        self._load_model()
    
    def _load_model(self):
        """تحميل نموذج Llama"""
        try:
            from llama_cpp import Llama
            
            logger.info(f"جاري تحميل نموذج Llama من: {self.model_path}")
            
            # تحميل النموذج
            self.model = Llama(
                model_path=self.model_path,
                n_ctx=4096,  # حجم سياق النموذج
                n_gpu_layers=-1 if self.use_gpu else 0  # استخدام جميع طبقات GPU إذا كان use_gpu=True
            )
            
            logger.info("تم تحميل نموذج Llama بنجاح")
        except ImportError:
            logger.error("فشل في استيراد llama_cpp. يرجى تثبيته باستخدام: pip install llama-cpp-python")
            raise
        except Exception as e:
            logger.error(f"فشل في تحميل نموذج Llama: {e}")
            raise
    
    def generate_response(self, prompt: str, max_tokens: int = 512, temperature: float = 0.7) -> str:
        """
        توليد استجابة من نموذج Llama
        
        المعلمات:
            prompt: النص المدخل للنموذج
            max_tokens: الحد الأقصى لعدد الرموز في الاستجابة
            temperature: درجة الحرارة للتوليد (0.0-1.0)، قيم أقل تعني استجابات أكثر حتمية
            
        الإرجاع:
            النص المولد
        """
        if self.model is None:
            logger.error("لم يتم تحميل النموذج")
            return "عذراً، النموذج غير متاح حالياً."
        
        try:
            # إضافة قالب التعليمات لنموذج Llama 3
            formatted_prompt = f"""<|im_start|>system
أنت مساعد تعليمي ذكي لمنصة EduverseAI - قلعة BTEC. أنت تتحدث العربية بطلاقة وتقدم إجابات دقيقة ومفيدة للطلاب والمعلمين.
<|im_end|>
<|im_start|>user
{prompt}
<|im_end|>
<|im_start|>assistant
"""
            
            # توليد الاستجابة
            response = self.model(
                formatted_prompt,
                max_tokens=max_tokens,
                temperature=temperature,
                stop=["<|im_end|>", "<|im_start|>"]
            )
            
            # استخراج النص المولد
            generated_text = response["choices"][0]["text"]
            
            return generated_text.strip()
        except Exception as e:
            logger.error(f"حدث خطأ أثناء توليد الاستجابة: {e}")
            return "عذراً، حدث خطأ أثناء معالجة طلبك."
    
    def provide_feedback(self, student_answer: str, correct_answer: str, criteria: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        تقديم تغذية راجعة ذكية على إجابة الطالب
        
        المعلمات:
            student_answer: إجابة الطالب
            correct_answer: الإجابة الصحيحة أو النموذجية
            criteria: معايير التقييم
            
        الإرجاع:
            قاموس يحتوي على التغذية الراجعة والدرجة
        """
        prompt = f"""
أنا بحاجة إلى تقييم إجابة طالب بناءً على معايير محددة.

إجابة الطالب:
{student_answer}

الإجابة النموذجية:
{correct_answer}

معايير التقييم:
{json.dumps(criteria, ensure_ascii=False)}

قم بتقييم الإجابة وتقديم تغذية راجعة مفصلة. أعطِ درجة لكل معيار، ثم احسب الدرجة الإجمالية.
قدم النتيجة بتنسيق JSON يحتوي على:
1. درجات كل معيار
2. الدرجة الإجمالية
3. نقاط القوة
4. مجالات التحسين
5. اقتراحات للتحسين
"""
        
        try:
            # توليد التغذية الراجعة
            feedback_text = self.generate_response(prompt, max_tokens=1024, temperature=0.3)
            
            # محاولة تحليل النص كـ JSON
            try:
                # البحث عن بداية ونهاية JSON في النص
                start_idx = feedback_text.find('{')
                end_idx = feedback_text.rfind('}') + 1
                
                if start_idx >= 0 and end_idx > start_idx:
                    json_str = feedback_text[start_idx:end_idx]
                    feedback_data = json.loads(json_str)
                else:
                    # إذا لم يتم العثور على JSON، إنشاء هيكل بديل
                    feedback_data = {
                        "criteria_scores": {},
                        "total_score": 0,
                        "strengths": [],
                        "areas_for_improvement": [],
                        "suggestions": [],
                        "feedback_text": feedback_text
                    }
            except json.JSONDecodeError:
                # إذا فشل تحليل JSON، إنشاء هيكل بديل
                feedback_data = {
                    "criteria_scores": {},
                    "total_score": 0,
                    "strengths": [],
                    "areas_for_improvement": [],
                    "suggestions": [],
                    "feedback_text": feedback_text
                }
            
            return feedback_data
        except Exception as e:
            logger.error(f"حدث خطأ أثناء تقديم التغذية الراجعة: {e}")
            return {
                "error": str(e),
                "feedback_text": "عذراً، حدث خطأ أثناء تقييم الإجابة."
            }
    
    def generate_educational_content(self, topic: str, content_type: str, difficulty_level: str, language: str = "ar") -> str:
        """
        توليد محتوى تعليمي
        
        المعلمات:
            topic: موضوع المحتوى
            content_type: نوع المحتوى (مثل: شرح، أسئلة، تمارين)
            difficulty_level: مستوى الصعوبة (مثل: مبتدئ، متوسط، متقدم)
            language: لغة المحتوى (الافتراضي: العربية)
            
        الإرجاع:
            المحتوى التعليمي المولد
        """
        prompt = f"""
أنا بحاجة إلى توليد محتوى تعليمي حول موضوع معين.

الموضوع: {topic}
نوع المحتوى: {content_type}
مستوى الصعوبة: {difficulty_level}
اللغة: {"العربية" if language == "ar" else "الإنجليزية"}

قم بإنشاء محتوى تعليمي عالي الجودة يناسب الموضوع والمستوى المطلوب. يجب أن يكون المحتوى دقيقاً علمياً، منظماً بشكل جيد، وسهل الفهم.
"""
        
        return self.generate_response(prompt, max_tokens=2048, temperature=0.5)
    
    def analyze_student_performance(self, performance_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        تحليل أداء الطالب وتقديم توصيات
        
        المعلمات:
            performance_data: بيانات أداء الطالب
            
        الإرجاع:
            تحليل الأداء والتوصيات
        """
        prompt = f"""
أنا بحاجة إلى تحليل أداء طالب بناءً على بيانات الأداء التالية:

{json.dumps(performance_data, ensure_ascii=False)}

قم بتحليل هذه البيانات وتقديم:
1. ملخص لأداء الطالب
2. نقاط القوة الرئيسية
3. مجالات تحتاج إلى تحسين
4. توصيات محددة للتحسين
5. مسار تعلم مقترح

قدم النتيجة بتنسيق JSON.
"""
        
        try:
            # توليد التحليل
            analysis_text = self.generate_response(prompt, max_tokens=1024, temperature=0.3)
            
            # محاولة تحليل النص كـ JSON
            try:
                # البحث عن بداية ونهاية JSON في النص
                start_idx = analysis_text.find('{')
                end_idx = analysis_text.rfind('}') + 1
                
                if start_idx >= 0 and end_idx > start_idx:
                    json_str = analysis_text[start_idx:end_idx]
                    analysis_data = json.loads(json_str)
                else:
                    # إذا لم يتم العثور على JSON، إنشاء هيكل بديل
                    analysis_data = {
                        "summary": "",
                        "strengths": [],
                        "areas_for_improvement": [],
                        "recommendations": [],
                        "learning_path": [],
                        "analysis_text": analysis_text
                    }
            except json.JSONDecodeError:
                # إذا فشل تحليل JSON، إنشاء هيكل بديل
                analysis_data = {
                    "summary": "",
                    "strengths": [],
                    "areas_for_improvement": [],
                    "recommendations": [],
                    "learning_path": [],
                    "analysis_text": analysis_text
                }
            
            return analysis_data
        except Exception as e:
            logger.error(f"حدث خطأ أثناء تحليل أداء الطالب: {e}")
            return {
                "error": str(e),
                "analysis_text": "عذراً، حدث خطأ أثناء تحليل أداء الطالب."
            }

# إنشاء نسخة واحدة من الخدمة للاستخدام في جميع أنحاء التطبيق
llama_service = None

def get_llama_service(model_path: Optional[str] = None, use_gpu: bool = False) -> LlamaService:
    """
    الحصول على نسخة من خدمة Llama (نمط Singleton)
    
    المعلمات:
        model_path: مسار ملف النموذج
        use_gpu: استخدام GPU إذا كان متاحاً
        
    الإرجاع:
        نسخة من خدمة Llama
    """
    global llama_service
    
    if llama_service is None:
        llama_service = LlamaService(model_path, use_gpu)
    
    return llama_service

