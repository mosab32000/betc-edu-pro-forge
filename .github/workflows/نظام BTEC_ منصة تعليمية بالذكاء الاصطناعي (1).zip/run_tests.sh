#!/bin/bash
# سكربت لاختبار الأداء وقدرة التحمل لمنصة EduverseAI - قلعة BTEC

# التأكد من وجود المتطلبات
command -v locust >/dev/null 2>&1 || { echo "يرجى تثبيت Locust أولاً: pip install locust"; exit 1; }

# إنشاء مجلد للنتائج
RESULTS_DIR="performance_tests/results/$(date +%Y%m%d_%H%M%S)"
mkdir -p $RESULTS_DIR

# تشغيل اختبار الأداء
echo "بدء اختبار الأداء..."

# اختبار 1: 100 مستخدم، 5 مستخدمين جدد في الثانية
echo "اختبار 1: 100 مستخدم، 5 مستخدمين جدد في الثانية"
locust -f performance_tests/locustfile.py --headless -u 100 -r 5 --run-time 2m --html $RESULTS_DIR/report_100_users.html --csv $RESULTS_DIR/results_100_users --host http://localhost:5000

# اختبار 2: 1000 مستخدم، 20 مستخدم جديد في الثانية
echo "اختبار 2: 1000 مستخدم، 20 مستخدم جديد في الثانية"
locust -f performance_tests/locustfile.py --headless -u 1000 -r 20 --run-time 2m --html $RESULTS_DIR/report_1000_users.html --csv $RESULTS_DIR/results_1000_users --host http://localhost:5000

# اختبار 3: 5000 مستخدم، 50 مستخدم جديد في الثانية
echo "اختبار 3: 5000 مستخدم، 50 مستخدم جديد في الثانية"
locust -f performance_tests/locustfile.py --headless -u 5000 -r 50 --run-time 2m --html $RESULTS_DIR/report_5000_users.html --csv $RESULTS_DIR/results_5000_users --host http://localhost:5000

# اختبار 4: 10000 مستخدم، 100 مستخدم جديد في الثانية
echo "اختبار 4: 10000 مستخدم، 100 مستخدم جديد في الثانية"
locust -f performance_tests/locustfile.py --headless -u 10000 -r 100 --run-time 2m --html $RESULTS_DIR/report_10000_users.html --csv $RESULTS_DIR/results_10000_users --host http://localhost:5000

# تحليل النتائج
echo "تحليل النتائج..."
python performance_tests/analyze_results.py $RESULTS_DIR/results_10000_users_stats.csv

echo "تم الانتهاء من اختبار الأداء. النتائج متاحة في المجلد: $RESULTS_DIR"

