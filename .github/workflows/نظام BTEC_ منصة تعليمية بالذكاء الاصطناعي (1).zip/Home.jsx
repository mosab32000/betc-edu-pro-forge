import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  BookOpenIcon, 
  ClipboardCheckIcon, 
  MessageSquareIcon, 
  TrophyIcon, 
  BrainIcon,
  Gamepad2Icon,
  BarChart3Icon,
  LogOutIcon,
  User2Icon
} from 'lucide-react';
import { Button } from '@/components/ui/button';

const Home = ({ onLogout }) => {
  const [username, setUsername] = useState('أحمد');
  const [wisdomQuote, setWisdomQuote] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  // قائمة من الأمثال والحكم الأردنية
  const jordanianWisdoms = [
    "الصديق وقت الضيق",
    "اللي بيته من زجاج ما بيرمي الناس بالحجار",
    "اسأل مجرب ولا تسأل طبيب",
    "الجار قبل الدار",
    "العلم في الصغر كالنقش على الحجر"
  ];

  useEffect(() => {
    // محاكاة تحميل البيانات
    const loadData = async () => {
      setIsLoading(true);
      try {
        // محاكاة تأخير الشبكة
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // اختيار حكمة عشوائية
        const randomIndex = Math.floor(Math.random() * jordanianWisdoms.length);
        setWisdomQuote(jordanianWisdoms[randomIndex]);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadData();
  }, []);

  // تكوين بطاقات مكونات القلعة
  const castleComponents = [
    {
      title: 'قاعة المهام',
      description: 'استعرض وأكمل المهام والواجبات',
      icon: <ClipboardCheckIcon className="h-8 w-8" />,
      color: 'bg-primary text-white',
      link: '/task-hall'
    },
    {
      title: 'برج الحكمة',
      description: 'استكشف الموارد التعليمية',
      icon: <BookOpenIcon className="h-8 w-8" />,
      color: 'bg-secondary text-white',
      link: '/assessment'
    },
    {
      title: 'المساعد الذكي',
      description: 'احصل على مساعدة فورية من المساعد الذكي',
      icon: <BrainIcon className="h-8 w-8" />,
      color: 'bg-accent text-accent-foreground',
      link: '/ai-assistant'
    },
    {
      title: 'قاعة الأثير',
      description: 'تواصل مع زملائك والمعلمين',
      icon: <MessageSquareIcon className="h-8 w-8" />,
      color: 'bg-primary/80 text-white',
      link: '/feedback'
    },
    {
      title: 'سجل الأبطال',
      description: 'استعرض إنجازاتك والأوسمة',
      icon: <TrophyIcon className="h-8 w-8" />,
      color: 'bg-secondary/80 text-white',
      link: '/badges'
    },
    {
      title: 'تجارب التعلم الغامرة',
      description: 'استكشف عوالم التعلم الافتراضية',
      icon: <svg className="h-8 w-8" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M13 4H21V10H13V4Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M13 14H21V20H13V14Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M3 4H9V10H3V4Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M3 14H9V20H3V14Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>,
      color: 'bg-accent/80 text-accent-foreground',
      link: '/xr-experiences'
    },
    {
      title: 'لوحة التحليلات',
      description: 'تتبع تقدمك وأدائك',
      icon: <BarChart3Icon className="h-8 w-8" />,
      color: 'bg-primary/60 text-white',
      link: '/analytics'
    },
    {
      title: 'قاعة الألعاب التعليمية',
      description: 'تعلم من خلال الألعاب التفاعلية',
      icon: <Gamepad2Icon className="h-8 w-8" />,
      color: 'bg-secondary/60 text-white',
      link: '/educational-games'
    }
  ];

  // تأثيرات الحركة للبطاقات
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100
      }
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background jordanian-pattern">
      {/* شريط التنقل العلوي */}
      <header className="bg-primary text-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <img 
              src="../assets/images/btec_logo.png" 
              alt="EduverseAI - قلعة BTEC" 
              className="h-10 ml-2"
            />
            <h1 className="text-xl font-bold">قلعة BTEC</h1>
          </div>
          
          <div className="flex items-center">
            <div className="flex items-center ml-4">
              <span className="ml-2">{username}</span>
              <div className="bg-white text-primary rounded-full p-1">
                <User2Icon className="h-6 w-6" />
              </div>
            </div>
            
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onLogout}
              className="text-white hover:bg-primary-foreground/10"
            >
              <LogOutIcon className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        {/* ترحيب */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <h2 className="text-2xl font-bold text-primary">مرحباً بك، {username}!</h2>
          <p className="text-muted-foreground">ماذا تريد أن تتعلم اليوم؟</p>
        </motion.div>

        {/* ومضة الحكمة الأردنية */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="bg-accent/20 border border-accent rounded-lg p-4 mb-8"
        >
          <h3 className="text-lg font-semibold text-accent-foreground mb-2">ومضة الحكمة الأردنية</h3>
          {isLoading ? (
            <div className="animate-pulse h-6 bg-accent/20 rounded w-3/4"></div>
          ) : (
            <p className="text-accent-foreground/80">"{wisdomQuote}"</p>
          )}
        </motion.div>

        {/* مكونات القلعة */}
        <h3 className="text-xl font-bold text-primary mb-4">مكونات القلعة</h3>
        
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
        >
          {castleComponents.map((component, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              whileHover={{ scale: 1.03 }}
              className={`${component.color} rounded-lg shadow-md overflow-hidden transition-all hover:shadow-lg`}
            >
              <Link to={component.link} className="block p-4">
                <div className="flex flex-col items-center text-center">
                  <div className="mb-3">
                    {component.icon}
                  </div>
                  <h3 className="text-lg font-bold mb-1">{component.title}</h3>
                  <p className="text-sm opacity-90">{component.description}</p>
                </div>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      </main>

      <footer className="bg-primary/80 text-white p-4 text-center">
        <p className="text-sm">© 2025 EduverseAI - قلعة BTEC. جميع الحقوق محفوظة.</p>
      </footer>
    </div>
  );
};

export default Home;

