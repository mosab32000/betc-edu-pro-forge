#!/usr/bin/env python3
"""
سكربت لتحليل نتائج اختبار الأداء وإنشاء تقرير

يقوم هذا السكربت بتحليل نتائج اختبار الأداء وإنشاء تقرير مفصل
يتضمن الرسوم البيانية والتوصيات لتحسين الأداء.

كيفية الاستخدام:
1. قم بتشغيل السكربت: python analyze_performance_results.py
"""

import json
import os
import sys
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from datetime import datetime
import seaborn as sns

def create_report_directory():
    """إنشاء مجلد للتقرير"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_dir = f"performance_report_{timestamp}"
    os.makedirs(report_dir, exist_ok=True)
    return report_dir

def load_performance_data(file_path):
    """تحميل بيانات الأداء"""
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"خطأ في تحميل ملف البيانات: {e}")
        return None

def analyze_scenarios(performance_data, report_dir):
    """تحليل سيناريوهات اختبار الأداء"""
    scenarios = performance_data["scenarios"]
    
    # إنشاء DataFrame للسيناريوهات
    scenarios_df = pd.DataFrame.from_dict(scenarios, orient="index")
    scenarios_df.reset_index(inplace=True)
    scenarios_df.rename(columns={"index": "scenario"}, inplace=True)
    
    # ترتيب السيناريوهات حسب عدد المستخدمين
    scenarios_df.sort_values(by="users", inplace=True)
    
    # حفظ البيانات في ملف CSV
    csv_path = os.path.join(report_dir, "scenarios_summary.csv")
    scenarios_df.to_csv(csv_path, index=False)
    
    # إنشاء رسم بياني لمتوسط وقت الاستجابة
    plt.figure(figsize=(10, 6))
    plt.plot(scenarios_df["users"], scenarios_df["avg_response_time"], marker="o", linewidth=2)
    plt.title("متوسط وقت الاستجابة حسب عدد المستخدمين", fontsize=14)
    plt.xlabel("عدد المستخدمين", fontsize=12)
    plt.ylabel("متوسط وقت الاستجابة (مللي ثانية)", fontsize=12)
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(report_dir, "avg_response_time.png"), dpi=300)
    
    # إنشاء رسم بياني للمئين 95 لوقت الاستجابة
    plt.figure(figsize=(10, 6))
    plt.plot(scenarios_df["users"], scenarios_df["p95_response_time"], marker="o", linewidth=2, color="orange")
    plt.title("المئين 95 لوقت الاستجابة حسب عدد المستخدمين", fontsize=14)
    plt.xlabel("عدد المستخدمين", fontsize=12)
    plt.ylabel("المئين 95 لوقت الاستجابة (مللي ثانية)", fontsize=12)
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(report_dir, "p95_response_time.png"), dpi=300)
    
    # إنشاء رسم بياني لمعدل الفشل
    plt.figure(figsize=(10, 6))
    plt.plot(scenarios_df["users"], scenarios_df["failure_rate"], marker="o", linewidth=2, color="red")
    plt.title("معدل الفشل حسب عدد المستخدمين", fontsize=14)
    plt.xlabel("عدد المستخدمين", fontsize=12)
    plt.ylabel("معدل الفشل (%)", fontsize=12)
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(report_dir, "failure_rate.png"), dpi=300)
    
    # إنشاء رسم بياني للطلبات في الثانية
    plt.figure(figsize=(10, 6))
    plt.plot(scenarios_df["users"], scenarios_df["requests_per_second"], marker="o", linewidth=2, color="green")
    plt.title("الطلبات في الثانية حسب عدد المستخدمين", fontsize=14)
    plt.xlabel("عدد المستخدمين", fontsize=12)
    plt.ylabel("الطلبات في الثانية", fontsize=12)
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(report_dir, "requests_per_second.png"), dpi=300)
    
    # إنشاء رسم بياني مقارن
    plt.figure(figsize=(12, 8))
    
    # تطبيع البيانات للمقارنة
    normalized_df = scenarios_df.copy()
    for column in ["avg_response_time", "p95_response_time", "failure_rate", "requests_per_second"]:
        max_value = normalized_df[column].max()
        normalized_df[column] = normalized_df[column] / max_value
    
    plt.plot(normalized_df["users"], normalized_df["avg_response_time"], marker="o", linewidth=2, label="متوسط وقت الاستجابة")
    plt.plot(normalized_df["users"], normalized_df["p95_response_time"], marker="s", linewidth=2, label="المئين 95 لوقت الاستجابة")
    plt.plot(normalized_df["users"], normalized_df["failure_rate"], marker="^", linewidth=2, label="معدل الفشل")
    plt.plot(normalized_df["users"], normalized_df["requests_per_second"], marker="d", linewidth=2, label="الطلبات في الثانية")
    
    plt.title("مقارنة مؤشرات الأداء حسب عدد المستخدمين", fontsize=14)
    plt.xlabel("عدد المستخدمين", fontsize=12)
    plt.ylabel("القيمة المطبعة (0-1)", fontsize=12)
    plt.grid(True)
    plt.legend(fontsize=12)
    plt.tight_layout()
    plt.savefig(os.path.join(report_dir, "performance_comparison.png"), dpi=300)
    
    return scenarios_df

def analyze_endpoint_performance(report_dir):
    """تحليل أداء نقاط النهاية"""
    # تحميل بيانات نقاط النهاية من ملف 10000 مستخدم
    try:
        with open("performance_tests/results/locust_results_10000_users.json", "r", encoding="utf-8") as f:
            endpoint_data = json.load(f)
    except Exception as e:
        print(f"خطأ في تحميل ملف بيانات نقاط النهاية: {e}")
        return None
    
    # استخراج بيانات نقاط النهاية
    endpoints = {}
    for endpoint, data in endpoint_data["stats"].items():
        if endpoint != "Total":
            endpoints[endpoint] = {
                "num_requests": data["num_requests"],
                "num_failures": data["num_failures"],
                "failure_rate": data["num_failures"] / data["num_requests"] * 100 if data["num_requests"] > 0 else 0,
                "avg_response_time": data["avg_response_time"],
                "median_response_time": data["median_response_time"],
                "p95_response_time": data["response_time_percentiles"]["95.0"]
            }
    
    # إنشاء DataFrame لنقاط النهاية
    endpoints_df = pd.DataFrame.from_dict(endpoints, orient="index")
    endpoints_df.reset_index(inplace=True)
    endpoints_df.rename(columns={"index": "endpoint"}, inplace=True)
    
    # ترتيب نقاط النهاية حسب متوسط وقت الاستجابة
    endpoints_df.sort_values(by="avg_response_time", ascending=False, inplace=True)
    
    # حفظ البيانات في ملف CSV
    csv_path = os.path.join(report_dir, "endpoints_performance.csv")
    endpoints_df.to_csv(csv_path, index=False)
    
    # إنشاء رسم بياني لمتوسط وقت الاستجابة لنقاط النهاية
    plt.figure(figsize=(12, 8))
    bars = plt.barh(endpoints_df["endpoint"], endpoints_df["avg_response_time"], color="skyblue")
    plt.title("متوسط وقت الاستجابة لنقاط النهاية", fontsize=14)
    plt.xlabel("متوسط وقت الاستجابة (مللي ثانية)", fontsize=12)
    plt.ylabel("نقطة النهاية", fontsize=12)
    plt.grid(axis="x")
    
    # إضافة القيم على الرسم البياني
    for bar in bars:
        width = bar.get_width()
        plt.text(width + 50, bar.get_y() + bar.get_height()/2, f"{width:.1f}", ha="left", va="center")
    
    plt.tight_layout()
    plt.savefig(os.path.join(report_dir, "endpoint_avg_response_time.png"), dpi=300)
    
    # إنشاء رسم بياني لمعدل الفشل لنقاط النهاية
    plt.figure(figsize=(12, 8))
    endpoints_df_sorted = endpoints_df.sort_values(by="failure_rate", ascending=False)
    bars = plt.barh(endpoints_df_sorted["endpoint"], endpoints_df_sorted["failure_rate"], color="salmon")
    plt.title("معدل الفشل لنقاط النهاية", fontsize=14)
    plt.xlabel("معدل الفشل (%)", fontsize=12)
    plt.ylabel("نقطة النهاية", fontsize=12)
    plt.grid(axis="x")
    
    # إضافة القيم على الرسم البياني
    for bar in bars:
        width = bar.get_width()
        plt.text(width + 0.1, bar.get_y() + bar.get_height()/2, f"{width:.2f}%", ha="left", va="center")
    
    plt.tight_layout()
    plt.savefig(os.path.join(report_dir, "endpoint_failure_rate.png"), dpi=300)
    
    return endpoints_df

def generate_recommendations(performance_data, scenarios_df, endpoints_df, report_dir):
    """إنشاء التوصيات لتحسين الأداء"""
    recommendations = performance_data["recommendations"]
    
    # تحليل البيانات لإنشاء توصيات إضافية
    additional_recommendations = []
    
    # التحقق من أداء المنصة مع 10000 مستخدم
    max_users_scenario = scenarios_df.loc[scenarios_df["users"] == 10000].iloc[0]
    if max_users_scenario["avg_response_time"] > 1000:  # أكثر من 1 ثانية
        additional_recommendations.append("تحسين أوقات الاستجابة للمنصة مع 10000 مستخدم من خلال تحسين البنية التحتية")
    
    if max_users_scenario["failure_rate"] > 1:  # أكثر من 1%
        additional_recommendations.append("تقليل معدل الفشل للمنصة مع 10000 مستخدم من خلال تحسين آليات التعامل مع الأخطاء")
    
    # التحقق من أداء نقاط النهاية
    slow_endpoints = endpoints_df[endpoints_df["avg_response_time"] > 1000]  # أكثر من 1 ثانية
    for _, endpoint in slow_endpoints.iterrows():
        additional_recommendations.append(f"تحسين أداء نقطة النهاية {endpoint['endpoint']} (متوسط وقت الاستجابة: {endpoint['avg_response_time']:.2f} مللي ثانية)")
    
    high_failure_endpoints = endpoints_df[endpoints_df["failure_rate"] > 5]  # أكثر من 5%
    for _, endpoint in high_failure_endpoints.iterrows():
        additional_recommendations.append(f"تقليل معدل الفشل لنقطة النهاية {endpoint['endpoint']} (معدل الفشل: {endpoint['failure_rate']:.2f}%)")
    
    # دمج التوصيات
    all_recommendations = recommendations + additional_recommendations
    
    # حفظ التوصيات في ملف نصي
    recommendations_path = os.path.join(report_dir, "recommendations.txt")
    with open(recommendations_path, "w", encoding="utf-8") as f:
        f.write("توصيات لتحسين أداء المنصة:\n")
        f.write("=" * 50 + "\n\n")
        
        for i, recommendation in enumerate(all_recommendations, 1):
            f.write(f"{i}. {recommendation}\n")
    
    return all_recommendations

def generate_performance_report(performance_data, scenarios_df, endpoints_df, recommendations, report_dir):
    """إنشاء تقرير الأداء النهائي"""
    report_path = os.path.join(report_dir, "performance_report.md")
    
    with open(report_path, "w", encoding="utf-8") as f:
        f.write("# تقرير أداء منصة EduverseAI - قلعة BTEC\n\n")
        f.write(f"تاريخ التقرير: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        
        f.write("## ملخص الأداء\n\n")
        f.write("تم إجراء اختبارات الأداء على المنصة لتقييم قدرتها على استيعاب 10,000 مستخدم في وقت واحد. ")
        f.write("تم اختبار المنصة تحت أحمال مختلفة (100، 1000، 5000، 10000 مستخدم) وتحليل النتائج.\n\n")
        
        f.write("### مؤشرات الأداء الرئيسية\n\n")
        f.write("| عدد المستخدمين | متوسط وقت الاستجابة (مللي ثانية) | المئين 95 (مللي ثانية) | معدل الفشل (%) | الطلبات في الثانية |\n")
        f.write("|----------------|----------------------------------|------------------------|----------------|--------------------|\n")
        
        for _, row in scenarios_df.iterrows():
            f.write(f"| {row['users']} | {row['avg_response_time']:.2f} | {row['p95_response_time']:.2f} | {row['failure_rate']:.2f} | {row['requests_per_second']:.2f} |\n")
        
        f.write("\n## تحليل أداء نقاط النهاية\n\n")
        f.write("تم تحليل أداء نقاط النهاية المختلفة في المنصة لتحديد النقاط التي تحتاج إلى تحسين.\n\n")
        
        f.write("### نقاط النهاية الأبطأ\n\n")
        f.write("| نقطة النهاية | متوسط وقت الاستجابة (مللي ثانية) | المئين 95 (مللي ثانية) | معدل الفشل (%) |\n")
        f.write("|--------------|----------------------------------|------------------------|----------------|\n")
        
        for _, row in endpoints_df.sort_values(by="avg_response_time", ascending=False).head(5).iterrows():
            f.write(f"| {row['endpoint']} | {row['avg_response_time']:.2f} | {row['p95_response_time']:.2f} | {row['failure_rate']:.2f} |\n")
        
        f.write("\n### نقاط النهاية ذات معدل الفشل الأعلى\n\n")
        f.write("| نقطة النهاية | معدل الفشل (%) | متوسط وقت الاستجابة (مللي ثانية) | المئين 95 (مللي ثانية) |\n")
        f.write("|--------------|----------------|----------------------------------|------------------------|\n")
        
        for _, row in endpoints_df.sort_values(by="failure_rate", ascending=False).head(5).iterrows():
            f.write(f"| {row['endpoint']} | {row['failure_rate']:.2f} | {row['avg_response_time']:.2f} | {row['p95_response_time']:.2f} |\n")
        
        f.write("\n## الرسوم البيانية\n\n")
        f.write("### متوسط وقت الاستجابة حسب عدد المستخدمين\n\n")
        f.write("![متوسط وقت الاستجابة](avg_response_time.png)\n\n")
        
        f.write("### المئين 95 لوقت الاستجابة حسب عدد المستخدمين\n\n")
        f.write("![المئين 95 لوقت الاستجابة](p95_response_time.png)\n\n")
        
        f.write("### معدل الفشل حسب عدد المستخدمين\n\n")
        f.write("![معدل الفشل](failure_rate.png)\n\n")
        
        f.write("### الطلبات في الثانية حسب عدد المستخدمين\n\n")
        f.write("![الطلبات في الثانية](requests_per_second.png)\n\n")
        
        f.write("### مقارنة مؤشرات الأداء\n\n")
        f.write("![مقارنة مؤشرات الأداء](performance_comparison.png)\n\n")
        
        f.write("### متوسط وقت الاستجابة لنقاط النهاية\n\n")
        f.write("![متوسط وقت الاستجابة لنقاط النهاية](endpoint_avg_response_time.png)\n\n")
        
        f.write("### معدل الفشل لنقاط النهاية\n\n")
        f.write("![معدل الفشل لنقاط النهاية](endpoint_failure_rate.png)\n\n")
        
        f.write("## التوصيات\n\n")
        for i, recommendation in enumerate(recommendations, 1):
            f.write(f"{i}. {recommendation}\n")
        
        f.write("\n## الخلاصة\n\n")
        
        # تحديد ما إذا كانت المنصة قادرة على استيعاب 10000 مستخدم
        max_users_scenario = scenarios_df.loc[scenarios_df["users"] == 10000].iloc[0]
        if max_users_scenario["avg_response_time"] < 1000 and max_users_scenario["failure_rate"] < 5:
            f.write("المنصة قادرة على استيعاب 10,000 مستخدم في وقت واحد بأداء جيد. ")
            f.write("ومع ذلك، يمكن تحسين الأداء من خلال تنفيذ التوصيات المذكورة أعلاه.\n")
        else:
            f.write("المنصة غير قادرة حاليًا على استيعاب 10,000 مستخدم في وقت واحد بأداء مقبول. ")
            f.write("يجب تنفيذ التوصيات المذكورة أعلاه لتحسين الأداء وزيادة قدرة التحمل.\n")
    
    # تحويل التقرير إلى PDF
    try:
        os.system(f"cd {report_dir} && manus-md-to-pdf performance_report.md performance_report.pdf")
        print(f"تم إنشاء تقرير الأداء في: {os.path.join(report_dir, 'performance_report.pdf')}")
    except Exception as e:
        print(f"خطأ في تحويل التقرير إلى PDF: {e}")
        print(f"تم إنشاء تقرير الأداء في: {report_path}")
    
    return report_path

def main():
    """الدالة الرئيسية"""
    # إنشاء مجلد للتقرير
    report_dir = create_report_directory()
    print(f"إنشاء التقارير في المجلد: {report_dir}")
    
    # تحميل بيانات الأداء
    performance_data = load_performance_data("performance_tests/results/performance_summary.json")
    if not performance_data:
        print("فشل تحميل بيانات الأداء.")
        return
    
    # تحليل سيناريوهات اختبار الأداء
    scenarios_df = analyze_scenarios(performance_data, report_dir)
    
    # تحليل أداء نقاط النهاية
    endpoints_df = analyze_endpoint_performance(report_dir)
    
    # إنشاء التوصيات
    recommendations = generate_recommendations(performance_data, scenarios_df, endpoints_df, report_dir)
    
    # إنشاء تقرير الأداء النهائي
    report_path = generate_performance_report(performance_data, scenarios_df, endpoints_df, recommendations, report_dir)
    
    print(f"تم إنشاء تقرير الأداء بنجاح في: {report_path}")

if __name__ == "__main__":
    main()

