"""
خدمة البلوكتشين للتحقق من الشهادات والإنجازات في منصة EduverseAI - قلعة BTEC

توفر هذه الوحدة واجهة برمجية لاستخدام تقنية البلوكتشين لـ:
1. إصدار شهادات وإنجازات موثقة
2. التحقق من صحة الشهادات والإنجازات
3. تتبع مسار التعلم للطلاب
"""

import os
import logging
import json
import hashlib
import time
import uuid
from typing import Dict, List, Optional, Union, Any
from pathlib import Path
import base64
import hmac

# إعداد التسجيل
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class BlockchainService:
    """خدمة البلوكتشين للتحقق من الشهادات والإنجازات"""
    
    def __init__(self, data_dir: Optional[str] = None):
        """
        تهيئة خدمة البلوكتشين
        
        المعلمات:
            data_dir: مجلد تخزين بيانات البلوكتشين. إذا كان None، سيتم استخدام المسار الافتراضي
        """
        self.data_dir = data_dir or os.environ.get(
            'BLOCKCHAIN_DATA_DIR', 
            str(Path(__file__).parent.parent.parent / 'data' / 'blockchain')
        )
        
        # إنشاء مجلد البيانات إذا لم يكن موجوداً
        os.makedirs(self.data_dir, exist_ok=True)
        
        # مسار ملف سلسلة الكتل
        self.blockchain_file = os.path.join(self.data_dir, 'blockchain.json')
        
        # تحميل سلسلة الكتل أو إنشاء سلسلة جديدة
        self.blockchain = self._load_blockchain()
        
        # المفتاح السري للتوقيع (في الإنتاج، يجب تخزينه بشكل آمن)
        self.secret_key = os.environ.get('BLOCKCHAIN_SECRET_KEY', 'eduverse_btec_secret_key')
    
    def _load_blockchain(self) -> List[Dict[str, Any]]:
        """
        تحميل سلسلة الكتل من الملف
        
        الإرجاع:
            سلسلة الكتل
        """
        try:
            if os.path.exists(self.blockchain_file):
                with open(self.blockchain_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                # إنشاء كتلة البداية (Genesis Block)
                genesis_block = {
                    'index': 0,
                    'timestamp': time.time(),
                    'transactions': [],
                    'previous_hash': '0',
                    'hash': self._calculate_hash(0, time.time(), [], '0'),
                    'nonce': 0
                }
                
                # حفظ سلسلة الكتل
                self._save_blockchain([genesis_block])
                
                return [genesis_block]
        except Exception as e:
            logger.error(f"حدث خطأ أثناء تحميل سلسلة الكتل: {e}")
            
            # إنشاء كتلة البداية (Genesis Block) في حالة الخطأ
            genesis_block = {
                'index': 0,
                'timestamp': time.time(),
                'transactions': [],
                'previous_hash': '0',
                'hash': self._calculate_hash(0, time.time(), [], '0'),
                'nonce': 0
            }
            
            return [genesis_block]
    
    def _save_blockchain(self, blockchain: List[Dict[str, Any]]) -> None:
        """
        حفظ سلسلة الكتل إلى الملف
        
        المعلمات:
            blockchain: سلسلة الكتل
        """
        try:
            with open(self.blockchain_file, 'w', encoding='utf-8') as f:
                json.dump(blockchain, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"حدث خطأ أثناء حفظ سلسلة الكتل: {e}")
    
    def _calculate_hash(self, index: int, timestamp: float, transactions: List[Dict[str, Any]], previous_hash: str, nonce: int = 0) -> str:
        """
        حساب هاش الكتلة
        
        المعلمات:
            index: مؤشر الكتلة
            timestamp: الطابع الزمني
            transactions: المعاملات
            previous_hash: هاش الكتلة السابقة
            nonce: رقم مستخدم مرة واحدة
            
        الإرجاع:
            هاش الكتلة
        """
        block_string = json.dumps({
            'index': index,
            'timestamp': timestamp,
            'transactions': transactions,
            'previous_hash': previous_hash,
            'nonce': nonce
        }, sort_keys=True)
        
        return hashlib.sha256(block_string.encode()).hexdigest()
    
    def _mine_block(self, index: int, timestamp: float, transactions: List[Dict[str, Any]], previous_hash: str, difficulty: int = 2) -> Dict[str, Any]:
        """
        تعدين كتلة جديدة
        
        المعلمات:
            index: مؤشر الكتلة
            timestamp: الطابع الزمني
            transactions: المعاملات
            previous_hash: هاش الكتلة السابقة
            difficulty: صعوبة التعدين
            
        الإرجاع:
            الكتلة الجديدة
        """
        nonce = 0
        prefix = '0' * difficulty
        
        while True:
            hash_value = self._calculate_hash(index, timestamp, transactions, previous_hash, nonce)
            
            if hash_value.startswith(prefix):
                return {
                    'index': index,
                    'timestamp': timestamp,
                    'transactions': transactions,
                    'previous_hash': previous_hash,
                    'hash': hash_value,
                    'nonce': nonce
                }
            
            nonce += 1
    
    def _is_valid_chain(self, chain: List[Dict[str, Any]]) -> bool:
        """
        التحقق من صحة سلسلة الكتل
        
        المعلمات:
            chain: سلسلة الكتل
            
        الإرجاع:
            True إذا كانت السلسلة صحيحة، False خلاف ذلك
        """
        for i in range(1, len(chain)):
            current_block = chain[i]
            previous_block = chain[i - 1]
            
            # التحقق من صحة الهاش
            if current_block['previous_hash'] != previous_block['hash']:
                return False
            
            # التحقق من صحة هاش الكتلة الحالية
            if current_block['hash'] != self._calculate_hash(
                current_block['index'],
                current_block['timestamp'],
                current_block['transactions'],
                current_block['previous_hash'],
                current_block['nonce']
            ):
                return False
        
        return True
    
    def add_transaction(self, transaction_data: Dict[str, Any]) -> str:
        """
        إضافة معاملة جديدة
        
        المعلمات:
            transaction_data: بيانات المعاملة
            
        الإرجاع:
            معرف المعاملة
        """
        # إنشاء معرف للمعاملة
        transaction_id = str(uuid.uuid4())
        
        # إنشاء المعاملة
        transaction = {
            'id': transaction_id,
            'timestamp': time.time(),
            'data': transaction_data,
            'signature': self._sign_data(transaction_data)
        }
        
        # إضافة المعاملة إلى الكتلة الحالية
        last_block = self.blockchain[-1]
        new_block_index = last_block['index'] + 1
        new_block_timestamp = time.time()
        new_block_transactions = last_block['transactions'] + [transaction]
        
        # إذا وصل عدد المعاملات إلى 10، أو مر وقت كافٍ، قم بتعدين كتلة جديدة
        if len(new_block_transactions) >= 10 or (new_block_timestamp - last_block['timestamp']) > 600:  # 10 دقائق
            # تعدين كتلة جديدة
            new_block = self._mine_block(
                new_block_index,
                new_block_timestamp,
                new_block_transactions,
                last_block['hash']
            )
            
            # إضافة الكتلة الجديدة إلى سلسلة الكتل
            self.blockchain.append(new_block)
            
            # حفظ سلسلة الكتل
            self._save_blockchain(self.blockchain)
        else:
            # تحديث الكتلة الحالية
            last_block['transactions'] = new_block_transactions
            
            # حفظ سلسلة الكتل
            self._save_blockchain(self.blockchain)
        
        return transaction_id
    
    def _sign_data(self, data: Dict[str, Any]) -> str:
        """
        توقيع البيانات
        
        المعلمات:
            data: البيانات المراد توقيعها
            
        الإرجاع:
            التوقيع
        """
        data_string = json.dumps(data, sort_keys=True)
        signature = hmac.new(
            self.secret_key.encode(),
            data_string.encode(),
            hashlib.sha256
        ).digest()
        
        return base64.b64encode(signature).decode()
    
    def _verify_signature(self, data: Dict[str, Any], signature: str) -> bool:
        """
        التحقق من صحة التوقيع
        
        المعلمات:
            data: البيانات
            signature: التوقيع
            
        الإرجاع:
            True إذا كان التوقيع صحيحاً، False خلاف ذلك
        """
        data_string = json.dumps(data, sort_keys=True)
        expected_signature = hmac.new(
            self.secret_key.encode(),
            data_string.encode(),
            hashlib.sha256
        ).digest()
        
        actual_signature = base64.b64decode(signature)
        
        return hmac.compare_digest(expected_signature, actual_signature)
    
    def issue_certificate(self, student_id: str, course_id: str, certificate_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        إصدار شهادة موثقة
        
        المعلمات:
            student_id: معرف الطالب
            course_id: معرف الدورة
            certificate_data: بيانات الشهادة
            
        الإرجاع:
            بيانات الشهادة مع معرف المعاملة
        """
        # إنشاء بيانات المعاملة
        transaction_data = {
            'type': 'certificate',
            'student_id': student_id,
            'course_id': course_id,
            'certificate_data': certificate_data,
            'issuer': 'EduverseAI - قلعة BTEC',
            'issue_date': time.time()
        }
        
        # إضافة المعاملة
        transaction_id = self.add_transaction(transaction_data)
        
        # إنشاء رمز التحقق
        verification_code = hashlib.sha256(f"{transaction_id}:{student_id}:{course_id}".encode()).hexdigest()[:8].upper()
        
        return {
            'transaction_id': transaction_id,
            'verification_code': verification_code,
            'certificate_data': certificate_data,
            'issue_date': transaction_data['issue_date']
        }
    
    def issue_badge(self, student_id: str, badge_id: str, badge_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        إصدار وسام موثق
        
        المعلمات:
            student_id: معرف الطالب
            badge_id: معرف الوسام
            badge_data: بيانات الوسام
            
        الإرجاع:
            بيانات الوسام مع معرف المعاملة
        """
        # إنشاء بيانات المعاملة
        transaction_data = {
            'type': 'badge',
            'student_id': student_id,
            'badge_id': badge_id,
            'badge_data': badge_data,
            'issuer': 'EduverseAI - قلعة BTEC',
            'issue_date': time.time()
        }
        
        # إضافة المعاملة
        transaction_id = self.add_transaction(transaction_data)
        
        # إنشاء رمز التحقق
        verification_code = hashlib.sha256(f"{transaction_id}:{student_id}:{badge_id}".encode()).hexdigest()[:8].upper()
        
        return {
            'transaction_id': transaction_id,
            'verification_code': verification_code,
            'badge_data': badge_data,
            'issue_date': transaction_data['issue_date']
        }
    
    def verify_certificate(self, transaction_id: str, verification_code: str) -> Dict[str, Any]:
        """
        التحقق من صحة الشهادة
        
        المعلمات:
            transaction_id: معرف المعاملة
            verification_code: رمز التحقق
            
        الإرجاع:
            نتيجة التحقق
        """
        # البحث عن المعاملة
        transaction = self._find_transaction(transaction_id)
        
        if transaction is None:
            return {
                'valid': False,
                'message': 'لم يتم العثور على المعاملة'
            }
        
        # التحقق من نوع المعاملة
        if transaction['data']['type'] != 'certificate':
            return {
                'valid': False,
                'message': 'المعاملة ليست شهادة'
            }
        
        # التحقق من صحة التوقيع
        if not self._verify_signature(transaction['data'], transaction['signature']):
            return {
                'valid': False,
                'message': 'التوقيع غير صحيح'
            }
        
        # التحقق من رمز التحقق
        student_id = transaction['data']['student_id']
        course_id = transaction['data']['course_id']
        expected_verification_code = hashlib.sha256(f"{transaction_id}:{student_id}:{course_id}".encode()).hexdigest()[:8].upper()
        
        if verification_code != expected_verification_code:
            return {
                'valid': False,
                'message': 'رمز التحقق غير صحيح'
            }
        
        return {
            'valid': True,
            'message': 'الشهادة صحيحة',
            'certificate_data': transaction['data']['certificate_data'],
            'issue_date': transaction['data']['issue_date'],
            'student_id': student_id,
            'course_id': course_id
        }
    
    def verify_badge(self, transaction_id: str, verification_code: str) -> Dict[str, Any]:
        """
        التحقق من صحة الوسام
        
        المعلمات:
            transaction_id: معرف المعاملة
            verification_code: رمز التحقق
            
        الإرجاع:
            نتيجة التحقق
        """
        # البحث عن المعاملة
        transaction = self._find_transaction(transaction_id)
        
        if transaction is None:
            return {
                'valid': False,
                'message': 'لم يتم العثور على المعاملة'
            }
        
        # التحقق من نوع المعاملة
        if transaction['data']['type'] != 'badge':
            return {
                'valid': False,
                'message': 'المعاملة ليست وساماً'
            }
        
        # التحقق من صحة التوقيع
        if not self._verify_signature(transaction['data'], transaction['signature']):
            return {
                'valid': False,
                'message': 'التوقيع غير صحيح'
            }
        
        # التحقق من رمز التحقق
        student_id = transaction['data']['student_id']
        badge_id = transaction['data']['badge_id']
        expected_verification_code = hashlib.sha256(f"{transaction_id}:{student_id}:{badge_id}".encode()).hexdigest()[:8].upper()
        
        if verification_code != expected_verification_code:
            return {
                'valid': False,
                'message': 'رمز التحقق غير صحيح'
            }
        
        return {
            'valid': True,
            'message': 'الوسام صحيح',
            'badge_data': transaction['data']['badge_data'],
            'issue_date': transaction['data']['issue_date'],
            'student_id': student_id,
            'badge_id': badge_id
        }
    
    def _find_transaction(self, transaction_id: str) -> Optional[Dict[str, Any]]:
        """
        البحث عن معاملة
        
        المعلمات:
            transaction_id: معرف المعاملة
            
        الإرجاع:
            المعاملة إذا تم العثور عليها، None خلاف ذلك
        """
        for block in self.blockchain:
            for transaction in block['transactions']:
                if transaction.get('id') == transaction_id:
                    return transaction
        
        return None
    
    def get_student_certificates(self, student_id: str) -> List[Dict[str, Any]]:
        """
        الحصول على شهادات الطالب
        
        المعلمات:
            student_id: معرف الطالب
            
        الإرجاع:
            قائمة بشهادات الطالب
        """
        certificates = []
        
        for block in self.blockchain:
            for transaction in block['transactions']:
                if (transaction.get('data', {}).get('type') == 'certificate' and
                    transaction.get('data', {}).get('student_id') == student_id):
                    
                    # إنشاء رمز التحقق
                    verification_code = hashlib.sha256(
                        f"{transaction['id']}:{student_id}:{transaction['data']['course_id']}".encode()
                    ).hexdigest()[:8].upper()
                    
                    certificates.append({
                        'transaction_id': transaction['id'],
                        'verification_code': verification_code,
                        'certificate_data': transaction['data']['certificate_data'],
                        'issue_date': transaction['data']['issue_date'],
                        'course_id': transaction['data']['course_id']
                    })
        
        return certificates
    
    def get_student_badges(self, student_id: str) -> List[Dict[str, Any]]:
        """
        الحصول على أوسمة الطالب
        
        المعلمات:
            student_id: معرف الطالب
            
        الإرجاع:
            قائمة بأوسمة الطالب
        """
        badges = []
        
        for block in self.blockchain:
            for transaction in block['transactions']:
                if (transaction.get('data', {}).get('type') == 'badge' and
                    transaction.get('data', {}).get('student_id') == student_id):
                    
                    # إنشاء رمز التحقق
                    verification_code = hashlib.sha256(
                        f"{transaction['id']}:{student_id}:{transaction['data']['badge_id']}".encode()
                    ).hexdigest()[:8].upper()
                    
                    badges.append({
                        'transaction_id': transaction['id'],
                        'verification_code': verification_code,
                        'badge_data': transaction['data']['badge_data'],
                        'issue_date': transaction['data']['issue_date'],
                        'badge_id': transaction['data']['badge_id']
                    })
        
        return badges

# إنشاء نسخة واحدة من الخدمة للاستخدام في جميع أنحاء التطبيق
blockchain_service = None

def get_blockchain_service(data_dir: Optional[str] = None) -> BlockchainService:
    """
    الحصول على نسخة من خدمة البلوكتشين (نمط Singleton)
    
    المعلمات:
        data_dir: مجلد تخزين بيانات البلوكتشين
        
    الإرجاع:
        نسخة من خدمة البلوكتشين
    """
    global blockchain_service
    
    if blockchain_service is None:
        blockchain_service = BlockchainService(data_dir)
    
    return blockchain_service

