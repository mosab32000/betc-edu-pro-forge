#!/usr/bin/env python3
"""
سكربت لإنشاء بيانات اختبار للمنصة

يقوم هذا السكربت بإنشاء بيانات اختبار للمنصة، بما في ذلك المستخدمين والمهام التعليمية
وتجارب التعلم الغامرة والأوسمة.

كيفية الاستخدام:
1. قم بتشغيل السكربت: python generate_test_data.py
"""

import json
import random
import uuid
import os
import sys
import hashlib
import datetime

# عدد العناصر المراد إنشاؤها
NUM_STUDENTS = 1000
NUM_TEACHERS = 200
NUM_ADMINS = 50
NUM_TASKS = 100
NUM_XR_EXPERIENCES = 50
NUM_BADGES = 30

def generate_password_hash(password):
    """إنشاء تجزئة لكلمة المرور"""
    return hashlib.sha256(password.encode()).hexdigest()

def generate_users():
    """إنشاء بيانات المستخدمين"""
    users = []
    
    # إنشاء الطلاب
    for i in range(1, NUM_STUDENTS + 1):
        user_id = str(uuid.uuid4())
        username = f"student_{i}"
        password_hash = generate_password_hash("password123")
        
        users.append({
            "id": user_id,
            "username": username,
            "password_hash": password_hash,
            "email": f"{username}@example.com",
            "full_name": f"طالب {i}",
            "role": "student",
            "created_at": (datetime.datetime.now() - datetime.timedelta(days=random.randint(1, 365))).isoformat(),
            "last_login": (datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 30))).isoformat(),
            "profile": {
                "avatar": f"https://i.pravatar.cc/150?u={username}",
                "bio": f"أنا طالب رقم {i} في منصة EduverseAI - قلعة BTEC",
                "grade": random.choice(["الصف العاشر", "الصف الحادي عشر", "الصف الثاني عشر"]),
                "interests": random.sample(["رياضيات", "علوم", "لغة عربية", "لغة إنجليزية", "تاريخ", "جغرافيا", "فيزياء", "كيمياء", "أحياء", "حاسوب"], k=random.randint(2, 5))
            }
        })
    
    # إنشاء المعلمين
    for i in range(1, NUM_TEACHERS + 1):
        user_id = str(uuid.uuid4())
        username = f"teacher_{i}"
        password_hash = generate_password_hash("password123")
        
        users.append({
            "id": user_id,
            "username": username,
            "password_hash": password_hash,
            "email": f"{username}@example.com",
            "full_name": f"معلم {i}",
            "role": "teacher",
            "created_at": (datetime.datetime.now() - datetime.timedelta(days=random.randint(1, 365))).isoformat(),
            "last_login": (datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 30))).isoformat(),
            "profile": {
                "avatar": f"https://i.pravatar.cc/150?u={username}",
                "bio": f"أنا معلم رقم {i} في منصة EduverseAI - قلعة BTEC",
                "subjects": random.sample(["رياضيات", "علوم", "لغة عربية", "لغة إنجليزية", "تاريخ", "جغرافيا", "فيزياء", "كيمياء", "أحياء", "حاسوب"], k=random.randint(1, 3)),
                "years_of_experience": random.randint(1, 20)
            }
        })
    
    # إنشاء المشرفين
    for i in range(1, NUM_ADMINS + 1):
        user_id = str(uuid.uuid4())
        username = f"admin_{i}"
        password_hash = generate_password_hash("password123")
        
        users.append({
            "id": user_id,
            "username": username,
            "password_hash": password_hash,
            "email": f"{username}@example.com",
            "full_name": f"مشرف {i}",
            "role": "admin",
            "created_at": (datetime.datetime.now() - datetime.timedelta(days=random.randint(1, 365))).isoformat(),
            "last_login": (datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 30))).isoformat(),
            "profile": {
                "avatar": f"https://i.pravatar.cc/150?u={username}",
                "bio": f"أنا مشرف رقم {i} في منصة EduverseAI - قلعة BTEC",
                "department": random.choice(["إدارة المنصة", "الدعم الفني", "تطوير المحتوى", "ضمان الجودة"]),
                "permissions": ["إدارة المستخدمين", "إدارة المحتوى", "إدارة النظام"]
            }
        })
    
    return users

def generate_tasks():
    """إنشاء بيانات المهام التعليمية"""
    tasks = []
    
    subjects = ["رياضيات", "علوم", "لغة عربية", "لغة إنجليزية", "تاريخ", "جغرافيا", "فيزياء", "كيمياء", "أحياء", "حاسوب"]
    
    for i in range(1, NUM_TASKS + 1):
        task_id = f"task_{i}"
        subject = random.choice(subjects)
        
        tasks.append({
            "id": task_id,
            "title": f"مهمة {subject} {i}",
            "description": f"هذه مهمة في مادة {subject} رقم {i}. يجب على الطالب إكمال المهمة وفقًا للمعايير المحددة.",
            "subject": subject,
            "created_at": (datetime.datetime.now() - datetime.timedelta(days=random.randint(1, 90))).isoformat(),
            "due_date": (datetime.datetime.now() + datetime.timedelta(days=random.randint(1, 30))).isoformat(),
            "created_by": f"teacher_{random.randint(1, NUM_TEACHERS)}",
            "criteria": [
                {"name": "الدقة", "weight": 30},
                {"name": "الشمولية", "weight": 30},
                {"name": "الإبداع", "weight": 20},
                {"name": "التنظيم", "weight": 20}
            ],
            "resources": [
                {"type": "document", "url": f"https://example.com/resources/doc_{i}_1.pdf", "title": f"مستند {i} - 1"},
                {"type": "video", "url": f"https://example.com/resources/video_{i}_1.mp4", "title": f"فيديو {i} - 1"},
                {"type": "link", "url": f"https://example.com/resources/link_{i}_1", "title": f"رابط {i} - 1"}
            ],
            "difficulty": random.choice(["سهل", "متوسط", "متقدم"]),
            "estimated_time": random.randint(30, 180),  # بالدقائق
            "tags": [subject, f"مستوى_{random.choice(['أول', 'ثاني', 'ثالث'])}", f"فصل_{random.choice(['أول', 'ثاني'])}"]
        })
    
    return tasks

def generate_xr_experiences():
    """إنشاء بيانات تجارب التعلم الغامرة"""
    xr_experiences = []
    
    subjects = ["رياضيات", "علوم", "لغة عربية", "لغة إنجليزية", "تاريخ", "جغرافيا", "فيزياء", "كيمياء", "أحياء", "حاسوب"]
    xr_types = ["ar", "vr", "mr"]
    
    for i in range(1, NUM_XR_EXPERIENCES + 1):
        xr_id = f"xr_{i}"
        subject = random.choice(subjects)
        xr_type = random.choice(xr_types)
        
        xr_experiences.append({
            "id": xr_id,
            "title": f"تجربة {subject} {i}",
            "description": f"هذه تجربة تعلم غامرة في مادة {subject} رقم {i}. استمتع بتجربة تعليمية فريدة.",
            "subject": subject,
            "type": xr_type,
            "created_at": (datetime.datetime.now() - datetime.timedelta(days=random.randint(1, 90))).isoformat(),
            "created_by": f"teacher_{random.randint(1, NUM_TEACHERS)}",
            "difficulty": random.choice(["سهل", "متوسط", "متقدم"]),
            "duration": random.randint(15, 90),  # بالدقائق
            "tags": [subject, xr_type, "تعليم"],
            "requirements": {
                "device": "هاتف ذكي أو جهاز لوحي",
                "os": "Android 8.0+ أو iOS 12.0+",
                "camera": True,
                "storage": "500MB"
            },
            "preview_image": f"https://example.com/xr/preview_{i}.jpg",
            "download_url": f"https://example.com/xr/download_{i}.zip"
        })
    
    return xr_experiences

def generate_badges():
    """إنشاء بيانات الأوسمة"""
    badges = []
    
    badge_categories = ["إنجاز", "مهارة", "مشاركة", "إبداع", "تعاون"]
    
    for i in range(1, NUM_BADGES + 1):
        badge_id = f"badge_{i}"
        category = random.choice(badge_categories)
        
        badges.append({
            "id": badge_id,
            "title": f"وسام {category} {i}",
            "description": f"هذا وسام {category} رقم {i}. يتم منحه للطلاب الذين يحققون إنجازًا متميزًا.",
            "category": category,
            "created_at": (datetime.datetime.now() - datetime.timedelta(days=random.randint(1, 90))).isoformat(),
            "created_by": f"admin_{random.randint(1, NUM_ADMINS)}",
            "image_url": f"https://example.com/badges/badge_{i}.png",
            "criteria": {
                "type": random.choice(["task_completion", "xr_completion", "login_streak", "participation"]),
                "threshold": random.randint(1, 10),
                "description": f"يجب على الطالب تحقيق {random.randint(1, 10)} نقاط في فئة {category}"
            },
            "points": random.randint(10, 100),
            "rarity": random.choice(["شائع", "غير شائع", "نادر", "أسطوري"])
        })
    
    return badges

def generate_assessments():
    """إنشاء بيانات التقييمات"""
    assessments = []
    
    for i in range(1, 500):
        assessment_id = f"assessment_{i}"
        task_id = f"task_{random.randint(1, NUM_TASKS)}"
        student_id = f"student_{random.randint(1, NUM_STUDENTS)}"
        
        # تحديد حالة التقييم
        status = random.choice(["pending", "in_progress", "completed"])
        
        # إنشاء بيانات التقييم
        assessment = {
            "id": assessment_id,
            "task_id": task_id,
            "student_id": student_id,
            "content": f"هذه هي إجابتي على المهمة {task_id}. أتمنى أن تكون صحيحة.",
            "attachments": [
                {"type": "document", "url": f"https://example.com/assessments/doc_{i}_1.pdf", "title": f"مستند {i} - 1"},
                {"type": "image", "url": f"https://example.com/assessments/img_{i}_1.jpg", "title": f"صورة {i} - 1"}
            ],
            "submitted_at": (datetime.datetime.now() - datetime.timedelta(days=random.randint(1, 30))).isoformat(),
            "status": status
        }
        
        # إضافة بيانات التقييم إذا كانت الحالة "completed"
        if status == "completed":
            assessment["evaluated_at"] = (datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 7))).isoformat()
            assessment["evaluated_by"] = f"teacher_{random.randint(1, NUM_TEACHERS)}"
            assessment["score"] = random.randint(60, 100)
            assessment["feedback"] = f"هذه تغذية راجعة على التقييم {assessment_id}. هناك بعض النقاط القوية وبعض النقاط التي تحتاج إلى تحسين."
            assessment["ai_feedback"] = {
                "strengths": [
                    "فهم جيد للموضوع",
                    "تنظيم منطقي للأفكار",
                    "استخدام مناسب للمصطلحات"
                ],
                "areas_for_improvement": [
                    "يمكن تعزيز الأمثلة التوضيحية",
                    "تحتاج بعض الأفكار إلى توضيح إضافي",
                    "يمكن تحسين الصياغة في بعض الفقرات"
                ],
                "recommendations": [
                    "مراجعة المصادر الإضافية المقترحة",
                    "التركيز على تطبيق المفاهيم في سياقات مختلفة",
                    "ممارسة المزيد من التمارين العملية"
                ]
            }
        
        assessments.append(assessment)
    
    return assessments

def generate_user_progress():
    """إنشاء بيانات تقدم المستخدمين"""
    user_progress = []
    
    for i in range(1, 1000):
        student_id = f"student_{random.randint(1, NUM_STUDENTS)}"
        
        # تقدم المستخدم في تجربة XR
        if random.random() < 0.7:  # 70% احتمالية وجود تقدم في تجربة XR
            xr_id = f"xr_{random.randint(1, NUM_XR_EXPERIENCES)}"
            
            user_progress.append({
                "id": f"xr_progress_{i}",
                "user_id": student_id,
                "xr_id": xr_id,
                "progress": random.randint(10, 100),
                "completed": random.random() < 0.5,  # 50% احتمالية الإكمال
                "score": random.randint(0, 100),
                "time_spent": random.randint(60, 3600),  # بالثواني
                "last_accessed": (datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 30))).isoformat()
            })
        
        # أوسمة المستخدم
        if random.random() < 0.5:  # 50% احتمالية وجود وسام
            badge_id = f"badge_{random.randint(1, NUM_BADGES)}"
            
            user_progress.append({
                "id": f"badge_award_{i}",
                "user_id": student_id,
                "badge_id": badge_id,
                "awarded_at": (datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 90))).isoformat(),
                "awarded_by": f"teacher_{random.randint(1, NUM_TEACHERS)}",
                "blockchain_hash": hashlib.sha256(f"{student_id}_{badge_id}_{random.randint(1, 1000000)}".encode()).hexdigest()
            })
    
    return user_progress

def main():
    """الدالة الرئيسية"""
    print("إنشاء بيانات اختبار للمنصة...")
    
    # إنشاء مجلد للبيانات
    data_dir = "performance_tests/test_data"
    os.makedirs(data_dir, exist_ok=True)
    
    # إنشاء البيانات
    users = generate_users()
    tasks = generate_tasks()
    xr_experiences = generate_xr_experiences()
    badges = generate_badges()
    assessments = generate_assessments()
    user_progress = generate_user_progress()
    
    # حفظ البيانات في ملفات JSON
    with open(f"{data_dir}/users.json", "w", encoding="utf-8") as f:
        json.dump(users, f, ensure_ascii=False, indent=2)
    
    with open(f"{data_dir}/tasks.json", "w", encoding="utf-8") as f:
        json.dump(tasks, f, ensure_ascii=False, indent=2)
    
    with open(f"{data_dir}/xr_experiences.json", "w", encoding="utf-8") as f:
        json.dump(xr_experiences, f, ensure_ascii=False, indent=2)
    
    with open(f"{data_dir}/badges.json", "w", encoding="utf-8") as f:
        json.dump(badges, f, ensure_ascii=False, indent=2)
    
    with open(f"{data_dir}/assessments.json", "w", encoding="utf-8") as f:
        json.dump(assessments, f, ensure_ascii=False, indent=2)
    
    with open(f"{data_dir}/user_progress.json", "w", encoding="utf-8") as f:
        json.dump(user_progress, f, ensure_ascii=False, indent=2)
    
    print(f"تم إنشاء البيانات بنجاح في المجلد: {data_dir}")
    print(f"عدد المستخدمين: {len(users)}")
    print(f"عدد المهام: {len(tasks)}")
    print(f"عدد تجارب التعلم الغامرة: {len(xr_experiences)}")
    print(f"عدد الأوسمة: {len(badges)}")
    print(f"عدد التقييمات: {len(assessments)}")
    print(f"عدد سجلات تقدم المستخدمين: {len(user_progress)}")

if __name__ == "__main__":
    main()

