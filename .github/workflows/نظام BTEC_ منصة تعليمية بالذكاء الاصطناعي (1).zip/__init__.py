"""
حزمة النماذج لمنصة EduverseAI - قلعة BTEC
"""
from src.models.db import db
from src.models.user import User
from src.models.task import Task
from src.models.assessment import Assessment
from src.models.badge import Badge, UserBadge
from src.models.xr_experience import XRExperience, UserXRExperience
from src.models.llama_model import llama_model
from src.models.blockchain import blockchain_manager

__all__ = [
    'db',
    'User',
    'Task',
    'Assessment',
    'Badge',
    'UserBadge',
    'XRExperience',
    'UserXRExperience',
    'llama_model',
    'blockchain_manager'
]

