"""
نموذج التقييم والتغذية الراجعة في منصة EduverseAI - قلعة BTEC
"""
from datetime import datetime
from bson import ObjectId

class Assessment:
    """
    نموذج التقييم والتغذية الراجعة في المنصة
    """
    def __init__(self, task_id, user_id, answer, status="submitted", score=None, 
                 feedback=None, ai_feedback=None, blockchain_verification=None,
                 submitted_at=None, evaluated_at=None, _id=None):
        """
        تهيئة كائن التقييم
        
        المعلمات:
            task_id (ObjectId): معرف المهمة
            user_id (ObjectId): معرف المستخدم
            answer (str): إجابة المستخدم
            status (str): حالة التقييم (submitted, evaluating, completed)
            score (int): الدرجة المكتسبة
            feedback (str): التغذية الراجعة من المعلم
            ai_feedback (dict): التغذية الراجعة من الذكاء الاصطناعي
            blockchain_verification (dict): معلومات التحقق من البلوكتشين
            submitted_at (datetime): تاريخ تقديم الإجابة
            evaluated_at (datetime): تاريخ التقييم
            _id (ObjectId): معرف التقييم في قاعدة البيانات
        """
        self._id = _id if _id else ObjectId()
        self.task_id = task_id
        self.user_id = user_id
        self.answer = answer
        self.status = status
        self.score = score
        self.feedback = feedback
        self.ai_feedback = ai_feedback if ai_feedback else {}
        self.blockchain_verification = blockchain_verification if blockchain_verification else {}
        self.submitted_at = submitted_at if submitted_at else datetime.utcnow()
        self.evaluated_at = evaluated_at
        
        # بيانات إضافية للتقييم
        self.criteria_scores = {}  # درجات معايير التقييم المختلفة
        self.time_spent = 0  # الوقت المستغرق في الإجابة بالدقائق
        self.revision_history = []  # تاريخ المراجعات
        
    def to_dict(self):
        """
        تحويل كائن التقييم إلى قاموس
        
        العائد:
            dict: قاموس يمثل التقييم
        """
        return {
            "_id": str(self._id),
            "task_id": str(self.task_id),
            "user_id": str(self.user_id),
            "answer": self.answer,
            "status": self.status,
            "score": self.score,
            "feedback": self.feedback,
            "ai_feedback": self.ai_feedback,
            "blockchain_verification": self.blockchain_verification,
            "submitted_at": self.submitted_at.isoformat(),
            "evaluated_at": self.evaluated_at.isoformat() if self.evaluated_at else None,
            "criteria_scores": self.criteria_scores,
            "time_spent": self.time_spent,
            "revision_history": self.revision_history
        }
    
    @classmethod
    def from_dict(cls, data):
        """
        إنشاء كائن تقييم من قاموس
        
        المعلمات:
            data (dict): قاموس يحتوي على بيانات التقييم
            
        العائد:
            Assessment: كائن التقييم
        """
        _id = ObjectId(data["_id"]) if "_id" in data else None
        task_id = ObjectId(data["task_id"]) if "task_id" in data else None
        user_id = ObjectId(data["user_id"]) if "user_id" in data else None
        submitted_at = datetime.fromisoformat(data["submitted_at"]) if "submitted_at" in data else None
        evaluated_at = datetime.fromisoformat(data["evaluated_at"]) if "evaluated_at" in data and data["evaluated_at"] else None
        
        assessment = cls(
            task_id=task_id,
            user_id=user_id,
            answer=data.get("answer", ""),
            status=data.get("status", "submitted"),
            score=data.get("score"),
            feedback=data.get("feedback"),
            ai_feedback=data.get("ai_feedback", {}),
            blockchain_verification=data.get("blockchain_verification", {}),
            submitted_at=submitted_at,
            evaluated_at=evaluated_at,
            _id=_id
        )
        
        assessment.criteria_scores = data.get("criteria_scores", {})
        assessment.time_spent = data.get("time_spent", 0)
        assessment.revision_history = data.get("revision_history", [])
        
        return assessment

