"""
إدارة تكامل البلوكتشين لمنصة EduverseAI - قلعة BTEC
"""
import os
import json
import hashlib
import time
from typing import Dict, Any, List, Optional
from datetime import datetime
import threading
from dotenv import load_dotenv

# تحميل متغيرات البيئة
load_dotenv()

class BlockchainManager:
    """
    فئة إدارة تكامل البلوكتشين
    """
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        """
        تطبيق نمط Singleton لضمان وجود نسخة واحدة فقط من مدير البلوكتشين
        """
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super(BlockchainManager, cls).__new__(cls)
                    cls._instance._initialize()
        return cls._instance
    
    def _initialize(self):
        """
        تهيئة مدير البلوكتشين
        """
        self.blockchain_enabled = os.getenv("BLOCKCHAIN_ENABLED", "false").lower() == "true"
        self.blockchain_type = os.getenv("BLOCKCHAIN_TYPE", "simulated")
        self.blockchain_path = os.getenv("BLOCKCHAIN_PATH", "./data/blockchain")
        
        # إنشاء مجلد البلوكتشين إذا لم يكن موجوداً
        if self.blockchain_type == "simulated" and not os.path.exists(self.blockchain_path):
            os.makedirs(self.blockchain_path, exist_ok=True)
        
        # تحميل البلوكتشين المحاكى إذا كان موجوداً
        self.chain = []
        if self.blockchain_type == "simulated":
            self._load_simulated_blockchain()
        
        print(f"تم تهيئة مدير البلوكتشين. الحالة: {'مفعل' if self.blockchain_enabled else 'غير مفعل'}, النوع: {self.blockchain_type}")
    
    def _load_simulated_blockchain(self):
        """
        تحميل البلوكتشين المحاكى من الملف
        """
        blockchain_file = os.path.join(self.blockchain_path, "blockchain.json")
        if os.path.exists(blockchain_file):
            try:
                with open(blockchain_file, "r", encoding="utf-8") as f:
                    self.chain = json.load(f)
                print(f"تم تحميل البلوكتشين المحاكى. عدد الكتل: {len(self.chain)}")
            except Exception as e:
                print(f"فشل تحميل البلوكتشين المحاكى: {str(e)}")
                self.chain = []
        
        # إنشاء كتلة البداية إذا كانت السلسلة فارغة
        if not self.chain:
            genesis_block = {
                "index": 0,
                "timestamp": datetime.now().isoformat(),
                "data": {
                    "message": "كتلة البداية لمنصة EduverseAI - قلعة BTEC"
                },
                "previous_hash": "0" * 64,
                "hash": "0" * 64
            }
            self.chain.append(genesis_block)
            self._save_simulated_blockchain()
    
    def _save_simulated_blockchain(self):
        """
        حفظ البلوكتشين المحاكى إلى الملف
        """
        if self.blockchain_type == "simulated":
            blockchain_file = os.path.join(self.blockchain_path, "blockchain.json")
            try:
                with open(blockchain_file, "w", encoding="utf-8") as f:
                    json.dump(self.chain, f, ensure_ascii=False, indent=2)
            except Exception as e:
                print(f"فشل حفظ البلوكتشين المحاكى: {str(e)}")
    
    def _calculate_hash(self, block: Dict[str, Any]) -> str:
        """
        حساب تجزئة الكتلة
        
        المعلمات:
            block (Dict[str, Any]): الكتلة
            
        العائد:
            str: تجزئة الكتلة
        """
        # إنشاء نسخة من الكتلة بدون حقل التجزئة
        block_copy = block.copy()
        block_copy.pop("hash", None)
        
        # تحويل الكتلة إلى سلسلة JSON وحساب التجزئة
        block_string = json.dumps(block_copy, sort_keys=True)
        return hashlib.sha256(block_string.encode()).hexdigest()
    
    def _is_valid_block(self, block: Dict[str, Any], previous_block: Dict[str, Any]) -> bool:
        """
        التحقق من صحة الكتلة
        
        المعلمات:
            block (Dict[str, Any]): الكتلة
            previous_block (Dict[str, Any]): الكتلة السابقة
            
        العائد:
            bool: صحة الكتلة
        """
        # التحقق من الفهرس
        if block["index"] != previous_block["index"] + 1:
            return False
        
        # التحقق من تجزئة الكتلة السابقة
        if block["previous_hash"] != previous_block["hash"]:
            return False
        
        # التحقق من تجزئة الكتلة الحالية
        if block["hash"] != self._calculate_hash(block):
            return False
        
        return True
    
    def _is_valid_chain(self, chain: List[Dict[str, Any]]) -> bool:
        """
        التحقق من صحة السلسلة
        
        المعلمات:
            chain (List[Dict[str, Any]]): السلسلة
            
        العائد:
            bool: صحة السلسلة
        """
        # التحقق من كتلة البداية
        if len(chain) == 0:
            return False
        
        # التحقق من الكتل المتبقية
        for i in range(1, len(chain)):
            if not self._is_valid_block(chain[i], chain[i-1]):
                return False
        
        return True
    
    def add_block(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        إضافة كتلة جديدة إلى البلوكتشين
        
        المعلمات:
            data (Dict[str, Any]): بيانات الكتلة
            
        العائد:
            Dict[str, Any]: الكتلة المضافة
        """
        if not self.blockchain_enabled:
            return {
                "success": False,
                "message": "البلوكتشين غير مفعل",
                "block": None
            }
        
        # إنشاء كتلة جديدة
        previous_block = self.chain[-1]
        new_block = {
            "index": previous_block["index"] + 1,
            "timestamp": datetime.now().isoformat(),
            "data": data,
            "previous_hash": previous_block["hash"]
        }
        
        # حساب تجزئة الكتلة الجديدة
        new_block["hash"] = self._calculate_hash(new_block)
        
        # إضافة الكتلة إلى السلسلة
        self.chain.append(new_block)
        
        # حفظ البلوكتشين المحاكى
        if self.blockchain_type == "simulated":
            self._save_simulated_blockchain()
        
        return {
            "success": True,
            "message": "تمت إضافة الكتلة بنجاح",
            "block": new_block
        }
    
    def verify_data(self, data: Dict[str, Any], block_hash: Optional[str] = None) -> Dict[str, Any]:
        """
        التحقق من البيانات في البلوكتشين
        
        المعلمات:
            data (Dict[str, Any]): البيانات المراد التحقق منها
            block_hash (Optional[str]): تجزئة الكتلة المراد التحقق منها
            
        العائد:
            Dict[str, Any]: نتيجة التحقق
        """
        if not self.blockchain_enabled:
            return {
                "verified": False,
                "message": "البلوكتشين غير مفعل",
                "block": None
            }
        
        # البحث عن الكتلة المطلوبة
        target_block = None
        if block_hash:
            for block in self.chain:
                if block["hash"] == block_hash:
                    target_block = block
                    break
        else:
            # البحث عن البيانات في جميع الكتل
            for block in reversed(self.chain):
                # التحقق من تطابق البيانات الأساسية
                block_data = block["data"]
                match = True
                for key, value in data.items():
                    if key in block_data and block_data[key] != value:
                        match = False
                        break
                
                if match:
                    target_block = block
                    break
        
        if target_block:
            # التحقق من صحة الكتلة
            block_index = target_block["index"]
            if block_index > 0:
                previous_block = self.chain[block_index - 1]
                is_valid = self._is_valid_block(target_block, previous_block)
            else:
                # كتلة البداية
                is_valid = target_block["hash"] == self._calculate_hash(target_block)
            
            return {
                "verified": is_valid,
                "message": "تم التحقق من البيانات بنجاح" if is_valid else "فشل التحقق من البيانات",
                "block": target_block
            }
        else:
            return {
                "verified": False,
                "message": "لم يتم العثور على البيانات في البلوكتشين",
                "block": None
            }
    
    def get_chain(self) -> List[Dict[str, Any]]:
        """
        الحصول على سلسلة البلوكتشين
        
        العائد:
            List[Dict[str, Any]]: سلسلة البلوكتشين
        """
        return self.chain
    
    def get_block(self, block_hash: str) -> Optional[Dict[str, Any]]:
        """
        الحصول على كتلة محددة
        
        المعلمات:
            block_hash (str): تجزئة الكتلة
            
        العائد:
            Optional[Dict[str, Any]]: الكتلة المطلوبة
        """
        for block in self.chain:
            if block["hash"] == block_hash:
                return block
        return None
    
    def get_latest_block(self) -> Dict[str, Any]:
        """
        الحصول على آخر كتلة في السلسلة
        
        العائد:
            Dict[str, Any]: آخر كتلة
        """
        return self.chain[-1]
    
    def is_valid(self) -> bool:
        """
        التحقق من صحة البلوكتشين
        
        العائد:
            bool: صحة البلوكتشين
        """
        return self._is_valid_chain(self.chain)
    
    def record_assessment(self, assessment_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        تسجيل بيانات التقييم في البلوكتشين
        
        المعلمات:
            assessment_data (Dict[str, Any]): بيانات التقييم
            
        العائد:
            Dict[str, Any]: نتيجة التسجيل
        """
        # إنشاء بيانات الكتلة
        block_data = {
            "type": "assessment",
            "assessment_id": assessment_data.get("_id"),
            "task_id": assessment_data.get("task_id"),
            "user_id": assessment_data.get("user_id"),
            "score": assessment_data.get("score"),
            "submitted_at": assessment_data.get("submitted_at"),
            "evaluated_at": assessment_data.get("evaluated_at"),
            # حساب تجزئة الإجابة لتخزينها بدلاً من النص الكامل
            "answer_hash": hashlib.sha256(assessment_data.get("answer", "").encode()).hexdigest(),
            "timestamp": datetime.now().isoformat()
        }
        
        # إضافة الكتلة
        result = self.add_block(block_data)
        
        if result["success"]:
            return {
                "success": True,
                "message": "تم تسجيل التقييم في البلوكتشين بنجاح",
                "verification": {
                    "block_hash": result["block"]["hash"],
                    "timestamp": result["block"]["timestamp"],
                    "blockchain_type": self.blockchain_type
                }
            }
        else:
            return {
                "success": False,
                "message": result["message"],
                "verification": None
            }
    
    def record_badge(self, badge_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        تسجيل بيانات الوسام في البلوكتشين
        
        المعلمات:
            badge_data (Dict[str, Any]): بيانات الوسام
            
        العائد:
            Dict[str, Any]: نتيجة التسجيل
        """
        # إنشاء بيانات الكتلة
        block_data = {
            "type": "badge",
            "user_badge_id": badge_data.get("_id"),
            "user_id": badge_data.get("user_id"),
            "badge_id": badge_data.get("badge_id"),
            "earned_at": badge_data.get("earned_at"),
            "timestamp": datetime.now().isoformat()
        }
        
        # إضافة الكتلة
        result = self.add_block(block_data)
        
        if result["success"]:
            return {
                "success": True,
                "message": "تم تسجيل الوسام في البلوكتشين بنجاح",
                "verification": {
                    "block_hash": result["block"]["hash"],
                    "timestamp": result["block"]["timestamp"],
                    "blockchain_type": self.blockchain_type
                }
            }
        else:
            return {
                "success": False,
                "message": result["message"],
                "verification": None
            }


# إنشاء كائن مدير البلوكتشين للاستخدام في جميع أنحاء التطبيق
blockchain_manager = BlockchainManager()

# تصدير كائن مدير البلوكتشين
__all__ = ['blockchain_manager']

