"""
التطبيق الرئيسي لمنصة EduverseAI - قلعة BTEC
"""

import os
from flask import Flask
from flask_cors import CORS
from dotenv import load_dotenv
import logging

# تحميل متغيرات البيئة
load_dotenv()

# إعداد التسجيل
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_app(test_config=None):
    """
    إنشاء وتكوين تطبيق Flask
    
    المعلمات:
        test_config: تكوين الاختبار (اختياري)
        
    الإرجاع:
        تطبيق Flask
    """
    # إنشاء وتكوين التطبيق
    app = Flask(__name__, instance_relative_config=True)
    
    # تكوين التطبيق
    app.config.from_mapping(
        SECRET_KEY=os.environ.get('SECRET_KEY', 'dev'),
        DATABASE_URI=os.environ.get('DATABASE_URI', 'mongodb://localhost:27017/eduverse_btec'),
        LLAMA_MODEL_PATH=os.environ.get('LLAMA_MODEL_PATH', './models/llama-3-8b-instruct.Q4_K_M.gguf'),
        BLOCKCHAIN_NETWORK=os.environ.get('BLOCKCHAIN_NETWORK', 'testnet'),
        XR_DATA_DIR=os.environ.get('XR_DATA_DIR', './data/xr')
    )
    
    # تكوين CORS
    CORS(app)
    
    # تسجيل المسارات
    
    # مسارات المستخدمين
    from .routes.users import users_bp
    app.register_blueprint(users_bp)
    
    # مسارات المهام التعليمية
    from .routes.tasks import tasks_bp
    app.register_blueprint(tasks_bp)
    
    # مسارات التقييمات
    from .routes.assessments import assessments_bp
    app.register_blueprint(assessments_bp)
    
    # مسارات الأوسمة
    from .routes.badges import badges_bp
    app.register_blueprint(badges_bp)
    
    # مسارات تجارب التعلم الغامرة
    from .routes.xr import xr_bp
    app.register_blueprint(xr_bp)
    
    # مسارات الذكاء الاصطناعي
    from .routes.ai import ai_bp
    app.register_blueprint(ai_bp)
    
    # مسارات البلوكتشين
    from .routes.blockchain import blockchain_bp
    app.register_blueprint(blockchain_bp)
    
    # مسار الصحة
    @app.route('/health')
    def health():
        """
        فحص صحة التطبيق
        
        الإرجاع:
            حالة صحة التطبيق
        """
        return {
            'status': 'healthy',
            'version': '1.0.0',
            'name': 'EduverseAI - قلعة BTEC API'
        }
    
    return app

