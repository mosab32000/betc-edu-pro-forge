import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

// أيقونات
import { 
  Home, 
  BookOpen, 
  Award, 
  Cube, 
  Gamepad2, 
  MessageSquare, 
  BarChart3, 
  User, 
  LogOut, 
  Menu, 
  X,
  Sun,
  Moon
} from 'lucide-react';

/**
 * مكون التخطيط الرئيسي
 * @param {object} props - خصائص المكون
 * @returns {JSX.Element} - مكون التخطيط الرئيسي
 */
const MainLayout = ({ children }) => {
  const { user, logout, isAuthenticated } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  
  // التحقق من حالة المصادقة
  useEffect(() => {
    if (!isAuthenticated && !location.pathname.includes('/login') && !location.pathname.includes('/register')) {
      navigate('/login');
    }
  }, [isAuthenticated, location.pathname, navigate]);
  
  // تبديل وضع الظلام
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);
  
  // التحقق مما إذا كان الرابط نشطًا
  const isActive = (path) => {
    return location.pathname === path;
  };
  
  // عناصر القائمة الجانبية
  const sidebarItems = [
    { 
      title: 'الرئيسية', 
      path: '/', 
      icon: <Home className="w-5 h-5" /> 
    },
    { 
      title: 'قاعة المهام', 
      path: '/tasks', 
      icon: <BookOpen className="w-5 h-5" /> 
    },
    { 
      title: 'الأوسمة والإنجازات', 
      path: '/badges', 
      icon: <Award className="w-5 h-5" /> 
    },
    { 
      title: 'تجارب التعلم الغامرة', 
      path: '/xr-experiences', 
      icon: <Cube className="w-5 h-5" /> 
    },
    { 
      title: 'الألعاب التعليمية', 
      path: '/games', 
      icon: <Gamepad2 className="w-5 h-5" /> 
    },
    { 
      title: 'المساعد الذكي', 
      path: '/ai-assistant', 
      icon: <MessageSquare className="w-5 h-5" /> 
    }
  ];
  
  // إضافة عناصر خاصة بالمعلمين والمشرفين
  if (user && (user.role === 'teacher' || user.role === 'admin')) {
    sidebarItems.push({ 
      title: 'لوحة التحليلات', 
      path: '/analytics', 
      icon: <BarChart3 className="w-5 h-5" /> 
    });
  }
  
  // معالجة تسجيل الخروج
  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  return (
    <div className="min-h-screen bg-background rtl">
      {/* الشريط العلوي */}
      <header className="bg-primary text-primary-foreground shadow-md">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center">
            <button
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 rounded-md hover:bg-primary-foreground/10 md:hidden"
            >
              {isSidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            
            <Link to="/" className="flex items-center space-x-2 space-x-reverse">
              <img 
                src="/src/assets/images/eduverse-btec-logo.png" 
                alt="EduverseAI - قلعة BTEC" 
                className="h-10"
              />
            </Link>
          </div>
          
          <div className="flex items-center space-x-4 space-x-reverse">
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2 rounded-md hover:bg-primary-foreground/10"
            >
              {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            
            {isAuthenticated && (
              <div className="flex items-center space-x-2 space-x-reverse">
                <Link to="/profile" className="flex items-center space-x-2 space-x-reverse hover:bg-primary-foreground/10 p-2 rounded-md">
                  <div className="w-8 h-8 rounded-full bg-accent text-accent-foreground flex items-center justify-center">
                    {user?.first_name?.charAt(0) || user?.username?.charAt(0) || 'U'}
                  </div>
                  <span className="hidden md:inline">{user?.first_name || user?.username}</span>
                </Link>
              </div>
            )}
          </div>
        </div>
      </header>
      
      <div className="flex">
        {/* الشريط الجانبي */}
        <aside 
          className={`bg-sidebar text-sidebar-foreground w-64 fixed inset-y-0 pt-16 transition-transform duration-300 ease-in-out z-10 ${
            isSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
          }`}
        >
          <div className="p-4">
            <nav className="space-y-1">
              {sidebarItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center space-x-3 space-x-reverse px-4 py-3 rounded-md transition-colors ${
                    isActive(item.path)
                      ? 'bg-sidebar-primary text-sidebar-primary-foreground'
                      : 'hover:bg-sidebar-accent/10'
                  }`}
                  onClick={() => setIsSidebarOpen(false)}
                >
                  {item.icon}
                  <span>{item.title}</span>
                </Link>
              ))}
              
              <div className="pt-4 mt-4 border-t border-sidebar-border">
                <Link
                  to="/profile"
                  className={`flex items-center space-x-3 space-x-reverse px-4 py-3 rounded-md transition-colors ${
                    isActive('/profile')
                      ? 'bg-sidebar-primary text-sidebar-primary-foreground'
                      : 'hover:bg-sidebar-accent/10'
                  }`}
                  onClick={() => setIsSidebarOpen(false)}
                >
                  <User className="w-5 h-5" />
                  <span>الملف الشخصي</span>
                </Link>
                
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center space-x-3 space-x-reverse px-4 py-3 rounded-md transition-colors hover:bg-sidebar-accent/10 text-left"
                >
                  <LogOut className="w-5 h-5" />
                  <span>تسجيل الخروج</span>
                </button>
              </div>
            </nav>
          </div>
        </aside>
        
        {/* المحتوى الرئيسي */}
        <main className={`flex-1 transition-all duration-300 ${isSidebarOpen ? 'md:mr-64' : ''}`}>
          <div className="container mx-auto px-4 py-6 md:py-8">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default MainLayout;

