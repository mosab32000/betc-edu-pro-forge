"""
سكربت Locust لاختبار الأداء وقدرة التحمل لمنصة EduverseAI - قلعة BTEC

يقوم هذا السكربت بمحاكاة سلوك المستخدمين المختلفين (الطلاب والمعلمين والمشرفين)
واختبار قدرة المنصة على التعامل مع عدد كبير من المستخدمين المتزامنين.

كيفية الاستخدام:
1. تأكد من تشغيل خادم API
2. قم بتشغيل Locust: locust -f locustfile.py
3. افتح واجهة Locust في المتصفح: http://localhost:8089
"""

import json
import random
import time
import uuid
from locust import HttpUser, task, between, tag, events
from locust.exception import StopUser

# بيانات اختبار
TEST_USERS = {
    "students": [
        {"username": f"student_{i}", "password": "password123", "role": "student"} for i in range(1, 101)
    ],
    "teachers": [
        {"username": f"teacher_{i}", "password": "password123", "role": "teacher"} for i in range(1, 21)
    ],
    "admins": [
        {"username": f"admin_{i}", "password": "password123", "role": "admin"} for i in range(1, 6)
    ]
}

# قائمة بالمهام التعليمية للاختبار
TEST_TASKS = [
    {"id": "task_1", "title": "مهمة الرياضيات 1", "subject": "رياضيات"},
    {"id": "task_2", "title": "مهمة العلوم 1", "subject": "علوم"},
    {"id": "task_3", "title": "مهمة اللغة العربية 1", "subject": "لغة عربية"},
    {"id": "task_4", "title": "مهمة اللغة الإنجليزية 1", "subject": "لغة إنجليزية"},
    {"id": "task_5", "title": "مهمة التاريخ 1", "subject": "تاريخ"}
]

# قائمة بتجارب التعلم الغامرة للاختبار
TEST_XR_EXPERIENCES = [
    {"id": "ar_petra", "type": "ar"},
    {"id": "ar_human_anatomy", "type": "ar"},
    {"id": "vr_chemistry_lab", "type": "vr"},
    {"id": "vr_space_exploration", "type": "vr"},
    {"id": "mr_historical_jordan", "type": "mr"}
]

class StudentUser(HttpUser):
    """محاكاة سلوك الطالب"""
    
    wait_time = between(1, 5)  # وقت الانتظار بين المهام (بالثواني)
    weight = 70  # وزن هذا النوع من المستخدمين (70% من إجمالي المستخدمين)
    
    def on_start(self):
        """تسجيل الدخول عند بدء المحاكاة"""
        self.user_data = random.choice(TEST_USERS["students"])
        self.token = self.login()
        if not self.token:
            raise StopUser()
    
    def login(self):
        """تسجيل الدخول والحصول على رمز المصادقة"""
        response = self.client.post(
            "/api/users/login",
            json={
                "username": self.user_data["username"],
                "password": self.user_data["password"]
            }
        )
        
        if response.status_code == 200:
            return response.json().get("token")
        return None
    
    @tag("student", "home")
    @task(10)
    def view_home(self):
        """عرض الصفحة الرئيسية"""
        self.client.get(
            "/api/users/profile",
            headers={"Authorization": f"Bearer {self.token}"}
        )
    
    @tag("student", "tasks")
    @task(5)
    def view_tasks(self):
        """عرض المهام التعليمية"""
        self.client.get(
            "/api/tasks",
            headers={"Authorization": f"Bearer {self.token}"}
        )
    
    @tag("student", "task_details")
    @task(3)
    def view_task_details(self):
        """عرض تفاصيل مهمة تعليمية"""
        task = random.choice(TEST_TASKS)
        self.client.get(
            f"/api/tasks/{task['id']}",
            headers={"Authorization": f"Bearer {self.token}"}
        )
    
    @tag("student", "submit_assessment")
    @task(2)
    def submit_assessment(self):
        """تقديم تقييم لمهمة تعليمية"""
        task = random.choice(TEST_TASKS)
        self.client.post(
            "/api/assessments",
            headers={"Authorization": f"Bearer {self.token}"},
            json={
                "task_id": task["id"],
                "content": f"هذه هي إجابتي على المهمة {task['title']}. أتمنى أن تكون صحيحة.",
                "attachments": []
            }
        )
    
    @tag("student", "ai_assistant")
    @task(3)
    def use_ai_assistant(self):
        """استخدام المساعد الذكي"""
        subject = random.choice(["رياضيات", "علوم", "لغة عربية", "لغة إنجليزية", "تاريخ"])
        self.client.post(
            "/api/ai/chat",
            headers={"Authorization": f"Bearer {self.token}"},
            json={
                "message": f"أريد مساعدة في مادة {subject}",
                "context": {
                    "subject": subject,
                    "previous_messages": []
                }
            }
        )
    
    @tag("student", "xr_experience")
    @task(1)
    def use_xr_experience(self):
        """استخدام تجربة تعلم غامرة"""
        experience = random.choice(TEST_XR_EXPERIENCES)
        
        # عرض تفاصيل التجربة
        self.client.get(
            f"/api/xr/experience/{experience['id']}",
            headers={"Authorization": f"Bearer {self.token}"}
        )
        
        # تحديث تقدم المستخدم
        self.client.post(
            f"/api/xr/user-progress/{self.user_data['username']}/{experience['id']}",
            headers={"Authorization": f"Bearer {self.token}"},
            json={
                "progress": random.randint(10, 100),
                "completed": random.choice([True, False]),
                "score": random.randint(0, 100),
                "time_spent": random.randint(60, 3600)
            }
        )
    
    @tag("student", "badges")
    @task(1)
    def view_badges(self):
        """عرض الأوسمة"""
        self.client.get(
            f"/api/badges/user/{self.user_data['username']}",
            headers={"Authorization": f"Bearer {self.token}"}
        )

class TeacherUser(HttpUser):
    """محاكاة سلوك المعلم"""
    
    wait_time = between(2, 7)  # وقت الانتظار بين المهام (بالثواني)
    weight = 20  # وزن هذا النوع من المستخدمين (20% من إجمالي المستخدمين)
    
    def on_start(self):
        """تسجيل الدخول عند بدء المحاكاة"""
        self.user_data = random.choice(TEST_USERS["teachers"])
        self.token = self.login()
        if not self.token:
            raise StopUser()
    
    def login(self):
        """تسجيل الدخول والحصول على رمز المصادقة"""
        response = self.client.post(
            "/api/users/login",
            json={
                "username": self.user_data["username"],
                "password": self.user_data["password"]
            }
        )
        
        if response.status_code == 200:
            return response.json().get("token")
        return None
    
    @tag("teacher", "home")
    @task(10)
    def view_dashboard(self):
        """عرض لوحة التحكم"""
        self.client.get(
            "/api/users/profile",
            headers={"Authorization": f"Bearer {self.token}"}
        )
    
    @tag("teacher", "tasks")
    @task(5)
    def view_tasks(self):
        """عرض المهام التعليمية"""
        self.client.get(
            "/api/tasks",
            headers={"Authorization": f"Bearer {self.token}"}
        )
    
    @tag("teacher", "create_task")
    @task(2)
    def create_task(self):
        """إنشاء مهمة تعليمية جديدة"""
        subject = random.choice(["رياضيات", "علوم", "لغة عربية", "لغة إنجليزية", "تاريخ"])
        self.client.post(
            "/api/tasks",
            headers={"Authorization": f"Bearer {self.token}"},
            json={
                "title": f"مهمة {subject} جديدة",
                "description": f"هذه مهمة جديدة في مادة {subject}",
                "subject": subject,
                "due_date": (time.time() + 7 * 24 * 60 * 60) * 1000,  # بعد أسبوع
                "criteria": [
                    {"name": "الدقة", "weight": 30},
                    {"name": "الشمولية", "weight": 30},
                    {"name": "الإبداع", "weight": 20},
                    {"name": "التنظيم", "weight": 20}
                ]
            }
        )
    
    @tag("teacher", "review_assessment")
    @task(3)
    def review_assessment(self):
        """مراجعة تقييم طالب"""
        task = random.choice(TEST_TASKS)
        student = random.choice(TEST_USERS["students"])
        
        # الحصول على تقييمات المهمة
        response = self.client.get(
            f"/api/assessments/task/{task['id']}",
            headers={"Authorization": f"Bearer {self.token}"}
        )
        
        # إذا كان هناك تقييمات، قم بتحديث أحدها
        if response.status_code == 200 and response.json():
            assessment = response.json()[0]
            self.client.put(
                f"/api/assessments/{assessment['id']}",
                headers={"Authorization": f"Bearer {self.token}"},
                json={
                    "feedback": "هذه تغذية راجعة على التقييم",
                    "score": random.randint(60, 100),
                    "status": "completed"
                }
            )
    
    @tag("teacher", "analytics")
    @task(2)
    def view_analytics(self):
        """عرض التحليلات"""
        task = random.choice(TEST_TASKS)
        self.client.get(
            f"/api/analytics/task/{task['id']}",
            headers={"Authorization": f"Bearer {self.token}"}
        )
    
    @tag("teacher", "award_badge")
    @task(1)
    def award_badge(self):
        """منح وسام لطالب"""
        student = random.choice(TEST_USERS["students"])
        badge_id = f"badge_{random.randint(1, 10)}"
        
        self.client.post(
            f"/api/badges/award/{student['username']}/{badge_id}",
            headers={"Authorization": f"Bearer {self.token}"}
        )

class AdminUser(HttpUser):
    """محاكاة سلوك المشرف"""
    
    wait_time = between(3, 10)  # وقت الانتظار بين المهام (بالثواني)
    weight = 10  # وزن هذا النوع من المستخدمين (10% من إجمالي المستخدمين)
    
    def on_start(self):
        """تسجيل الدخول عند بدء المحاكاة"""
        self.user_data = random.choice(TEST_USERS["admins"])
        self.token = self.login()
        if not self.token:
            raise StopUser()
    
    def login(self):
        """تسجيل الدخول والحصول على رمز المصادقة"""
        response = self.client.post(
            "/api/users/login",
            json={
                "username": self.user_data["username"],
                "password": self.user_data["password"]
            }
        )
        
        if response.status_code == 200:
            return response.json().get("token")
        return None
    
    @tag("admin", "dashboard")
    @task(10)
    def view_admin_dashboard(self):
        """عرض لوحة تحكم المشرف"""
        self.client.get(
            "/api/admin/dashboard",
            headers={"Authorization": f"Bearer {self.token}"}
        )
    
    @tag("admin", "users")
    @task(5)
    def view_users(self):
        """عرض المستخدمين"""
        self.client.get(
            "/api/users",
            headers={"Authorization": f"Bearer {self.token}"}
        )
    
    @tag("admin", "create_user")
    @task(2)
    def create_user(self):
        """إنشاء مستخدم جديد"""
        role = random.choice(["student", "teacher", "admin"])
        username = f"{role}_{uuid.uuid4().hex[:8]}"
        
        self.client.post(
            "/api/users/register",
            headers={"Authorization": f"Bearer {self.token}"},
            json={
                "username": username,
                "password": "password123",
                "email": f"{username}@example.com",
                "full_name": f"اسم {username}",
                "role": role
            }
        )
    
    @tag("admin", "system_health")
    @task(3)
    def check_system_health(self):
        """فحص صحة النظام"""
        self.client.get(
            "/api/admin/system-health",
            headers={"Authorization": f"Bearer {self.token}"}
        )
    
    @tag("admin", "create_xr_experience")
    @task(1)
    def create_xr_experience(self):
        """إنشاء تجربة تعلم غامرة جديدة"""
        experience_type = random.choice(["ar", "vr", "mr"])
        subject = random.choice(["رياضيات", "علوم", "لغة عربية", "لغة إنجليزية", "تاريخ"])
        
        self.client.post(
            "/api/xr/experience",
            headers={"Authorization": f"Bearer {self.token}"},
            json={
                "title": f"تجربة {subject} جديدة",
                "description": f"هذه تجربة تعلم غامرة جديدة في مادة {subject}",
                "type": experience_type,
                "difficulty": random.choice(["سهل", "متوسط", "متقدم"]),
                "duration": random.randint(15, 90),
                "tags": [subject, experience_type, "تعليم"],
                "requirements": {
                    "device": "هاتف ذكي أو جهاز لوحي",
                    "os": "Android 8.0+ أو iOS 12.0+",
                    "camera": True,
                    "storage": "500MB"
                }
            }
        )

# إحصائيات مخصصة
@events.init.add_listener
def on_locust_init(environment, **kwargs):
    """تهيئة الإحصائيات المخصصة"""
    environment.stats.register_stats_model("response_time_percentiles", ["50%", "90%", "95%", "99%"])
    environment.stats.register_stats_model("requests_per_second", ["avg", "max"])
    environment.stats.register_stats_model("failures_per_second", ["avg", "max"])

@events.request.add_listener
def on_request(request_type, name, response_time, response_length, exception, **kwargs):
    """تسجيل الإحصائيات لكل طلب"""
    if exception:
        print(f"Request failed: {request_type} {name}, Exception: {exception}")

@events.test_start.add_listener
def on_test_start(environment, **kwargs):
    """عند بدء الاختبار"""
    print("بدء اختبار الأداء وقدرة التحمل")

@events.test_stop.add_listener
def on_test_stop(environment, **kwargs):
    """عند انتهاء الاختبار"""
    print("انتهاء اختبار الأداء وقدرة التحمل")
    
    # حفظ نتائج الاختبار
    stats = environment.stats.serialize_stats()
    with open("performance_test_results.json", "w", encoding="utf-8") as f:
        json.dump(stats, f, ensure_ascii=False, indent=2)

