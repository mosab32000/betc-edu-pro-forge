import { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  SendIcon, 
  MicIcon, 
  PaperclipIcon, 
  HomeIcon,
  ArrowLeftIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const AIAssistant = () => {
  const [messages, setMessages] = useState([
    { 
      id: 1, 
      role: 'assistant', 
      content: 'مرحباً! أنا المساعد الذكي لقلعة BTEC. كيف يمكنني مساعدتك اليوم؟' 
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);

  // التمرير التلقائي إلى أحدث رسالة
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // محاكاة إرسال رسالة واستلام رد من المساعد الذكي
  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;
    
    // إضافة رسالة المستخدم
    const userMessage = {
      id: messages.length + 1,
      role: 'user',
      content: inputMessage
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);
    
    // محاكاة تأخير الشبكة والمعالجة
    setTimeout(() => {
      let response;
      
      // محاكاة ردود المساعد الذكي بناءً على محتوى رسالة المستخدم
      if (inputMessage.includes('BTEC')) {
        response = 'BTEC هو عبارة عن شهادة مهنية معترف بها لتزويد الطلاب بالمهارات العملية والمعرفة الأكاديمية في مختلف المجالات.';
      } else if (inputMessage.includes('ادارة الأعمال') || inputMessage.includes('مفهوم ادارة الأعمال')) {
        response = 'إدارة الأعمال هي تنظيم وتنسيق الأنشطة والمشاريع للوصول إلى أهداف المؤسسة بكفاءة وفاعلية.';
      } else if (inputMessage.includes('تحليل البيانات') || inputMessage.includes('مهارة تحليل البيانات')) {
        response = 'بالطبع! يمكنني تعليم تحليل البيانات. تحليل البيانات هو عملية فحص وتنظيف وتحويل البيانات لاستخراج معلومات مفيدة ودعم اتخاذ القرارات. يتضمن ذلك عدة خطوات مثل جمع البيانات، تنظيفها، تحليلها، وتفسير النتائج.';
      } else {
        response = 'شكراً على سؤالك! يمكنني مساعدتك في فهم مفاهيم BTEC، شرح المصطلحات التقنية، أو تقديم نصائح للدراسة. هل هناك موضوع محدد تود معرفة المزيد عنه؟';
      }
      
      const assistantMessage = {
        id: messages.length + 2,
        role: 'assistant',
        content: response
      };
      
      setMessages(prev => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 1500);
  };

  // إرسال الرسالة عند الضغط على Enter
  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* شريط التنقل العلوي */}
      <header className="bg-primary text-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <Link to="/" className="ml-2">
              <Button variant="ghost" size="icon" className="text-white hover:bg-primary-foreground/10">
                <ArrowLeftIcon className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-bold">المساعد الذكي</h1>
          </div>
          
          <Link to="/">
            <Button variant="ghost" size="icon" className="text-white hover:bg-primary-foreground/10">
              <HomeIcon className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6 flex flex-col">
        {/* منطقة المحادثة */}
        <div className="flex-1 overflow-y-auto mb-4 bg-muted/30 rounded-lg p-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {message.role === 'assistant' && (
                  <div className="h-10 w-10 rounded-full overflow-hidden ml-2 flex-shrink-0">
                    <img 
                      src="/src/assets/images/eduverse_btec_ai_assistant.png" 
                      alt="المساعد الذكي" 
                      className="h-full w-full object-cover"
                    />
                  </div>
                )}
                
                <div 
                  className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                    message.role === 'user' 
                      ? 'bg-primary text-white rounded-tr-none' 
                      : 'bg-white shadow rounded-tl-none'
                  }`}
                >
                  <p className="text-sm">{message.content}</p>
                </div>
                
                {message.role === 'user' && (
                  <div className="h-10 w-10 rounded-full bg-secondary text-white flex items-center justify-center mr-2 flex-shrink-0">
                    <span className="text-sm font-bold">أ</span>
                  </div>
                )}
              </motion.div>
            ))}
            
            {isTyping && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex justify-start"
              >
                <div className="h-10 w-10 rounded-full overflow-hidden ml-2 flex-shrink-0">
                  <img 
                    src="/src/assets/images/eduverse_btec_ai_assistant.png" 
                    alt="المساعد الذكي" 
                    className="h-full w-full object-cover"
                  />
                </div>
                
                <div className="bg-white shadow rounded-2xl rounded-tl-none px-4 py-2">
                  <div className="flex space-x-1 rtl:space-x-reverse">
                    <div className="h-2 w-2 bg-primary/60 rounded-full animate-bounce"></div>
                    <div className="h-2 w-2 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    <div className="h-2 w-2 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                  </div>
                </div>
              </motion.div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
        </div>
        
        {/* منطقة الإدخال */}
        <div className="bg-white rounded-lg shadow-md p-3 flex items-center">
          <Button variant="ghost" size="icon" className="text-muted-foreground">
            <PaperclipIcon className="h-5 w-5" />
          </Button>
          
          <Input
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="اكتب رسالتك هنا..."
            className="flex-1 mx-2 text-right"
          />
          
          <Button variant="ghost" size="icon" className="text-muted-foreground">
            <MicIcon className="h-5 w-5" />
          </Button>
          
          <Button 
            onClick={handleSendMessage} 
            disabled={!inputMessage.trim() || isTyping}
            size="icon"
            className="bg-primary text-white hover:bg-primary/90"
          >
            <SendIcon className="h-5 w-5" />
          </Button>
        </div>
        
        {/* اقتراحات للأسئلة */}
        <div className="mt-4">
          <h3 className="text-sm font-medium text-muted-foreground mb-2">اقتراحات للأسئلة:</h3>
          <div className="flex flex-wrap gap-2">
            {[
              'ما هو BTEC؟',
              'اشرح لي مفهوم ادارة الأعمال',
              'ساعدني على تعلم مهارة تحليل البيانات',
              'كيف أحسن مهاراتي في العرض التقديمي؟'
            ].map((suggestion, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={() => {
                  setInputMessage(suggestion);
                }}
                className="text-xs"
              >
                {suggestion}
              </Button>
            ))}
          </div>
        </div>
      </main>

      <footer className="bg-primary/80 text-white p-4 text-center">
        <p className="text-sm">© 2025 EduverseAI - قلعة BTEC. جميع الحقوق محفوظة.</p>
      </footer>
    </div>
  );
};

export default AIAssistant;

