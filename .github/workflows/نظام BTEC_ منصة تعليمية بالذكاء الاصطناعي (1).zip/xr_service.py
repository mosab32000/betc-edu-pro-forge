"""
خدمة تجارب التعلم الغامرة (XR) في منصة EduverseAI - قلعة BTEC

توفر هذه الوحدة واجهة برمجية لإدارة تجارب التعلم الغامرة:
1. تجارب الواقع المعزز (AR)
2. تجارب الواقع الافتراضي (VR)
3. تجارب الواقع المختلط (MR)
"""

import os
import logging
import json
import uuid
from typing import Dict, List, Optional, Union, Any
from pathlib import Path
import time

# إعداد التسجيل
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class XRService:
    """خدمة تجارب التعلم الغامرة (XR)"""
    
    def __init__(self, data_dir: Optional[str] = None):
        """
        تهيئة خدمة تجارب التعلم الغامرة
        
        المعلمات:
            data_dir: مجلد تخزين بيانات تجارب التعلم الغامرة. إذا كان None، سيتم استخدام المسار الافتراضي
        """
        self.data_dir = data_dir or os.environ.get(
            'XR_DATA_DIR', 
            str(Path(__file__).parent.parent.parent / 'data' / 'xr')
        )
        
        # إنشاء مجلد البيانات إذا لم يكن موجوداً
        os.makedirs(self.data_dir, exist_ok=True)
        
        # مسار ملف تجارب التعلم الغامرة
        self.experiences_file = os.path.join(self.data_dir, 'experiences.json')
        self.user_progress_file = os.path.join(self.data_dir, 'user_progress.json')
        
        # تحميل تجارب التعلم الغامرة
        self.experiences = self._load_experiences()
        
        # تحميل تقدم المستخدمين
        self.user_progress = self._load_user_progress()
    
    def _load_experiences(self) -> Dict[str, Any]:
        """
        تحميل تجارب التعلم الغامرة من الملف
        
        الإرجاع:
            تجارب التعلم الغامرة
        """
        try:
            if os.path.exists(self.experiences_file):
                with open(self.experiences_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                # إنشاء تجارب افتراضية
                default_experiences = {
                    'ar': [
                        {
                            'id': 'ar_petra',
                            'title': 'استكشاف البتراء',
                            'description': 'استكشف مدينة البتراء الأثرية باستخدام الواقع المعزز',
                            'thumbnail': '/assets/images/xr/ar_petra_thumbnail.jpg',
                            'type': 'ar',
                            'difficulty': 'متوسط',
                            'duration': 30,  # بالدقائق
                            'tags': ['تاريخ', 'آثار', 'سياحة'],
                            'requirements': {
                                'device': 'هاتف ذكي أو جهاز لوحي',
                                'os': 'Android 8.0+ أو iOS 12.0+',
                                'camera': True,
                                'storage': '500MB'
                            },
                            'content_url': '/api/xr/content/ar_petra',
                            'created_at': time.time(),
                            'updated_at': time.time()
                        },
                        {
                            'id': 'ar_human_anatomy',
                            'title': 'تشريح جسم الإنسان',
                            'description': 'تعلم تشريح جسم الإنسان باستخدام الواقع المعزز',
                            'thumbnail': '/assets/images/xr/ar_human_anatomy_thumbnail.jpg',
                            'type': 'ar',
                            'difficulty': 'متقدم',
                            'duration': 45,  # بالدقائق
                            'tags': ['علوم', 'طب', 'تشريح'],
                            'requirements': {
                                'device': 'هاتف ذكي أو جهاز لوحي',
                                'os': 'Android 8.0+ أو iOS 12.0+',
                                'camera': True,
                                'storage': '1GB'
                            },
                            'content_url': '/api/xr/content/ar_human_anatomy',
                            'created_at': time.time(),
                            'updated_at': time.time()
                        }
                    ],
                    'vr': [
                        {
                            'id': 'vr_chemistry_lab',
                            'title': 'مختبر الكيمياء الافتراضي',
                            'description': 'قم بإجراء تجارب كيميائية في مختبر افتراضي آمن',
                            'thumbnail': '/assets/images/xr/vr_chemistry_lab_thumbnail.jpg',
                            'type': 'vr',
                            'difficulty': 'متوسط',
                            'duration': 60,  # بالدقائق
                            'tags': ['علوم', 'كيمياء', 'مختبر'],
                            'requirements': {
                                'device': 'نظارة واقع افتراضي',
                                'os': 'Windows 10+ أو Android 9.0+',
                                'camera': False,
                                'storage': '2GB'
                            },
                            'content_url': '/api/xr/content/vr_chemistry_lab',
                            'created_at': time.time(),
                            'updated_at': time.time()
                        },
                        {
                            'id': 'vr_space_exploration',
                            'title': 'استكشاف الفضاء',
                            'description': 'سافر عبر النظام الشمسي واستكشف الكواكب والنجوم',
                            'thumbnail': '/assets/images/xr/vr_space_exploration_thumbnail.jpg',
                            'type': 'vr',
                            'difficulty': 'سهل',
                            'duration': 40,  # بالدقائق
                            'tags': ['علوم', 'فلك', 'فضاء'],
                            'requirements': {
                                'device': 'نظارة واقع افتراضي',
                                'os': 'Windows 10+ أو Android 9.0+',
                                'camera': False,
                                'storage': '1.5GB'
                            },
                            'content_url': '/api/xr/content/vr_space_exploration',
                            'created_at': time.time(),
                            'updated_at': time.time()
                        }
                    ],
                    'mr': [
                        {
                            'id': 'mr_historical_jordan',
                            'title': 'الأردن التاريخي',
                            'description': 'استكشف تاريخ الأردن من خلال تجربة واقع مختلط تفاعلية',
                            'thumbnail': '/assets/images/xr/mr_historical_jordan_thumbnail.jpg',
                            'type': 'mr',
                            'difficulty': 'متقدم',
                            'duration': 90,  # بالدقائق
                            'tags': ['تاريخ', 'ثقافة', 'الأردن'],
                            'requirements': {
                                'device': 'نظارة واقع مختلط',
                                'os': 'Windows 10+ مع Windows Mixed Reality',
                                'camera': True,
                                'storage': '3GB'
                            },
                            'content_url': '/api/xr/content/mr_historical_jordan',
                            'created_at': time.time(),
                            'updated_at': time.time()
                        }
                    ]
                }
                
                # حفظ التجارب الافتراضية
                self._save_experiences(default_experiences)
                
                return default_experiences
        except Exception as e:
            logger.error(f"حدث خطأ أثناء تحميل تجارب التعلم الغامرة: {e}")
            return {'ar': [], 'vr': [], 'mr': []}
    
    def _save_experiences(self, experiences: Dict[str, Any]) -> None:
        """
        حفظ تجارب التعلم الغامرة إلى الملف
        
        المعلمات:
            experiences: تجارب التعلم الغامرة
        """
        try:
            with open(self.experiences_file, 'w', encoding='utf-8') as f:
                json.dump(experiences, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"حدث خطأ أثناء حفظ تجارب التعلم الغامرة: {e}")
    
    def _load_user_progress(self) -> Dict[str, Any]:
        """
        تحميل تقدم المستخدمين من الملف
        
        الإرجاع:
            تقدم المستخدمين
        """
        try:
            if os.path.exists(self.user_progress_file):
                with open(self.user_progress_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                # إنشاء ملف تقدم فارغ
                empty_progress = {}
                
                # حفظ ملف التقدم
                self._save_user_progress(empty_progress)
                
                return empty_progress
        except Exception as e:
            logger.error(f"حدث خطأ أثناء تحميل تقدم المستخدمين: {e}")
            return {}
    
    def _save_user_progress(self, user_progress: Dict[str, Any]) -> None:
        """
        حفظ تقدم المستخدمين إلى الملف
        
        المعلمات:
            user_progress: تقدم المستخدمين
        """
        try:
            with open(self.user_progress_file, 'w', encoding='utf-8') as f:
                json.dump(user_progress, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"حدث خطأ أثناء حفظ تقدم المستخدمين: {e}")
    
    def get_all_experiences(self) -> Dict[str, List[Dict[str, Any]]]:
        """
        الحصول على جميع تجارب التعلم الغامرة
        
        الإرجاع:
            جميع تجارب التعلم الغامرة
        """
        return self.experiences
    
    def get_experiences_by_type(self, experience_type: str) -> List[Dict[str, Any]]:
        """
        الحصول على تجارب التعلم الغامرة حسب النوع
        
        المعلمات:
            experience_type: نوع التجربة (ar, vr, mr)
            
        الإرجاع:
            تجارب التعلم الغامرة من النوع المحدد
        """
        return self.experiences.get(experience_type, [])
    
    def get_experience_by_id(self, experience_id: str) -> Optional[Dict[str, Any]]:
        """
        الحصول على تجربة تعلم غامرة حسب المعرف
        
        المعلمات:
            experience_id: معرف التجربة
            
        الإرجاع:
            تجربة التعلم الغامرة إذا تم العثور عليها، None خلاف ذلك
        """
        for experience_type, experiences in self.experiences.items():
            for experience in experiences:
                if experience.get('id') == experience_id:
                    return experience
        
        return None
    
    def add_experience(self, experience_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        إضافة تجربة تعلم غامرة جديدة
        
        المعلمات:
            experience_data: بيانات التجربة
            
        الإرجاع:
            بيانات التجربة المضافة
        """
        # التحقق من وجود النوع
        experience_type = experience_data.get('type')
        if experience_type not in ['ar', 'vr', 'mr']:
            raise ValueError('نوع التجربة غير صالح. يجب أن يكون ar أو vr أو mr')
        
        # إنشاء معرف للتجربة إذا لم يتم توفيره
        if 'id' not in experience_data:
            experience_data['id'] = f"{experience_type}_{str(uuid.uuid4())[:8]}"
        
        # إضافة الطوابع الزمنية
        current_time = time.time()
        experience_data['created_at'] = current_time
        experience_data['updated_at'] = current_time
        
        # إضافة التجربة
        if experience_type not in self.experiences:
            self.experiences[experience_type] = []
        
        self.experiences[experience_type].append(experience_data)
        
        # حفظ التجارب
        self._save_experiences(self.experiences)
        
        return experience_data
    
    def update_experience(self, experience_id: str, experience_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        تحديث تجربة تعلم غامرة
        
        المعلمات:
            experience_id: معرف التجربة
            experience_data: بيانات التجربة المحدثة
            
        الإرجاع:
            بيانات التجربة المحدثة إذا تم العثور عليها، None خلاف ذلك
        """
        for experience_type, experiences in self.experiences.items():
            for i, experience in enumerate(experiences):
                if experience.get('id') == experience_id:
                    # تحديث البيانات
                    updated_experience = {**experience, **experience_data}
                    
                    # تحديث الطابع الزمني
                    updated_experience['updated_at'] = time.time()
                    
                    # تحديث التجربة
                    self.experiences[experience_type][i] = updated_experience
                    
                    # حفظ التجارب
                    self._save_experiences(self.experiences)
                    
                    return updated_experience
        
        return None
    
    def delete_experience(self, experience_id: str) -> bool:
        """
        حذف تجربة تعلم غامرة
        
        المعلمات:
            experience_id: معرف التجربة
            
        الإرجاع:
            True إذا تم الحذف بنجاح، False خلاف ذلك
        """
        for experience_type, experiences in self.experiences.items():
            for i, experience in enumerate(experiences):
                if experience.get('id') == experience_id:
                    # حذف التجربة
                    del self.experiences[experience_type][i]
                    
                    # حفظ التجارب
                    self._save_experiences(self.experiences)
                    
                    return True
        
        return False
    
    def get_user_progress(self, user_id: str) -> Dict[str, Any]:
        """
        الحصول على تقدم المستخدم
        
        المعلمات:
            user_id: معرف المستخدم
            
        الإرجاع:
            تقدم المستخدم
        """
        return self.user_progress.get(user_id, {})
    
    def update_user_progress(self, user_id: str, experience_id: str, progress_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        تحديث تقدم المستخدم
        
        المعلمات:
            user_id: معرف المستخدم
            experience_id: معرف التجربة
            progress_data: بيانات التقدم
            
        الإرجاع:
            تقدم المستخدم المحدث
        """
        # إنشاء تقدم المستخدم إذا لم يكن موجوداً
        if user_id not in self.user_progress:
            self.user_progress[user_id] = {}
        
        # إنشاء تقدم التجربة إذا لم يكن موجوداً
        if experience_id not in self.user_progress[user_id]:
            self.user_progress[user_id][experience_id] = {
                'started_at': time.time(),
                'last_activity': time.time(),
                'progress': 0,
                'completed': False,
                'score': 0,
                'time_spent': 0,
                'activities': []
            }
        
        # تحديث بيانات التقدم
        user_experience_progress = self.user_progress[user_id][experience_id]
        user_experience_progress.update(progress_data)
        
        # تحديث وقت آخر نشاط
        user_experience_progress['last_activity'] = time.time()
        
        # حفظ تقدم المستخدمين
        self._save_user_progress(self.user_progress)
        
        return user_experience_progress
    
    def get_recommended_experiences(self, user_id: str, limit: int = 5) -> List[Dict[str, Any]]:
        """
        الحصول على تجارب التعلم الغامرة الموصى بها للمستخدم
        
        المعلمات:
            user_id: معرف المستخدم
            limit: الحد الأقصى لعدد التجارب الموصى بها
            
        الإرجاع:
            قائمة بتجارب التعلم الغامرة الموصى بها
        """
        # الحصول على تقدم المستخدم
        user_progress = self.get_user_progress(user_id)
        
        # تجميع جميع التجارب
        all_experiences = []
        for experience_type, experiences in self.experiences.items():
            all_experiences.extend(experiences)
        
        # تصفية التجارب التي لم يكملها المستخدم
        incomplete_experiences = []
        for experience in all_experiences:
            experience_id = experience.get('id')
            if experience_id not in user_progress or not user_progress[experience_id].get('completed', False):
                incomplete_experiences.append(experience)
        
        # ترتيب التجارب حسب الصعوبة (من السهل إلى المتقدم)
        difficulty_order = {'سهل': 0, 'متوسط': 1, 'متقدم': 2}
        sorted_experiences = sorted(
            incomplete_experiences,
            key=lambda x: difficulty_order.get(x.get('difficulty'), 1)
        )
        
        # إرجاع التجارب الموصى بها
        return sorted_experiences[:limit]
    
    def get_experience_content(self, experience_id: str) -> Dict[str, Any]:
        """
        الحصول على محتوى تجربة التعلم الغامرة
        
        المعلمات:
            experience_id: معرف التجربة
            
        الإرجاع:
            محتوى التجربة
        """
        # الحصول على التجربة
        experience = self.get_experience_by_id(experience_id)
        
        if experience is None:
            raise ValueError(f"لم يتم العثور على تجربة بالمعرف: {experience_id}")
        
        # إنشاء محتوى افتراضي للتجربة
        content = {
            'id': experience_id,
            'title': experience.get('title', ''),
            'description': experience.get('description', ''),
            'type': experience.get('type', ''),
            'scenes': [],
            'assets': [],
            'interactions': [],
            'quizzes': []
        }
        
        # إضافة مشاهد افتراضية حسب نوع التجربة
        if experience.get('type') == 'ar':
            content['scenes'] = [
                {
                    'id': 'scene_1',
                    'name': 'المشهد الأول',
                    'description': 'المشهد الأول للتجربة',
                    'background': '/assets/images/xr/scenes/ar_scene_1.jpg',
                    'markers': [
                        {
                            'id': 'marker_1',
                            'name': 'العلامة الأولى',
                            'image': '/assets/images/xr/markers/marker_1.jpg',
                            'model': '/assets/models/xr/model_1.glb'
                        }
                    ]
                }
            ]
        elif experience.get('type') == 'vr':
            content['scenes'] = [
                {
                    'id': 'scene_1',
                    'name': 'المشهد الأول',
                    'description': 'المشهد الأول للتجربة',
                    'environment': '/assets/models/xr/environment_1.glb',
                    'skybox': '/assets/images/xr/skyboxes/skybox_1.jpg'
                }
            ]
        elif experience.get('type') == 'mr':
            content['scenes'] = [
                {
                    'id': 'scene_1',
                    'name': 'المشهد الأول',
                    'description': 'المشهد الأول للتجربة',
                    'environment': '/assets/models/xr/environment_1.glb',
                    'anchors': [
                        {
                            'id': 'anchor_1',
                            'name': 'النقطة الأولى',
                            'position': {'x': 0, 'y': 0, 'z': 0},
                            'model': '/assets/models/xr/model_1.glb'
                        }
                    ]
                }
            ]
        
        # إضافة أصول افتراضية
        content['assets'] = [
            {
                'id': 'asset_1',
                'name': 'الأصل الأول',
                'type': 'model',
                'url': '/assets/models/xr/asset_1.glb'
            },
            {
                'id': 'asset_2',
                'name': 'الأصل الثاني',
                'type': 'image',
                'url': '/assets/images/xr/asset_2.jpg'
            }
        ]
        
        # إضافة تفاعلات افتراضية
        content['interactions'] = [
            {
                'id': 'interaction_1',
                'name': 'التفاعل الأول',
                'type': 'tap',
                'target': 'asset_1',
                'action': 'show_info',
                'data': {
                    'title': 'معلومات',
                    'content': 'هذا هو محتوى المعلومات'
                }
            }
        ]
        
        # إضافة اختبارات افتراضية
        content['quizzes'] = [
            {
                'id': 'quiz_1',
                'name': 'الاختبار الأول',
                'questions': [
                    {
                        'id': 'question_1',
                        'text': 'هذا هو السؤال الأول',
                        'options': [
                            {'id': 'option_1', 'text': 'الخيار الأول'},
                            {'id': 'option_2', 'text': 'الخيار الثاني'},
                            {'id': 'option_3', 'text': 'الخيار الثالث'}
                        ],
                        'correct_option': 'option_1'
                    }
                ]
            }
        ]
        
        return content

# إنشاء نسخة واحدة من الخدمة للاستخدام في جميع أنحاء التطبيق
xr_service = None

def get_xr_service(data_dir: Optional[str] = None) -> XRService:
    """
    الحصول على نسخة من خدمة تجارب التعلم الغامرة (نمط Singleton)
    
    المعلمات:
        data_dir: مجلد تخزين بيانات تجارب التعلم الغامرة
        
    الإرجاع:
        نسخة من خدمة تجارب التعلم الغامرة
    """
    global xr_service
    
    if xr_service is None:
        xr_service = XRService(data_dir)
    
    return xr_service

