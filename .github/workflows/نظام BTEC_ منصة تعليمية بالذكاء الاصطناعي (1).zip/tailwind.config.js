/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        tajawal: ['Tajawal', 'sans-serif'],
        noto: ['Noto Sans Arabic', 'sans-serif'],
        poppins: ['Poppins', 'sans-serif'],
        inter: ['Inter', 'sans-serif'],
      },
      colors: {
        'royal-blue': '#1F4287',
        'emerald-green': '#009975',
        'jordanian-red': '#CE1126',
        'stone-gray': '#8A8D91',
        'desert-gold': '#D4AF37',
        'turquoise-blue': '#30BFBF',
        'royal-purple': '#7B68EE',
        'sunrise-orange': '#FF7F50',
      },
    },
  },
  plugins: [],
}

