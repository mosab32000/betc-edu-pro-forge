import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import AuthLayout from '../layouts/AuthLayout';

/**
 * صفحة التسجيل
 * @returns {JSX.Element} - مكون صفحة التسجيل
 */
const Register = () => {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    confirmPassword: '',
    first_name: '',
    last_name: '',
    email: '',
    role: 'student'
  });
  
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const { register } = useAuth();
  
  /**
   * تحديث بيانات النموذج
   * @param {Event} e - حدث التغيير
   */
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };
  
  /**
   * معالجة التسجيل
   * @param {Event} e - حدث النموذج
   */
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // التحقق من صحة البيانات
    if (!formData.username || !formData.password || !formData.email) {
      setError('يرجى ملء جميع الحقول المطلوبة');
      return;
    }
    
    if (formData.password !== formData.confirmPassword) {
      setError('كلمات المرور غير متطابقة');
      return;
    }
    
    if (formData.password.length < 8) {
      setError('يجب أن تتكون كلمة المرور من 8 أحرف على الأقل');
      return;
    }
    
    try {
      setIsLoading(true);
      setError('');
      
      // إزالة حقل تأكيد كلمة المرور قبل الإرسال
      const { confirmPassword, ...userData } = formData;
      
      await register(userData);
      // سيتم إعادة التوجيه تلقائيًا بواسطة AuthContext
    } catch (err) {
      setError(err.message || 'فشل التسجيل. يرجى المحاولة مرة أخرى.');
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <AuthLayout>
      <div className="max-w-md mx-auto bg-card rounded-lg shadow-lg overflow-hidden">
        <div className="p-6 sm:p-8">
          <div className="text-center mb-8">
            <img 
              src="/src/assets/images/eduverse-btec-logo.png" 
              alt="EduverseAI - قلعة BTEC" 
              className="h-24 mx-auto"
            />
            <h1 className="text-2xl font-bold mt-4 text-card-foreground">إنشاء حساب جديد</h1>
            <p className="text-muted-foreground mt-2">انضم إلى منصة EduverseAI - قلعة BTEC</p>
          </div>
          
          {error && (
            <div className="bg-destructive/10 text-destructive p-3 rounded-md mb-4">
              {error}
            </div>
          )}
          
          <form onSubmit={handleSubmit}>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="first_name" className="block text-sm font-medium text-card-foreground mb-1">
                    الاسم الأول
                  </label>
                  <input
                    id="first_name"
                    name="first_name"
                    type="text"
                    value={formData.first_name}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                    placeholder="الاسم الأول"
                    disabled={isLoading}
                  />
                </div>
                
                <div>
                  <label htmlFor="last_name" className="block text-sm font-medium text-card-foreground mb-1">
                    الاسم الأخير
                  </label>
                  <input
                    id="last_name"
                    name="last_name"
                    type="text"
                    value={formData.last_name}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                    placeholder="الاسم الأخير"
                    disabled={isLoading}
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="username" className="block text-sm font-medium text-card-foreground mb-1">
                  اسم المستخدم *
                </label>
                <input
                  id="username"
                  name="username"
                  type="text"
                  value={formData.username}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="أدخل اسم المستخدم"
                  required
                  disabled={isLoading}
                />
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-card-foreground mb-1">
                  البريد الإلكتروني *
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="أدخل البريد الإلكتروني"
                  required
                  disabled={isLoading}
                />
              </div>
              
              <div>
                <label htmlFor="password" className="block text-sm font-medium text-card-foreground mb-1">
                  كلمة المرور *
                </label>
                <input
                  id="password"
                  name="password"
                  type="password"
                  value={formData.password}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="أدخل كلمة المرور (8 أحرف على الأقل)"
                  required
                  disabled={isLoading}
                />
              </div>
              
              <div>
                <label htmlFor="confirmPassword" className="block text-sm font-medium text-card-foreground mb-1">
                  تأكيد كلمة المرور *
                </label>
                <input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="أعد إدخال كلمة المرور"
                  required
                  disabled={isLoading}
                />
              </div>
              
              <div>
                <label htmlFor="role" className="block text-sm font-medium text-card-foreground mb-1">
                  نوع الحساب *
                </label>
                <select
                  id="role"
                  name="role"
                  value={formData.role}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  disabled={isLoading}
                >
                  <option value="student">طالب</option>
                  <option value="teacher">معلم</option>
                </select>
              </div>
              
              <div>
                <button
                  type="submit"
                  className="w-full bg-primary text-primary-foreground py-2 px-4 rounded-md hover:bg-primary/90 transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 disabled:opacity-50"
                  disabled={isLoading}
                >
                  {isLoading ? 'جاري التسجيل...' : 'إنشاء حساب'}
                </button>
              </div>
            </div>
          </form>
          
          <div className="mt-6 text-center">
            <p className="text-sm text-muted-foreground">
              لديك حساب بالفعل؟{' '}
              <Link to="/login" className="text-primary hover:underline">
                تسجيل الدخول
              </Link>
            </p>
          </div>
        </div>
      </div>
    </AuthLayout>
  );
};

export default Register;

