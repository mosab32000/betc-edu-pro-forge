"""
نقطة دخول WSGI لمنصة EduverseAI - قلعة BTEC
"""
from src.app import create_app

app = create_app()

if __name__ == '__main__':
    app.run()

