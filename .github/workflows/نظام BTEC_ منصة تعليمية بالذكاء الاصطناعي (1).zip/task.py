"""
نموذج المهام التعليمية في منصة EduverseAI - قلعة BTEC
"""
from datetime import datetime
from bson import ObjectId

class Task:
    """
    نموذج المهمة التعليمية في المنصة
    """
    def __init__(self, title, description, subject, instructions=None, criteria=None, 
                 resources=None, due_date=None, created_by=None, created_at=None, 
                 updated_at=None, _id=None):
        """
        تهيئة كائن المهمة التعليمية
        
        المعلمات:
            title (str): عنوان المهمة
            description (str): وصف المهمة
            subject (str): المادة الدراسية المرتبطة بالمهمة
            instructions (list): قائمة بالتعليمات لإكمال المهمة
            criteria (list): معايير التقييم
            resources (list): الموارد المساعدة
            due_date (datetime): تاريخ استحقاق المهمة
            created_by (str): معرف المستخدم الذي أنشأ المهمة
            created_at (datetime): تاريخ إنشاء المهمة
            updated_at (datetime): تاريخ آخر تحديث للمهمة
            _id (ObjectId): معرف المهمة في قاعدة البيانات
        """
        self._id = _id if _id else ObjectId()
        self.title = title
        self.description = description
        self.subject = subject
        self.instructions = instructions if instructions else []
        self.criteria = criteria if criteria else []
        self.resources = resources if resources else []
        self.due_date = due_date
        self.created_by = created_by
        self.created_at = created_at if created_at else datetime.utcnow()
        self.updated_at = updated_at if updated_at else datetime.utcnow()
        
        # بيانات إضافية للمهمة
        self.difficulty = "medium"  # مستوى صعوبة المهمة (easy, medium, hard)
        self.points = 100  # النقاط المكتسبة عند إكمال المهمة
        self.estimated_time = 60  # الوقت المقدر لإكمال المهمة بالدقائق
        self.tags = []  # وسوم المهمة
        self.xr_experiences = []  # تجارب الواقع الممتد المرتبطة بالمهمة
        
    def to_dict(self):
        """
        تحويل كائن المهمة إلى قاموس
        
        العائد:
            dict: قاموس يمثل المهمة
        """
        return {
            "_id": str(self._id),
            "title": self.title,
            "description": self.description,
            "subject": self.subject,
            "instructions": self.instructions,
            "criteria": self.criteria,
            "resources": self.resources,
            "due_date": self.due_date.isoformat() if self.due_date else None,
            "created_by": str(self.created_by) if self.created_by else None,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "difficulty": self.difficulty,
            "points": self.points,
            "estimated_time": self.estimated_time,
            "tags": self.tags,
            "xr_experiences": self.xr_experiences
        }
    
    @classmethod
    def from_dict(cls, data):
        """
        إنشاء كائن مهمة من قاموس
        
        المعلمات:
            data (dict): قاموس يحتوي على بيانات المهمة
            
        العائد:
            Task: كائن المهمة
        """
        _id = ObjectId(data["_id"]) if "_id" in data else None
        created_by = ObjectId(data["created_by"]) if "created_by" in data and data["created_by"] else None
        created_at = datetime.fromisoformat(data["created_at"]) if "created_at" in data else None
        updated_at = datetime.fromisoformat(data["updated_at"]) if "updated_at" in data else None
        due_date = datetime.fromisoformat(data["due_date"]) if "due_date" in data and data["due_date"] else None
        
        task = cls(
            title=data.get("title"),
            description=data.get("description"),
            subject=data.get("subject"),
            instructions=data.get("instructions", []),
            criteria=data.get("criteria", []),
            resources=data.get("resources", []),
            due_date=due_date,
            created_by=created_by,
            created_at=created_at,
            updated_at=updated_at,
            _id=_id
        )
        
        task.difficulty = data.get("difficulty", "medium")
        task.points = data.get("points", 100)
        task.estimated_time = data.get("estimated_time", 60)
        task.tags = data.get("tags", [])
        task.xr_experiences = data.get("xr_experiences", [])
        
        return task

