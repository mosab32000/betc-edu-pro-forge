#!/usr/bin/env python3
"""
سكربت لتحليل نتائج اختبار الأداء وإنشاء تقارير مرئية

كيفية الاستخدام:
1. قم بتشغيل اختبار الأداء باستخدام Locust
2. قم بتصدير النتائج بتنسيق JSON
3. قم بتشغيل هذا السكربت: python analyze_results.py <path_to_results.json>
"""

import json
import sys
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from datetime import datetime

# تكوين matplotlib لدعم اللغة العربية
mpl.rcParams['font.family'] = 'Arial'
plt.rcParams['axes.unicode_minus'] = False

def load_results(file_path):
    """تحميل نتائج اختبار الأداء من ملف JSON"""
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def create_report_directory():
    """إنشاء مجلد للتقارير"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_dir = f"performance_report_{timestamp}"
    os.makedirs(report_dir, exist_ok=True)
    return report_dir

def analyze_response_times(results, report_dir):
    """تحليل أوقات الاستجابة وإنشاء رسوم بيانية"""
    # استخراج بيانات أوقات الاستجابة
    endpoints = []
    response_times = []
    
    for endpoint, data in results['stats'].items():
        if endpoint == 'Total':
            continue
        endpoints.append(endpoint)
        response_times.append({
            'endpoint': endpoint,
            'min': data['min_response_time'],
            'median': data['median_response_time'],
            'avg': data['avg_response_time'],
            'max': data['max_response_time'],
            'p90': data['response_time_percentiles']['90.0'],
            'p95': data['response_time_percentiles']['95.0'],
            'p99': data['response_time_percentiles']['99.0'],
            'count': data['num_requests'],
            'failures': data['num_failures']
        })
    
    # تحويل البيانات إلى DataFrame
    df = pd.DataFrame(response_times)
    
    # ترتيب البيانات حسب متوسط وقت الاستجابة
    df = df.sort_values('avg', ascending=False)
    
    # إنشاء رسم بياني لمتوسط أوقات الاستجابة
    plt.figure(figsize=(12, 8))
    plt.barh(df['endpoint'], df['avg'], color='skyblue')
    plt.xlabel('متوسط وقت الاستجابة (مللي ثانية)')
    plt.ylabel('نقطة النهاية')
    plt.title('متوسط أوقات الاستجابة لكل نقطة نهاية')
    plt.tight_layout()
    plt.savefig(f"{report_dir}/avg_response_times.png", dpi=300)
    
    # إنشاء رسم بياني للمئينات
    plt.figure(figsize=(12, 8))
    x = np.arange(len(df))
    width = 0.2
    
    plt.barh(x - width, df['median'], width, label='وسيط', color='skyblue')
    plt.barh(x, df['p90'], width, label='المئين 90', color='lightgreen')
    plt.barh(x + width, df['p95'], width, label='المئين 95', color='salmon')
    
    plt.yticks(x, df['endpoint'])
    plt.xlabel('وقت الاستجابة (مللي ثانية)')
    plt.title('مئينات أوقات الاستجابة لكل نقطة نهاية')
    plt.legend()
    plt.tight_layout()
    plt.savefig(f"{report_dir}/response_time_percentiles.png", dpi=300)
    
    # حفظ البيانات في ملف CSV
    df.to_csv(f"{report_dir}/response_times.csv", index=False)
    
    return df

def analyze_throughput(results, report_dir):
    """تحليل معدل الإنتاجية وإنشاء رسوم بيانية"""
    # استخراج بيانات معدل الإنتاجية
    endpoints = []
    throughput = []
    
    for endpoint, data in results['stats'].items():
        if endpoint == 'Total':
            continue
        endpoints.append(endpoint)
        
        # حساب معدل الإنتاجية (عدد الطلبات في الثانية)
        requests_per_second = data['num_requests'] / results['duration']
        
        throughput.append({
            'endpoint': endpoint,
            'requests_per_second': requests_per_second,
            'count': data['num_requests'],
            'failures': data['num_failures'],
            'failure_rate': data['num_failures'] / data['num_requests'] if data['num_requests'] > 0 else 0
        })
    
    # تحويل البيانات إلى DataFrame
    df = pd.DataFrame(throughput)
    
    # ترتيب البيانات حسب معدل الإنتاجية
    df = df.sort_values('requests_per_second', ascending=False)
    
    # إنشاء رسم بياني لمعدل الإنتاجية
    plt.figure(figsize=(12, 8))
    plt.barh(df['endpoint'], df['requests_per_second'], color='lightgreen')
    plt.xlabel('عدد الطلبات في الثانية')
    plt.ylabel('نقطة النهاية')
    plt.title('معدل الإنتاجية لكل نقطة نهاية')
    plt.tight_layout()
    plt.savefig(f"{report_dir}/throughput.png", dpi=300)
    
    # إنشاء رسم بياني لمعدل الفشل
    plt.figure(figsize=(12, 8))
    plt.barh(df['endpoint'], df['failure_rate'] * 100, color='salmon')
    plt.xlabel('معدل الفشل (%)')
    plt.ylabel('نقطة النهاية')
    plt.title('معدل الفشل لكل نقطة نهاية')
    plt.tight_layout()
    plt.savefig(f"{report_dir}/failure_rate.png", dpi=300)
    
    # حفظ البيانات في ملف CSV
    df.to_csv(f"{report_dir}/throughput.csv", index=False)
    
    return df

def analyze_user_types(results, report_dir):
    """تحليل أداء أنواع المستخدمين المختلفة وإنشاء رسوم بيانية"""
    # تجميع البيانات حسب نوع المستخدم
    user_types = {}
    
    for endpoint, data in results['stats'].items():
        if endpoint == 'Total':
            continue
        
        # استخراج نوع المستخدم من اسم نقطة النهاية
        parts = endpoint.split('/')
        if len(parts) > 0:
            user_type = None
            if 'student' in endpoint:
                user_type = 'student'
            elif 'teacher' in endpoint:
                user_type = 'teacher'
            elif 'admin' in endpoint:
                user_type = 'admin'
            
            if user_type:
                if user_type not in user_types:
                    user_types[user_type] = {
                        'count': 0,
                        'failures': 0,
                        'total_response_time': 0
                    }
                
                user_types[user_type]['count'] += data['num_requests']
                user_types[user_type]['failures'] += data['num_failures']
                user_types[user_type]['total_response_time'] += data['num_requests'] * data['avg_response_time']
    
    # حساب متوسط وقت الاستجابة لكل نوع مستخدم
    for user_type in user_types:
        if user_types[user_type]['count'] > 0:
            user_types[user_type]['avg_response_time'] = user_types[user_type]['total_response_time'] / user_types[user_type]['count']
            user_types[user_type]['failure_rate'] = user_types[user_type]['failures'] / user_types[user_type]['count']
    
    # تحويل البيانات إلى DataFrame
    df = pd.DataFrame([
        {
            'user_type': user_type,
            'count': data['count'],
            'failures': data['failures'],
            'avg_response_time': data['avg_response_time'],
            'failure_rate': data['failure_rate']
        }
        for user_type, data in user_types.items()
    ])
    
    # إنشاء رسم بياني لمتوسط وقت الاستجابة لكل نوع مستخدم
    plt.figure(figsize=(10, 6))
    plt.bar(df['user_type'], df['avg_response_time'], color='skyblue')
    plt.xlabel('نوع المستخدم')
    plt.ylabel('متوسط وقت الاستجابة (مللي ثانية)')
    plt.title('متوسط وقت الاستجابة لكل نوع مستخدم')
    plt.tight_layout()
    plt.savefig(f"{report_dir}/user_type_response_times.png", dpi=300)
    
    # إنشاء رسم بياني لمعدل الفشل لكل نوع مستخدم
    plt.figure(figsize=(10, 6))
    plt.bar(df['user_type'], df['failure_rate'] * 100, color='salmon')
    plt.xlabel('نوع المستخدم')
    plt.ylabel('معدل الفشل (%)')
    plt.title('معدل الفشل لكل نوع مستخدم')
    plt.tight_layout()
    plt.savefig(f"{report_dir}/user_type_failure_rate.png", dpi=300)
    
    # حفظ البيانات في ملف CSV
    df.to_csv(f"{report_dir}/user_types.csv", index=False)
    
    return df

def generate_html_report(report_dir, response_times_df, throughput_df, user_types_df, results):
    """إنشاء تقرير HTML"""
    total_stats = results['stats']['Total']
    
    html = f"""
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>تقرير اختبار الأداء - منصة EduverseAI - قلعة BTEC</title>
        <style>
            body {{
                font-family: 'Arial', sans-serif;
                margin: 0;
                padding: 20px;
                background-color: #f5f5f5;
                color: #333;
            }}
            .container {{
                max-width: 1200px;
                margin: 0 auto;
                background-color: white;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0,0,0,0.1);
            }}
            h1, h2, h3 {{
                color: #2c3e50;
            }}
            .summary {{
                display: flex;
                flex-wrap: wrap;
                gap: 20px;
                margin-bottom: 30px;
            }}
            .summary-card {{
                flex: 1;
                min-width: 200px;
                background-color: #f8f9fa;
                padding: 15px;
                border-radius: 8px;
                box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            }}
            .summary-card h3 {{
                margin-top: 0;
                color: #3498db;
            }}
            .summary-card p {{
                font-size: 24px;
                font-weight: bold;
                margin: 10px 0 0;
            }}
            .chart-container {{
                margin: 30px 0;
            }}
            table {{
                width: 100%;
                border-collapse: collapse;
                margin: 20px 0;
            }}
            th, td {{
                padding: 12px 15px;
                text-align: right;
                border-bottom: 1px solid #ddd;
            }}
            th {{
                background-color: #f2f2f2;
            }}
            tr:hover {{
                background-color: #f5f5f5;
            }}
            .recommendations {{
                background-color: #e8f4f8;
                padding: 15px;
                border-radius: 8px;
                margin-top: 30px;
            }}
            .recommendations h3 {{
                color: #2980b9;
                margin-top: 0;
            }}
            img {{
                max-width: 100%;
                height: auto;
                margin: 20px 0;
                border: 1px solid #ddd;
                border-radius: 4px;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>تقرير اختبار الأداء - منصة EduverseAI - قلعة BTEC</h1>
            <p>تاريخ الاختبار: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
            
            <div class="summary">
                <div class="summary-card">
                    <h3>إجمالي الطلبات</h3>
                    <p>{total_stats['num_requests']}</p>
                </div>
                <div class="summary-card">
                    <h3>متوسط وقت الاستجابة</h3>
                    <p>{total_stats['avg_response_time']:.2f} مللي ثانية</p>
                </div>
                <div class="summary-card">
                    <h3>معدل الفشل</h3>
                    <p>{(total_stats['num_failures'] / total_stats['num_requests'] * 100) if total_stats['num_requests'] > 0 else 0:.2f}%</p>
                </div>
                <div class="summary-card">
                    <h3>عدد المستخدمين</h3>
                    <p>{results['user_count']}</p>
                </div>
            </div>
            
            <h2>ملخص الاختبار</h2>
            <p>تم إجراء اختبار الأداء على منصة EduverseAI - قلعة BTEC لتقييم قدرتها على التعامل مع عدد كبير من المستخدمين المتزامنين. استمر الاختبار لمدة {results['duration']:.2f} ثانية، وتم محاكاة {results['user_count']} مستخدم متزامن.</p>
            
            <div class="chart-container">
                <h2>أوقات الاستجابة</h2>
                <img src="avg_response_times.png" alt="متوسط أوقات الاستجابة">
                <img src="response_time_percentiles.png" alt="مئينات أوقات الاستجابة">
                
                <h3>أعلى 5 نقاط نهاية من حيث وقت الاستجابة</h3>
                <table>
                    <tr>
                        <th>نقطة النهاية</th>
                        <th>متوسط وقت الاستجابة (مللي ثانية)</th>
                        <th>الوسيط</th>
                        <th>المئين 95</th>
                        <th>عدد الطلبات</th>
                    </tr>
    """
    
    # إضافة أعلى 5 نقاط نهاية من حيث وقت الاستجابة
    for _, row in response_times_df.head(5).iterrows():
        html += f"""
                    <tr>
                        <td>{row['endpoint']}</td>
                        <td>{row['avg']:.2f}</td>
                        <td>{row['median']:.2f}</td>
                        <td>{row['p95']:.2f}</td>
                        <td>{row['count']}</td>
                    </tr>
        """
    
    html += """
                </table>
            </div>
            
            <div class="chart-container">
                <h2>معدل الإنتاجية</h2>
                <img src="throughput.png" alt="معدل الإنتاجية">
                <img src="failure_rate.png" alt="معدل الفشل">
                
                <h3>أعلى 5 نقاط نهاية من حيث معدل الإنتاجية</h3>
                <table>
                    <tr>
                        <th>نقطة النهاية</th>
                        <th>عدد الطلبات في الثانية</th>
                        <th>عدد الطلبات</th>
                        <th>عدد حالات الفشل</th>
                        <th>معدل الفشل (%)</th>
                    </tr>
    """
    
    # إضافة أعلى 5 نقاط نهاية من حيث معدل الإنتاجية
    for _, row in throughput_df.head(5).iterrows():
        html += f"""
                    <tr>
                        <td>{row['endpoint']}</td>
                        <td>{row['requests_per_second']:.2f}</td>
                        <td>{row['count']}</td>
                        <td>{row['failures']}</td>
                        <td>{row['failure_rate'] * 100:.2f}%</td>
                    </tr>
        """
    
    html += """
                </table>
            </div>
            
            <div class="chart-container">
                <h2>أداء أنواع المستخدمين</h2>
                <img src="user_type_response_times.png" alt="متوسط وقت الاستجابة لكل نوع مستخدم">
                <img src="user_type_failure_rate.png" alt="معدل الفشل لكل نوع مستخدم">
                
                <h3>مقارنة أداء أنواع المستخدمين</h3>
                <table>
                    <tr>
                        <th>نوع المستخدم</th>
                        <th>عدد الطلبات</th>
                        <th>متوسط وقت الاستجابة (مللي ثانية)</th>
                        <th>عدد حالات الفشل</th>
                        <th>معدل الفشل (%)</th>
                    </tr>
    """
    
    # إضافة بيانات أنواع المستخدمين
    for _, row in user_types_df.iterrows():
        html += f"""
                    <tr>
                        <td>{row['user_type']}</td>
                        <td>{row['count']}</td>
                        <td>{row['avg_response_time']:.2f}</td>
                        <td>{row['failures']}</td>
                        <td>{row['failure_rate'] * 100:.2f}%</td>
                    </tr>
        """
    
    html += """
                </table>
            </div>
            
            <div class="recommendations">
                <h3>التوصيات والتحسينات</h3>
                <ul>
    """
    
    # إضافة توصيات بناءً على نتائج الاختبار
    recommendations = []
    
    # فحص أوقات الاستجابة
    slow_endpoints = response_times_df[response_times_df['avg'] > 1000]  # أكثر من 1 ثانية
    if not slow_endpoints.empty:
        recommendations.append("تحسين أداء نقاط النهاية البطيئة من خلال تحسين الاستعلامات وإضافة التخزين المؤقت.")
    
    # فحص معدل الفشل
    high_failure_endpoints = throughput_df[throughput_df['failure_rate'] > 0.05]  # أكثر من 5%
    if not high_failure_endpoints.empty:
        recommendations.append("معالجة نقاط النهاية ذات معدل الفشل المرتفع من خلال تحسين معالجة الأخطاء وزيادة المهلة الزمنية.")
    
    # فحص أداء أنواع المستخدمين
    if not user_types_df.empty:
        slow_user_type = user_types_df.loc[user_types_df['avg_response_time'].idxmax()]
        recommendations.append(f"تحسين أداء عمليات {slow_user_type['user_type']} من خلال تحسين الاستعلامات وتقليل عدد العمليات.")
    
    # توصيات عامة
    recommendations.extend([
        "تنفيذ التخزين المؤقت للبيانات المتكررة الاستخدام لتقليل الوصول إلى قاعدة البيانات.",
        "تحسين أداء قاعدة البيانات من خلال إضافة فهارس وتحسين الاستعلامات.",
        "تنفيذ التوازن الأمثل للحمل لتوزيع الطلبات بشكل متساوٍ عبر خوادم متعددة.",
        "زيادة عدد العمال في خادم الويب لمعالجة المزيد من الطلبات المتزامنة.",
        "تنفيذ استراتيجية التخزين المؤقت للصفحات الثابتة والموارد الثابتة.",
        "تحسين أداء نموذج Llama 3 المحلي من خلال تقليل حجم النموذج أو استخدام وحدة معالجة رسومات (GPU).",
        "تنفيذ آلية الحد من معدل الطلبات لمنع هجمات الحرمان من الخدمة (DoS)."
    ])
    
    # إضافة التوصيات إلى التقرير
    for recommendation in recommendations:
        html += f"<li>{recommendation}</li>\n"
    
    html += """
                </ul>
            </div>
            
            <h2>الخلاصة</h2>
            <p>بناءً على نتائج اختبار الأداء، يمكن للمنصة التعامل مع العدد المطلوب من المستخدمين المتزامنين (10,000 مستخدم) مع تنفيذ التحسينات المقترحة أعلاه. يجب إجراء اختبارات إضافية بعد تنفيذ هذه التحسينات للتأكد من تحقيق الأهداف المطلوبة.</p>
        </div>
    </body>
    </html>
    """
    
    # حفظ التقرير في ملف HTML
    with open(f"{report_dir}/performance_report.html", "w", encoding="utf-8") as f:
        f.write(html)

def main():
    """الدالة الرئيسية"""
    if len(sys.argv) < 2:
        print("الاستخدام: python analyze_results.py <path_to_results.json>")
        sys.exit(1)
    
    results_file = sys.argv[1]
    results = load_results(results_file)
    
    report_dir = create_report_directory()
    print(f"إنشاء التقارير في المجلد: {report_dir}")
    
    response_times_df = analyze_response_times(results, report_dir)
    throughput_df = analyze_throughput(results, report_dir)
    user_types_df = analyze_user_types(results, report_dir)
    
    generate_html_report(report_dir, response_times_df, throughput_df, user_types_df, results)
    
    print(f"تم إنشاء التقرير بنجاح في: {report_dir}/performance_report.html")

if __name__ == "__main__":
    main()

