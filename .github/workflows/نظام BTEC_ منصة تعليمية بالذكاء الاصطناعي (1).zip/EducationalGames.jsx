import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  HomeIcon,
  ArrowLeftIcon,
  Star,
  Trophy,
  Search,
  Filter
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const EducationalGames = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [games, setGames] = useState([]);
  const [leaderboard, setLeaderboard] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    // محاكاة تحميل البيانات
    const loadData = async () => {
      setIsLoading(true);
      try {
        // محاكاة تأخير الشبكة
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // بيانات وهمية للعرض
        setGames([
          {
            id: 1,
            title: 'رحلة الأعمال',
            description: 'لعبة محاكاة لإدارة مشروع تجاري من البداية إلى النجاح',
            image: '/src/assets/images/eduverse_btec_educational_games.png',
            difficulty: 2,
            category: 'إدارة الأعمال',
            players: 1250
          },
          {
            id: 2,
            title: 'تحدي الأسئلة',
            description: 'اختبر معلوماتك في مختلف المجالات من خلال أسئلة تفاعلية',
            image: '/src/assets/images/eduverse_btec_educational_games.png',
            difficulty: 1,
            category: 'معلومات عامة',
            players: 2340
          },
          {
            id: 3,
            title: 'مشروع الفريق',
            description: 'تعلم مهارات العمل الجماعي من خلال مشاريع افتراضية',
            image: '/src/assets/images/eduverse_btec_educational_games.png',
            difficulty: 2,
            category: 'إدارة المشاريع',
            players: 980
          },
          {
            id: 4,
            title: 'مغامرة حل المسائل',
            description: 'حل المشكلات المعقدة في بيئة مغامرة تفاعلية',
            image: '/src/assets/images/eduverse_btec_educational_games.png',
            difficulty: 3,
            category: 'رياضيات',
            players: 750
          }
        ]);
        
        setLeaderboard([
          { id: 1, name: 'ريحان', score: 1250, badge: 'ذهبي' },
          { id: 2, name: 'سارة', score: 1120, badge: 'ذهبي' },
          { id: 3, name: 'محمد', score: 980, badge: 'فضي' },
          { id: 4, name: 'لينا', score: 870, badge: 'فضي' },
          { id: 5, name: 'عمر', score: 760, badge: 'برونزي' }
        ]);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadData();
  }, []);

  // تصفية الألعاب حسب البحث
  const filteredGames = games.filter(game => 
    game.title.includes(searchQuery) || 
    game.description.includes(searchQuery) ||
    game.category.includes(searchQuery)
  );

  // تأثيرات الحركة للبطاقات
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100
      }
    }
  };

  // عرض النجوم لمستوى الصعوبة
  const DifficultyStars = ({ level }) => {
    return (
      <div className="flex">
        {[1, 2, 3].map((star) => (
          <Star
            key={star}
            className={`h-4 w-4 ${star <= level ? 'text-accent fill-accent' : 'text-muted'}`}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* شريط التنقل العلوي */}
      <header className="bg-primary text-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <Link to="/" className="ml-2">
              <Button variant="ghost" size="icon" className="text-white hover:bg-primary-foreground/10">
                <ArrowLeftIcon className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-bold">قاعة الألعاب التعليمية</h1>
          </div>
          
          <Link to="/">
            <Button variant="ghost" size="icon" className="text-white hover:bg-primary-foreground/10">
              <HomeIcon className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
              <p className="mt-4 text-muted-foreground">جاري تحميل الألعاب...</p>
            </div>
          </div>
        ) : (
          <>
            {/* شريط البحث */}
            <div className="flex items-center mb-6">
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="ابحث عن الألعاب..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-3 pr-10 text-right"
                />
              </div>
              <Button variant="outline" size="icon" className="mr-2">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
            
            {/* قائمة الألعاب */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                className="col-span-1 md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6"
              >
                {filteredGames.map((game) => (
                  <GameCard key={game.id} game={game} />
                ))}
              </motion.div>
            </div>
            
            {/* المتصدرون */}
            <div className="mt-8">
              <h3 className="text-xl font-bold text-primary mb-4 flex items-center">
                <Trophy className="h-5 w-5 ml-2 text-accent" />
                المتصدرون
              </h3>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <table className="w-full">
                  <thead className="bg-muted/50">
                    <tr>
                      <th className="py-3 px-4 text-right">#</th>
                      <th className="py-3 px-4 text-right">اللاعب</th>
                      <th className="py-3 px-4 text-right">النقاط</th>
                      <th className="py-3 px-4 text-right">الشارة</th>
                    </tr>
                  </thead>
                  <tbody>
                    {leaderboard.map((player, index) => (
                      <tr key={player.id} className={index % 2 === 0 ? 'bg-muted/10' : ''}>
                        <td className="py-3 px-4">{index + 1}</td>
                        <td className="py-3 px-4 font-medium">{player.name}</td>
                        <td className="py-3 px-4">{player.score}</td>
                        <td className="py-3 px-4">
                          <span className={`inline-block px-2 py-1 rounded text-xs ${
                            player.badge === 'ذهبي' 
                              ? 'bg-accent/20 text-accent' 
                              : player.badge === 'فضي'
                                ? 'bg-muted text-muted-foreground'
                                : 'bg-amber-700/20 text-amber-700'
                          }`}>
                            {player.badge}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </main>

      <footer className="bg-primary/80 text-white p-4 text-center">
        <p className="text-sm">© 2025 EduverseAI - قلعة BTEC. جميع الحقوق محفوظة.</p>
      </footer>
    </div>
  );
  
  // مكون بطاقة اللعبة
  function GameCard({ game }) {
    return (
      <motion.div
        variants={itemVariants}
        whileHover={{ scale: 1.02 }}
        className="bg-accent/10 rounded-lg shadow-md overflow-hidden transition-all hover:shadow-lg"
      >
        <div className="relative h-48">
          <img 
            src={game.image} 
            alt={game.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-4">
            <h3 className="text-xl font-bold text-white">{game.title}</h3>
            <div className="flex items-center justify-between mt-2">
              <span className="text-white/90 text-sm">{game.category}</span>
              <DifficultyStars level={game.difficulty} />
            </div>
          </div>
        </div>
        
        <div className="p-4">
          <p className="text-muted-foreground mb-4">{game.description}</p>
          
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
              </svg>
              {game.players} لاعب
            </span>
            
            <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">
              ابدأ اللعب
            </Button>
          </div>
        </div>
      </motion.div>
    );
  }
};

export default EducationalGames;

