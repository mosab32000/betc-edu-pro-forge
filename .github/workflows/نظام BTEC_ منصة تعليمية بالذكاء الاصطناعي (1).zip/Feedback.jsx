import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  HomeIcon,
  ArrowLeftIcon,
  CheckCircleIcon,
  TrendingUpIcon,
  ThumbsUpIcon,
  AlertCircleIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';

const Feedback = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [feedback, setFeedback] = useState(null);
  const [progressData, setProgressData] = useState([]);

  useEffect(() => {
    // محاكاة تحميل البيانات
    const loadData = async () => {
      setIsLoading(true);
      try {
        // محاكاة تأخير الشبكة
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // بيانات وهمية للعرض
        setFeedback({
          title: 'تقرير عن تأثير التكنولوجيا على الأعمال',
          aiAnalysis: {
            strengths: [
              'المقال منظم وبطور فهماً للموضوع',
            ],
            improvements: [
              'يجب ضبط القواعد النحوية في بعض العبارات',
              'المطلوب توضيح بعض الأفكار بمزيد التفصيل'
            ]
          },
          teacherComments: 'أحسنت! تحليل جيد للموضوع مع بعض الأخطاء النحوية البسيطة. أرجو التركيز على دعم الأفكار بأمثلة أكثر في المرة القادمة.',
          score: 85,
          verified: true
        });
        
        setProgressData([
          { month: 'يناير', score: 65 },
          { month: 'فبراير', score: 70 },
          { month: 'مارس', score: 62 },
          { month: 'أبريل', score: 75 },
          { month: 'مايو', score: 80 },
          { month: 'يونيو', score: 85 }
        ]);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadData();
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* شريط التنقل العلوي */}
      <header className="bg-primary text-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <Link to="/" className="ml-2">
              <Button variant="ghost" size="icon" className="text-white hover:bg-primary-foreground/10">
                <ArrowLeftIcon className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-bold">التغذية الراجعة الذكية</h1>
          </div>
          
          <Link to="/">
            <Button variant="ghost" size="icon" className="text-white hover:bg-primary-foreground/10">
              <HomeIcon className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
              <p className="mt-4 text-muted-foreground">جاري تحليل المهمة...</p>
            </div>
          </div>
        ) : (
          <>
            {/* عنوان المهمة */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mb-6"
            >
              <h2 className="text-2xl font-bold text-primary">{feedback.title}</h2>
              <div className="flex items-center mt-2">
                <div className="bg-secondary text-white text-sm px-3 py-1 rounded-full">
                  {feedback.score}%
                </div>
                <Progress value={feedback.score} className="h-2 flex-1 mx-3" />
              </div>
            </motion.div>
            
            {/* التحليل بواسطة الذكاء الاصطناعي */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="bg-white rounded-lg shadow-md p-6 mb-6"
            >
              <h3 className="text-lg font-bold text-primary mb-4">التحليل بواسطة الذكاء الاصطناعي</h3>
              
              <div className="mb-4">
                <h4 className="text-secondary font-medium flex items-center mb-2">
                  <ThumbsUpIcon className="h-5 w-5 ml-2" />
                  نقاط القوة
                </h4>
                <ul className="space-y-2 pr-7 list-disc">
                  {feedback.aiAnalysis.strengths.map((strength, index) => (
                    <li key={index} className="text-muted-foreground">
                      {strength}
                    </li>
                  ))}
                </ul>
              </div>
              
              <div>
                <h4 className="text-accent font-medium flex items-center mb-2">
                  <AlertCircleIcon className="h-5 w-5 ml-2" />
                  مجالات التحسين
                </h4>
                <ul className="space-y-2 pr-7 list-disc">
                  {feedback.aiAnalysis.improvements.map((improvement, index) => (
                    <li key={index} className="text-muted-foreground">
                      {improvement}
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
            
            {/* رسم بياني للتقدم */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="bg-white rounded-lg shadow-md p-6 mb-6"
            >
              <h3 className="text-lg font-bold text-primary mb-4 flex items-center">
                <TrendingUpIcon className="h-5 w-5 ml-2" />
                التقدم
              </h3>
              
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={progressData}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis domain={[0, 100]} />
                    <Tooltip />
                    <Line 
                      type="monotone" 
                      dataKey="score" 
                      stroke="#009975" 
                      strokeWidth={2}
                      activeDot={{ r: 8 }} 
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </motion.div>
            
            {/* تعليقات المعلم */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="bg-white rounded-lg shadow-md p-6 mb-6"
            >
              <h3 className="text-lg font-bold text-primary mb-4">ملاحظات المعلم</h3>
              <div className="flex">
                <div className="h-10 w-10 rounded-full bg-primary text-white flex items-center justify-center ml-3 flex-shrink-0">
                  <span className="text-sm font-bold">م</span>
                </div>
                <p className="text-muted-foreground">{feedback.teacherComments}</p>
              </div>
            </motion.div>
            
            {/* التحقق من البلوكتشين */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.5 }}
              className="bg-white rounded-lg p-4 shadow-sm border border-border flex items-center justify-center"
            >
              <CheckCircleIcon className="h-5 w-5 text-secondary ml-2" />
              <p className="text-sm">تم التحقق: بواسطة سلسلة الكتل</p>
            </motion.div>
          </>
        )}
      </main>

      <footer className="bg-primary/80 text-white p-4 text-center">
        <p className="text-sm">© 2025 EduverseAI - قلعة BTEC. جميع الحقوق محفوظة.</p>
      </footer>
    </div>
  );
};

export default Feedback;

