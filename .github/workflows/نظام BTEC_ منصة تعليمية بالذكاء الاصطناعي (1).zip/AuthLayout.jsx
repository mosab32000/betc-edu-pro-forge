import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Sun, Moon } from 'lucide-react';

/**
 * مكون تخطيط المصادقة
 * @param {object} props - خصائص المكون
 * @returns {JSX.Element} - مكون تخطيط المصادقة
 */
const AuthLayout = ({ children }) => {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [isDarkMode, setIsDarkMode] = useState(false);
  
  // التحقق من حالة المصادقة
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/');
    }
  }, [isAuthenticated, navigate]);
  
  // تبديل وضع الظلام
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);
  
  return (
    <div className="min-h-screen bg-background rtl flex flex-col">
      {/* الشريط العلوي */}
      <header className="bg-primary text-primary-foreground shadow-md">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center">
            <img 
              src="/src/assets/images/eduverse-btec-logo.png" 
              alt="EduverseAI - قلعة BTEC" 
              className="h-10"
            />
          </div>
          
          <div className="flex items-center">
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2 rounded-md hover:bg-primary-foreground/10"
            >
              {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>
      
      {/* المحتوى الرئيسي */}
      <main className="flex-1 flex items-center justify-center castle-bg">
        <div className="container mx-auto px-4 py-8">
          {children}
        </div>
      </main>
      
      {/* التذييل */}
      <footer className="bg-primary text-primary-foreground py-4">
        <div className="container mx-auto px-4 text-center">
          <p>جميع الحقوق محفوظة &copy; {new Date().getFullYear()} - منصة EduverseAI - قلعة BTEC</p>
        </div>
      </footer>
    </div>
  );
};

export default AuthLayout;

