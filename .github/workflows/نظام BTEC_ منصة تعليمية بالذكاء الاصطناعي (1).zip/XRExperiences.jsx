import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  HomeIcon,
  ArrowLeftIcon,
  Star,
  Filter
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const XRExperiences = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [experiences, setExperiences] = useState([]);
  const [activeTab, setActiveTab] = useState('all');

  useEffect(() => {
    // محاكاة تحميل البيانات
    const loadData = async () => {
      setIsLoading(true);
      try {
        // محاكاة تأخير الشبكة
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // بيانات وهمية للعرض
        setExperiences([
          {
            id: 1,
            title: 'مختبر الكيمياء',
            description: 'استكشف التفاعلات الكيميائية في مختبر افتراضي آمن',
            image: '/src/assets/images/eduverse_btec_xr_screen.png',
            difficulty: 3,
            category: 'ar',
            subject: 'علوم'
          },
          {
            id: 2,
            title: 'استكشاف البتراء',
            description: 'جولة افتراضية في مدينة البتراء التاريخية',
            image: '/src/assets/images/eduverse_btec_xr_screen.png',
            difficulty: 1,
            category: 'vr',
            subject: 'تاريخ'
          },
          {
            id: 3,
            title: 'محاكاة الأعمال',
            description: 'تعلم إدارة الأعمال من خلال محاكاة واقعية',
            image: '/src/assets/images/eduverse_btec_xr_screen.png',
            difficulty: 2,
            category: 'vr',
            subject: 'أعمال'
          },
          {
            id: 4,
            title: 'رحلة داخل الخلية',
            description: 'استكشف مكونات الخلية الحية بتقنية الواقع المعزز',
            image: '/src/assets/images/eduverse_btec_xr_screen.png',
            difficulty: 2,
            category: 'ar',
            subject: 'علوم'
          },
          {
            id: 5,
            title: 'تصميم المباني',
            description: 'صمم وابنِ مباني افتراضية باستخدام مبادئ الهندسة المعمارية',
            image: '/src/assets/images/eduverse_btec_xr_screen.png',
            difficulty: 3,
            category: 'vr',
            subject: 'هندسة'
          }
        ]);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadData();
  }, []);

  // تصفية التجارب حسب الفئة
  const filteredExperiences = activeTab === 'all' 
    ? experiences 
    : experiences.filter(exp => exp.category === activeTab);

  // تأثيرات الحركة للبطاقات
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100
      }
    }
  };

  // عرض النجوم لمستوى الصعوبة
  const DifficultyStars = ({ level }) => {
    return (
      <div className="flex">
        {[1, 2, 3].map((star) => (
          <Star
            key={star}
            className={`h-4 w-4 ${star <= level ? 'text-accent fill-accent' : 'text-muted'}`}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* شريط التنقل العلوي */}
      <header className="bg-primary text-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <Link to="/" className="ml-2">
              <Button variant="ghost" size="icon" className="text-white hover:bg-primary-foreground/10">
                <ArrowLeftIcon className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-bold">تجارب التعلم الغامرة</h1>
          </div>
          
          <Link to="/">
            <Button variant="ghost" size="icon" className="text-white hover:bg-primary-foreground/10">
              <HomeIcon className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
              <p className="mt-4 text-muted-foreground">جاري تحميل التجارب...</p>
            </div>
          </div>
        ) : (
          <>
            {/* علامات التبويب للتصفية */}
            <Tabs defaultValue="all" className="mb-6" onValueChange={setActiveTab}>
              <div className="flex items-center justify-between mb-4">
                <TabsList className="bg-muted">
                  <TabsTrigger value="all">الكل</TabsTrigger>
                  <TabsTrigger value="ar">الواقع المعزز</TabsTrigger>
                  <TabsTrigger value="vr">الواقع الافتراضي</TabsTrigger>
                </TabsList>
                
                <Button variant="outline" size="sm" className="flex items-center">
                  <Filter className="h-4 w-4 ml-1" />
                  <span>تصفية</span>
                </Button>
              </div>
              
              <TabsContent value="all" className="mt-0">
                <motion.div
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  className="space-y-4"
                >
                  {filteredExperiences.map((experience) => (
                    <ExperienceCard key={experience.id} experience={experience} />
                  ))}
                </motion.div>
              </TabsContent>
              
              <TabsContent value="ar" className="mt-0">
                <motion.div
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  className="space-y-4"
                >
                  {filteredExperiences.map((experience) => (
                    <ExperienceCard key={experience.id} experience={experience} />
                  ))}
                </motion.div>
              </TabsContent>
              
              <TabsContent value="vr" className="mt-0">
                <motion.div
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  className="space-y-4"
                >
                  {filteredExperiences.map((experience) => (
                    <ExperienceCard key={experience.id} experience={experience} />
                  ))}
                </motion.div>
              </TabsContent>
            </Tabs>
          </>
        )}
      </main>

      <footer className="bg-primary/80 text-white p-4 text-center">
        <p className="text-sm">© 2025 EduverseAI - قلعة BTEC. جميع الحقوق محفوظة.</p>
      </footer>
    </div>
  );
  
  // مكون بطاقة التجربة
  function ExperienceCard({ experience }) {
    return (
      <motion.div
        variants={itemVariants}
        whileHover={{ scale: 1.02 }}
        className="bg-white rounded-lg shadow-md overflow-hidden transition-all hover:shadow-lg"
      >
        <div className="flex flex-col md:flex-row">
          <div className="md:w-1/3 h-48 md:h-auto">
            <img 
              src={experience.image} 
              alt={experience.title}
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="p-4 md:w-2/3 flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start">
                <h3 className="text-xl font-bold text-primary">{experience.title}</h3>
                <span className="bg-muted text-xs px-2 py-1 rounded">
                  {experience.category === 'ar' ? 'واقع معزز' : 'واقع افتراضي'}
                </span>
              </div>
              
              <p className="text-muted-foreground mt-2">{experience.description}</p>
              
              <div className="flex items-center mt-3">
                <span className="text-xs text-muted-foreground ml-2">مستوى الصعوبة:</span>
                <DifficultyStars level={experience.difficulty} />
              </div>
              
              <div className="mt-2">
                <span className="inline-block bg-primary/10 text-primary text-xs px-2 py-1 rounded">
                  {experience.subject}
                </span>
              </div>
            </div>
            
            <div className="mt-4">
              <Button className="bg-secondary hover:bg-secondary/90 text-white">
                ابدأ التجربة
              </Button>
            </div>
          </div>
        </div>
      </motion.div>
    );
  }
};

export default XRExperiences;

