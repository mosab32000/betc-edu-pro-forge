"""
مسارات API للمهام التعليمية في منصة EduverseAI - قلعة BTEC
"""
from flask import Blueprint, request, jsonify
from bson import ObjectId, errors as bson_errors
from datetime import datetime
from src.models import db, Task
from src.routes.users import token_required

# إنشاء Blueprint للمهام
tasks_bp = Blueprint('tasks', __name__)

@tasks_bp.route('/tasks', methods=['POST'])
@token_required
def create_task():
    """
    إنشاء مهمة جديدة
    """
    # التحقق من صلاحيات المستخدم
    if request.current_user['role'] not in ['admin', 'teacher']:
        return jsonify({'message': 'غير مصرح لك بإنشاء مهام!'}), 403
    
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    if not data or not data.get('title') or not data.get('description') or not data.get('subject'):
        return jsonify({'message': 'البيانات غير مكتملة!'}), 400
    
    # إنشاء كائن المهمة
    task = Task(
        title=data['title'],
        description=data['description'],
        subject=data['subject'],
        instructions=data.get('instructions', []),
        criteria=data.get('criteria', []),
        resources=data.get('resources', []),
        due_date=datetime.fromisoformat(data['due_date']) if 'due_date' in data and data['due_date'] else None,
        created_by=request.current_user['_id']
    )
    
    # إضافة البيانات الإضافية
    if 'difficulty' in data:
        task.difficulty = data['difficulty']
    if 'points' in data:
        task.points = data['points']
    if 'estimated_time' in data:
        task.estimated_time = data['estimated_time']
    if 'tags' in data:
        task.tags = data['tags']
    if 'xr_experiences' in data:
        task.xr_experiences = data['xr_experiences']
    
    # حفظ المهمة في قاعدة البيانات
    db.tasks.insert_one(task.to_dict())
    
    return jsonify({
        'message': 'تم إنشاء المهمة بنجاح!',
        'task': task.to_dict()
    }), 201

@tasks_bp.route('/tasks', methods=['GET'])
@token_required
def get_tasks():
    """
    الحصول على قائمة المهام
    """
    # الحصول على معلمات البحث والترتيب والتصفح
    search = request.args.get('search', '')
    subject = request.args.get('subject', '')
    difficulty = request.args.get('difficulty', '')
    tags = request.args.get('tags', '')
    sort_by = request.args.get('sort_by', 'created_at')
    sort_order = int(request.args.get('sort_order', '-1'))
    page = int(request.args.get('page', '1'))
    limit = int(request.args.get('limit', '10'))
    
    # بناء استعلام البحث
    query = {}
    if search:
        query['$or'] = [
            {'title': {'$regex': search, '$options': 'i'}},
            {'description': {'$regex': search, '$options': 'i'}}
        ]
    if subject:
        query['subject'] = subject
    if difficulty:
        query['difficulty'] = difficulty
    if tags:
        query['tags'] = {'$in': tags.split(',')}
    
    # للطلاب، عرض المهام المخصصة لهم فقط
    if request.current_user['role'] == 'student':
        # يمكن إضافة منطق لعرض المهام المخصصة للطالب فقط
        pass
    # للمعلمين، عرض المهام التي أنشأوها فقط
    elif request.current_user['role'] == 'teacher':
        query['created_by'] = request.current_user['_id']
    
    # حساب عدد المهام
    total = db.tasks.count_documents(query)
    
    # الحصول على المهام مع التصفح والترتيب
    tasks_cursor = db.tasks.find(query).sort(sort_by, sort_order).skip((page - 1) * limit).limit(limit)
    
    # تحويل النتائج إلى قائمة
    tasks = []
    for task_data in tasks_cursor:
        # تحويل ObjectId إلى سلسلة
        task_data['_id'] = str(task_data['_id'])
        task_data['created_by'] = str(task_data['created_by']) if task_data['created_by'] else None
        
        tasks.append(task_data)
    
    return jsonify({
        'message': 'تم الحصول على قائمة المهام بنجاح!',
        'total': total,
        'page': page,
        'limit': limit,
        'pages': (total + limit - 1) // limit,
        'tasks': tasks
    }), 200

@tasks_bp.route('/tasks/<task_id>', methods=['GET'])
@token_required
def get_task(task_id):
    """
    الحصول على معلومات مهمة محددة
    """
    try:
        # البحث عن المهمة
        task_data = db.tasks.find_one({'_id': ObjectId(task_id)})
        if not task_data:
            return jsonify({'message': 'المهمة غير موجودة!'}), 404
        
        # التحقق من صلاحيات المستخدم
        if request.current_user['role'] == 'teacher' and task_data['created_by'] != request.current_user['_id']:
            return jsonify({'message': 'غير مصرح لك بالوصول إلى هذه المهمة!'}), 403
        
        # تحويل ObjectId إلى سلسلة
        task_data['_id'] = str(task_data['_id'])
        task_data['created_by'] = str(task_data['created_by']) if task_data['created_by'] else None
        
        # الحصول على معلومات المنشئ
        if task_data['created_by']:
            creator = db.users.find_one({'_id': ObjectId(task_data['created_by'])})
            if creator:
                task_data['creator_info'] = {
                    'username': creator['username'],
                    'first_name': creator.get('first_name', ''),
                    'last_name': creator.get('last_name', '')
                }
        
        # الحصول على معلومات تجارب XR المرتبطة
        if 'xr_experiences' in task_data and task_data['xr_experiences']:
            xr_experiences = []
            for xr_id in task_data['xr_experiences']:
                xr_data = db.xr_experiences.find_one({'_id': ObjectId(xr_id)})
                if xr_data:
                    xr_data['_id'] = str(xr_data['_id'])
                    xr_data['created_by'] = str(xr_data['created_by']) if xr_data['created_by'] else None
                    xr_experiences.append(xr_data)
            task_data['xr_experiences_data'] = xr_experiences
        
        return jsonify({
            'message': 'تم الحصول على معلومات المهمة بنجاح!',
            'task': task_data
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف المهمة غير صالح!'}), 400

@tasks_bp.route('/tasks/<task_id>', methods=['PUT'])
@token_required
def update_task(task_id):
    """
    تحديث مهمة محددة
    """
    try:
        # البحث عن المهمة
        task_data = db.tasks.find_one({'_id': ObjectId(task_id)})
        if not task_data:
            return jsonify({'message': 'المهمة غير موجودة!'}), 404
        
        # التحقق من صلاحيات المستخدم
        if request.current_user['role'] == 'student':
            return jsonify({'message': 'غير مصرح لك بتحديث المهام!'}), 403
        elif request.current_user['role'] == 'teacher' and str(task_data['created_by']) != str(request.current_user['_id']):
            return jsonify({'message': 'غير مصرح لك بتحديث هذه المهمة!'}), 403
        
        data = request.get_json()
        if not data:
            return jsonify({'message': 'لا توجد بيانات للتحديث!'}), 400
        
        # تحديد البيانات القابلة للتحديث
        update_data = {}
        allowed_fields = [
            'title', 'description', 'subject', 'instructions', 'criteria',
            'resources', 'due_date', 'difficulty', 'points', 'estimated_time',
            'tags', 'xr_experiences'
        ]
        
        for field in allowed_fields:
            if field in data:
                # معالجة خاصة لتاريخ الاستحقاق
                if field == 'due_date' and data[field]:
                    update_data[field] = datetime.fromisoformat(data[field])
                else:
                    update_data[field] = data[field]
        
        # تحديث تاريخ التحديث
        update_data['updated_at'] = datetime.utcnow()
        
        # تحديث المهمة في قاعدة البيانات
        if update_data:
            db.tasks.update_one({'_id': ObjectId(task_id)}, {'$set': update_data})
        
        # الحصول على بيانات المهمة المحدثة
        updated_task = db.tasks.find_one({'_id': ObjectId(task_id)})
        
        # تحويل ObjectId إلى سلسلة
        updated_task['_id'] = str(updated_task['_id'])
        updated_task['created_by'] = str(updated_task['created_by']) if updated_task['created_by'] else None
        
        return jsonify({
            'message': 'تم تحديث المهمة بنجاح!',
            'task': updated_task
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف المهمة غير صالح!'}), 400

@tasks_bp.route('/tasks/<task_id>', methods=['DELETE'])
@token_required
def delete_task(task_id):
    """
    حذف مهمة محددة
    """
    try:
        # البحث عن المهمة
        task_data = db.tasks.find_one({'_id': ObjectId(task_id)})
        if not task_data:
            return jsonify({'message': 'المهمة غير موجودة!'}), 404
        
        # التحقق من صلاحيات المستخدم
        if request.current_user['role'] == 'student':
            return jsonify({'message': 'غير مصرح لك بحذف المهام!'}), 403
        elif request.current_user['role'] == 'teacher' and str(task_data['created_by']) != str(request.current_user['_id']):
            return jsonify({'message': 'غير مصرح لك بحذف هذه المهمة!'}), 403
        
        # حذف التقييمات المرتبطة بالمهمة
        db.assessments.delete_many({'task_id': ObjectId(task_id)})
        
        # حذف المهمة
        db.tasks.delete_one({'_id': ObjectId(task_id)})
        
        return jsonify({
            'message': 'تم حذف المهمة بنجاح!'
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف المهمة غير صالح!'}), 400

@tasks_bp.route('/tasks/subjects', methods=['GET'])
@token_required
def get_subjects():
    """
    الحصول على قائمة المواد الدراسية
    """
    # الحصول على قائمة المواد الدراسية الفريدة
    subjects = db.tasks.distinct('subject')
    
    return jsonify({
        'message': 'تم الحصول على قائمة المواد الدراسية بنجاح!',
        'subjects': subjects
    }), 200

@tasks_bp.route('/tasks/tags', methods=['GET'])
@token_required
def get_tags():
    """
    الحصول على قائمة الوسوم
    """
    # الحصول على قائمة الوسوم الفريدة
    tags = db.tasks.distinct('tags')
    
    # إزالة القيم الفارغة
    tags = [tag for tag in tags if tag]
    
    return jsonify({
        'message': 'تم الحصول على قائمة الوسوم بنجاح!',
        'tags': tags
    }), 200

