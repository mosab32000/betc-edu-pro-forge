"""
مسارات API للمستخدمين في منصة EduverseAI - قلعة BTEC
"""
from flask import Blueprint, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
import datetime
import os
from functools import wraps
from bson import ObjectId, errors as bson_errors
from src.models import db, User

# إنشاء Blueprint للمستخدمين
users_bp = Blueprint('users', __name__)

# الحصول على المفتاح السري من متغيرات البيئة
SECRET_KEY = os.getenv('JWT_SECRET_KEY', 'eduverse_btec_secret_key')

def token_required(f):
    """
    مصادقة رمز JWT
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        
        # التحقق من وجود رمز في رأس الطلب
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            if auth_header.startswith('Bearer '):
                token = auth_header.split(' ')[1]
        
        if not token:
            return jsonify({'message': 'رمز المصادقة مفقود!'}), 401
        
        try:
            # فك تشفير الرمز
            data = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
            current_user = db.users.find_one({'_id': ObjectId(data['user_id'])})
            if not current_user:
                return jsonify({'message': 'المستخدم غير موجود!'}), 401
        except jwt.ExpiredSignatureError:
            return jsonify({'message': 'انتهت صلاحية رمز المصادقة!'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'message': 'رمز المصادقة غير صالح!'}), 401
        
        # إضافة المستخدم الحالي إلى الطلب
        request.current_user = current_user
        return f(*args, **kwargs)
    
    return decorated

@users_bp.route('/register', methods=['POST'])
def register():
    """
    تسجيل مستخدم جديد
    """
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    if not data or not data.get('username') or not data.get('email') or not data.get('password'):
        return jsonify({'message': 'البيانات غير مكتملة!'}), 400
    
    # التحقق من عدم وجود مستخدم بنفس اسم المستخدم أو البريد الإلكتروني
    if db.users.find_one({'username': data['username']}):
        return jsonify({'message': 'اسم المستخدم موجود بالفعل!'}), 400
    
    if db.users.find_one({'email': data['email']}):
        return jsonify({'message': 'البريد الإلكتروني موجود بالفعل!'}), 400
    
    # إنشاء تجزئة لكلمة المرور
    password_hash = generate_password_hash(data['password'])
    
    # إنشاء كائن المستخدم
    user = User(
        username=data['username'],
        email=data['email'],
        password_hash=password_hash,
        role=data.get('role', 'student'),
        first_name=data.get('first_name', ''),
        last_name=data.get('last_name', ''),
        profile_image=data.get('profile_image', '')
    )
    
    # حفظ المستخدم في قاعدة البيانات
    db.users.insert_one(user.to_dict())
    
    return jsonify({
        'message': 'تم تسجيل المستخدم بنجاح!',
        'user': {
            'id': str(user._id),
            'username': user.username,
            'email': user.email,
            'role': user.role
        }
    }), 201

@users_bp.route('/login', methods=['POST'])
def login():
    """
    تسجيل دخول المستخدم
    """
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    if not data or not data.get('username') or not data.get('password'):
        return jsonify({'message': 'البيانات غير مكتملة!'}), 400
    
    # البحث عن المستخدم
    user_data = db.users.find_one({'username': data['username']})
    if not user_data:
        return jsonify({'message': 'اسم المستخدم أو كلمة المرور غير صحيحة!'}), 401
    
    # التحقق من كلمة المرور
    if not check_password_hash(user_data['password_hash'], data['password']):
        return jsonify({'message': 'اسم المستخدم أو كلمة المرور غير صحيحة!'}), 401
    
    # إنشاء رمز JWT
    token = jwt.encode({
        'user_id': str(user_data['_id']),
        'username': user_data['username'],
        'role': user_data['role'],
        'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=24)
    }, SECRET_KEY, algorithm='HS256')
    
    return jsonify({
        'message': 'تم تسجيل الدخول بنجاح!',
        'token': token,
        'user': {
            'id': str(user_data['_id']),
            'username': user_data['username'],
            'email': user_data['email'],
            'role': user_data['role'],
            'first_name': user_data.get('first_name', ''),
            'last_name': user_data.get('last_name', '')
        }
    }), 200

@users_bp.route('/profile', methods=['GET'])
@token_required
def get_profile():
    """
    الحصول على الملف الشخصي للمستخدم الحالي
    """
    user_data = request.current_user
    
    # إزالة كلمة المرور من البيانات
    user_data.pop('password_hash', None)
    
    # تحويل ObjectId إلى سلسلة
    user_data['_id'] = str(user_data['_id'])
    
    return jsonify({
        'message': 'تم الحصول على الملف الشخصي بنجاح!',
        'user': user_data
    }), 200

@users_bp.route('/profile', methods=['PUT'])
@token_required
def update_profile():
    """
    تحديث الملف الشخصي للمستخدم الحالي
    """
    data = request.get_json()
    user_id = request.current_user['_id']
    
    # التحقق من البيانات
    if not data:
        return jsonify({'message': 'لا توجد بيانات للتحديث!'}), 400
    
    # تحديد البيانات القابلة للتحديث
    update_data = {}
    allowed_fields = ['first_name', 'last_name', 'profile_image']
    
    for field in allowed_fields:
        if field in data:
            update_data[field] = data[field]
    
    # تحديث كلمة المرور إذا تم توفيرها
    if 'password' in data and data['password']:
        update_data['password_hash'] = generate_password_hash(data['password'])
    
    # تحديث تاريخ التحديث
    update_data['updated_at'] = datetime.datetime.utcnow()
    
    # تحديث المستخدم في قاعدة البيانات
    if update_data:
        db.users.update_one({'_id': user_id}, {'$set': update_data})
    
    # الحصول على بيانات المستخدم المحدثة
    updated_user = db.users.find_one({'_id': user_id})
    
    # إزالة كلمة المرور من البيانات
    updated_user.pop('password_hash', None)
    
    # تحويل ObjectId إلى سلسلة
    updated_user['_id'] = str(updated_user['_id'])
    
    return jsonify({
        'message': 'تم تحديث الملف الشخصي بنجاح!',
        'user': updated_user
    }), 200

@users_bp.route('/users', methods=['GET'])
@token_required
def get_users():
    """
    الحصول على قائمة المستخدمين (للمشرفين فقط)
    """
    # التحقق من صلاحيات المستخدم
    if request.current_user['role'] != 'admin':
        return jsonify({'message': 'غير مصرح لك بالوصول إلى هذا المورد!'}), 403
    
    # الحصول على معلمات البحث والترتيب والتصفح
    search = request.args.get('search', '')
    sort_by = request.args.get('sort_by', 'username')
    sort_order = int(request.args.get('sort_order', '1'))
    page = int(request.args.get('page', '1'))
    limit = int(request.args.get('limit', '10'))
    
    # بناء استعلام البحث
    query = {}
    if search:
        query['$or'] = [
            {'username': {'$regex': search, '$options': 'i'}},
            {'email': {'$regex': search, '$options': 'i'}},
            {'first_name': {'$regex': search, '$options': 'i'}},
            {'last_name': {'$regex': search, '$options': 'i'}}
        ]
    
    # حساب عدد المستخدمين
    total = db.users.count_documents(query)
    
    # الحصول على المستخدمين مع التصفح والترتيب
    users_cursor = db.users.find(query).sort(sort_by, sort_order).skip((page - 1) * limit).limit(limit)
    
    # تحويل النتائج إلى قائمة
    users = []
    for user_data in users_cursor:
        # إزالة كلمة المرور من البيانات
        user_data.pop('password_hash', None)
        
        # تحويل ObjectId إلى سلسلة
        user_data['_id'] = str(user_data['_id'])
        
        users.append(user_data)
    
    return jsonify({
        'message': 'تم الحصول على قائمة المستخدمين بنجاح!',
        'total': total,
        'page': page,
        'limit': limit,
        'pages': (total + limit - 1) // limit,
        'users': users
    }), 200

@users_bp.route('/users/<user_id>', methods=['GET'])
@token_required
def get_user(user_id):
    """
    الحصول على معلومات مستخدم محدد
    """
    # التحقق من صلاحيات المستخدم
    current_user = request.current_user
    if current_user['role'] != 'admin' and str(current_user['_id']) != user_id:
        return jsonify({'message': 'غير مصرح لك بالوصول إلى هذا المورد!'}), 403
    
    try:
        # البحث عن المستخدم
        user_data = db.users.find_one({'_id': ObjectId(user_id)})
        if not user_data:
            return jsonify({'message': 'المستخدم غير موجود!'}), 404
        
        # إزالة كلمة المرور من البيانات
        user_data.pop('password_hash', None)
        
        # تحويل ObjectId إلى سلسلة
        user_data['_id'] = str(user_data['_id'])
        
        return jsonify({
            'message': 'تم الحصول على معلومات المستخدم بنجاح!',
            'user': user_data
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف المستخدم غير صالح!'}), 400

@users_bp.route('/users/<user_id>/badges', methods=['GET'])
@token_required
def get_user_badges(user_id):
    """
    الحصول على أوسمة مستخدم محدد
    """
    try:
        # البحث عن المستخدم
        user_data = db.users.find_one({'_id': ObjectId(user_id)})
        if not user_data:
            return jsonify({'message': 'المستخدم غير موجود!'}), 404
        
        # البحث عن أوسمة المستخدم
        user_badges_cursor = db.user_badges.find({'user_id': ObjectId(user_id)})
        
        # تحويل النتائج إلى قائمة
        user_badges = []
        for user_badge in user_badges_cursor:
            # الحصول على معلومات الوسام
            badge = db.badges.find_one({'_id': user_badge['badge_id']})
            if badge:
                # تحويل ObjectId إلى سلسلة
                badge['_id'] = str(badge['_id'])
                user_badge['_id'] = str(user_badge['_id'])
                user_badge['user_id'] = str(user_badge['user_id'])
                user_badge['badge_id'] = str(user_badge['badge_id'])
                
                # دمج معلومات الوسام مع معلومات العلاقة
                user_badges.append({
                    'user_badge': user_badge,
                    'badge': badge
                })
        
        return jsonify({
            'message': 'تم الحصول على أوسمة المستخدم بنجاح!',
            'user_id': user_id,
            'badges': user_badges
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف المستخدم غير صالح!'}), 400

