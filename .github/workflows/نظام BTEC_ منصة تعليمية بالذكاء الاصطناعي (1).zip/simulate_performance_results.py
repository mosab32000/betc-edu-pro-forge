#!/usr/bin/env python3
"""
سكربت لمحاكاة نتائج اختبار الأداء

يقوم هذا السكربت بإنشاء نتائج محاكاة لاختبار الأداء لتوضيح كيفية تحليل النتائج
وتقديم التوصيات لتحسين الأداء.

كيفية الاستخدام:
1. قم بتشغيل السكربت: python simulate_performance_results.py
"""

import json
import random
import numpy as np
import os
from datetime import datetime

def generate_realistic_response_times(num_requests, base_time=200, variance=100):
    """إنشاء أوقات استجابة واقعية"""
    # توزيع لوغاريتمي طبيعي لمحاكاة أوقات الاستجابة الواقعية
    response_times = np.random.lognormal(np.log(base_time), 0.5, num_requests)
    
    # إضافة بعض القيم الشاذة (outliers)
    outliers = np.random.choice(num_requests, size=int(num_requests * 0.05), replace=False)
    response_times[outliers] *= random.uniform(3, 10)
    
    return response_times.tolist()

def simulate_endpoint_performance():
    """محاكاة أداء نقاط النهاية المختلفة"""
    endpoints = [
        {"name": "/api/users/login", "base_time": 150, "requests": 2000},
        {"name": "/api/users/profile", "base_time": 100, "requests": 1500},
        {"name": "/api/tasks", "base_time": 200, "requests": 1800},
        {"name": "/api/tasks/{id}", "base_time": 120, "requests": 1200},
        {"name": "/api/assessments", "base_time": 300, "requests": 800},
        {"name": "/api/ai/chat", "base_time": 2000, "requests": 600},
        {"name": "/api/xr/experience/{id}", "base_time": 250, "requests": 400},
        {"name": "/api/xr/user-progress/{user}/{xr}", "base_time": 180, "requests": 350},
        {"name": "/api/badges/user/{user}", "base_time": 90, "requests": 300},
        {"name": "/api/blockchain/verify", "base_time": 500, "requests": 200}
    ]
    
    results = {}
    
    for endpoint in endpoints:
        response_times = generate_realistic_response_times(
            endpoint["requests"], 
            endpoint["base_time"]
        )
        
        # حساب الإحصائيات
        failures = int(endpoint["requests"] * random.uniform(0.01, 0.05))  # 1-5% معدل فشل
        successful = endpoint["requests"] - failures
        
        results[endpoint["name"]] = {
            "num_requests": endpoint["requests"],
            "num_failures": failures,
            "min_response_time": min(response_times),
            "max_response_time": max(response_times),
            "avg_response_time": np.mean(response_times),
            "median_response_time": np.median(response_times),
            "response_time_percentiles": {
                "50.0": np.percentile(response_times, 50),
                "90.0": np.percentile(response_times, 90),
                "95.0": np.percentile(response_times, 95),
                "99.0": np.percentile(response_times, 99)
            },
            "response_times": response_times
        }
    
    # إضافة إجمالي النتائج
    total_requests = sum(ep["requests"] for ep in endpoints)
    total_failures = sum(results[ep["name"]]["num_failures"] for ep in endpoints)
    all_response_times = []
    for ep in endpoints:
        all_response_times.extend(results[ep["name"]]["response_times"])
    
    results["Total"] = {
        "num_requests": total_requests,
        "num_failures": total_failures,
        "min_response_time": min(all_response_times),
        "max_response_time": max(all_response_times),
        "avg_response_time": np.mean(all_response_times),
        "median_response_time": np.median(all_response_times),
        "response_time_percentiles": {
            "50.0": np.percentile(all_response_times, 50),
            "90.0": np.percentile(all_response_times, 90),
            "95.0": np.percentile(all_response_times, 95),
            "99.0": np.percentile(all_response_times, 99)
        }
    }
    
    return results

def simulate_load_test_scenarios():
    """محاكاة سيناريوهات اختبار الحمل المختلفة"""
    scenarios = [
        {"users": 100, "duration": 300, "name": "100_users"},
        {"users": 1000, "duration": 300, "name": "1000_users"},
        {"users": 5000, "duration": 300, "name": "5000_users"},
        {"users": 10000, "duration": 300, "name": "10000_users"}
    ]
    
    results = {}
    
    for scenario in scenarios:
        # محاكاة تدهور الأداء مع زيادة عدد المستخدمين
        performance_factor = 1 + (scenario["users"] / 1000) * 0.2  # زيادة 20% لكل 1000 مستخدم
        
        stats = simulate_endpoint_performance()
        
        # تطبيق عامل الأداء على جميع الأوقات
        for endpoint, data in stats.items():
            if "response_times" in data:
                data["response_times"] = [t * performance_factor for t in data["response_times"]]
            
            for key in ["min_response_time", "max_response_time", "avg_response_time", "median_response_time"]:
                if key in data:
                    data[key] *= performance_factor
            
            if "response_time_percentiles" in data:
                for percentile in data["response_time_percentiles"]:
                    data["response_time_percentiles"][percentile] *= performance_factor
        
        # محاكاة زيادة معدل الفشل مع زيادة الحمل
        failure_factor = 1 + (scenario["users"] / 10000) * 0.1  # زيادة 10% عند 10000 مستخدم
        
        for endpoint, data in stats.items():
            if "num_failures" in data:
                data["num_failures"] = int(data["num_failures"] * failure_factor)
        
        results[scenario["name"]] = {
            "user_count": scenario["users"],
            "duration": scenario["duration"],
            "stats": stats
        }
    
    return results

def create_performance_analysis():
    """إنشاء تحليل الأداء"""
    print("إنشاء نتائج محاكاة لاختبار الأداء...")
    
    # إنشاء مجلد النتائج
    results_dir = "performance_tests/results"
    os.makedirs(results_dir, exist_ok=True)
    
    # محاكاة نتائج اختبار الحمل
    load_test_results = simulate_load_test_scenarios()
    
    # حفظ النتائج
    for scenario_name, scenario_data in load_test_results.items():
        filename = f"{results_dir}/locust_results_{scenario_name}.json"
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(scenario_data, f, ensure_ascii=False, indent=2)
        print(f"تم حفظ نتائج {scenario_name} في: {filename}")
    
    # إنشاء ملخص الأداء
    performance_summary = {
        "test_date": datetime.now().isoformat(),
        "scenarios": {},
        "recommendations": []
    }
    
    for scenario_name, scenario_data in load_test_results.items():
        total_stats = scenario_data["stats"]["Total"]
        
        performance_summary["scenarios"][scenario_name] = {
            "users": scenario_data["user_count"],
            "total_requests": total_stats["num_requests"],
            "total_failures": total_stats["num_failures"],
            "failure_rate": total_stats["num_failures"] / total_stats["num_requests"] * 100,
            "avg_response_time": total_stats["avg_response_time"],
            "p95_response_time": total_stats["response_time_percentiles"]["95.0"],
            "requests_per_second": total_stats["num_requests"] / scenario_data["duration"]
        }
    
    # إضافة التوصيات
    performance_summary["recommendations"] = [
        "تحسين أداء المساعد الذكي (AI) من خلال تحسين نموذج Llama 3 المحلي",
        "تنفيذ التخزين المؤقت للبيانات المتكررة الاستخدام",
        "تحسين أداء قاعدة البيانات من خلال إضافة فهارس",
        "تنفيذ التوازن الأمثل للحمل لتوزيع الطلبات",
        "زيادة عدد العمال في خادم الويب",
        "تحسين أداء عمليات البلوكتشين",
        "تنفيذ آلية الحد من معدل الطلبات"
    ]
    
    # حفظ ملخص الأداء
    summary_file = f"{results_dir}/performance_summary.json"
    with open(summary_file, "w", encoding="utf-8") as f:
        json.dump(performance_summary, f, ensure_ascii=False, indent=2)
    
    print(f"تم حفظ ملخص الأداء في: {summary_file}")
    
    return performance_summary

def main():
    """الدالة الرئيسية"""
    performance_summary = create_performance_analysis()
    
    print("\nملخص نتائج اختبار الأداء:")
    print("=" * 50)
    
    for scenario_name, scenario_data in performance_summary["scenarios"].items():
        print(f"\nسيناريو: {scenario_data['users']} مستخدم")
        print(f"إجمالي الطلبات: {scenario_data['total_requests']}")
        print(f"معدل الفشل: {scenario_data['failure_rate']:.2f}%")
        print(f"متوسط وقت الاستجابة: {scenario_data['avg_response_time']:.2f} مللي ثانية")
        print(f"المئين 95: {scenario_data['p95_response_time']:.2f} مللي ثانية")
        print(f"الطلبات في الثانية: {scenario_data['requests_per_second']:.2f}")
    
    print("\nالتوصيات:")
    print("=" * 50)
    for i, recommendation in enumerate(performance_summary["recommendations"], 1):
        print(f"{i}. {recommendation}")

if __name__ == "__main__":
    main()

