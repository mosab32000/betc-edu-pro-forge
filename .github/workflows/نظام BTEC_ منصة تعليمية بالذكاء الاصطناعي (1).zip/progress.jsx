import React from 'react';

const Progress = React.forwardRef(({ 
  className = '', 
  value = 0, 
  max = 100,
  indicatorClassName = '',
  ...props 
}, ref) => {
  return (
    <div
      className={`relative h-4 w-full overflow-hidden rounded-full bg-muted ${className}`}
      ref={ref}
      {...props}
    >
      <div
        className={`h-full w-full flex-1 bg-primary transition-all ${indicatorClassName}`}
        style={{ transform: `translateX(-${100 - (value / max) * 100}%)` }}
      />
    </div>
  );
});

Progress.displayName = 'Progress';

export { Progress };

