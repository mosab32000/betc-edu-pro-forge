"""
مسارات API للتقييمات والتغذية الراجعة في منصة EduverseAI - قلعة BTEC
"""
from flask import Blueprint, request, jsonify
from bson import ObjectId, errors as bson_errors
from datetime import datetime
from src.models import db, Assessment, llama_model, blockchain_manager
from src.routes.users import token_required

# إنشاء Blueprint للتقييمات
assessments_bp = Blueprint('assessments', __name__)

@assessments_bp.route('/assessments', methods=['POST'])
@token_required
def submit_assessment():
    """
    تقديم إجابة لمهمة
    """
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    if not data or not data.get('task_id') or not data.get('answer'):
        return jsonify({'message': 'البيانات غير مكتملة!'}), 400
    
    try:
        task_id = ObjectId(data['task_id'])
        
        # التحقق من وجود المهمة
        task = db.tasks.find_one({'_id': task_id})
        if not task:
            return jsonify({'message': 'المهمة غير موجودة!'}), 404
        
        # التحقق من عدم وجود تقييم سابق للمستخدم لهذه المهمة
        existing_assessment = db.assessments.find_one({
            'task_id': task_id,
            'user_id': request.current_user['_id']
        })
        
        if existing_assessment:
            # تحديث التقييم الموجود
            update_data = {
                'answer': data['answer'],
                'status': 'submitted',
                'submitted_at': datetime.utcnow()
            }
            
            # إضافة البيانات الإضافية
            if 'time_spent' in data:
                update_data['time_spent'] = data['time_spent']
            
            # تحديث التقييم في قاعدة البيانات
            db.assessments.update_one(
                {'_id': existing_assessment['_id']},
                {'$set': update_data}
            )
            
            # إضافة مراجعة جديدة إلى تاريخ المراجعات
            revision = {
                'timestamp': datetime.utcnow().isoformat(),
                'answer': data['answer']
            }
            db.assessments.update_one(
                {'_id': existing_assessment['_id']},
                {'$push': {'revision_history': revision}}
            )
            
            # الحصول على التقييم المحدث
            assessment_data = db.assessments.find_one({'_id': existing_assessment['_id']})
            
            # تحويل ObjectId إلى سلسلة
            assessment_data['_id'] = str(assessment_data['_id'])
            assessment_data['task_id'] = str(assessment_data['task_id'])
            assessment_data['user_id'] = str(assessment_data['user_id'])
            
            return jsonify({
                'message': 'تم تحديث الإجابة بنجاح!',
                'assessment': assessment_data
            }), 200
        else:
            # إنشاء تقييم جديد
            assessment = Assessment(
                task_id=task_id,
                user_id=request.current_user['_id'],
                answer=data['answer']
            )
            
            # إضافة البيانات الإضافية
            if 'time_spent' in data:
                assessment.time_spent = data['time_spent']
            
            # حفظ التقييم في قاعدة البيانات
            assessment_dict = assessment.to_dict()
            db.assessments.insert_one(assessment_dict)
            
            # تحويل ObjectId إلى سلسلة
            assessment_dict['_id'] = str(assessment_dict['_id'])
            assessment_dict['task_id'] = str(assessment_dict['task_id'])
            assessment_dict['user_id'] = str(assessment_dict['user_id'])
            
            return jsonify({
                'message': 'تم تقديم الإجابة بنجاح!',
                'assessment': assessment_dict
            }), 201
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف المهمة غير صالح!'}), 400

@assessments_bp.route('/assessments/<assessment_id>', methods=['GET'])
@token_required
def get_assessment(assessment_id):
    """
    الحصول على معلومات تقييم محدد
    """
    try:
        # البحث عن التقييم
        assessment_data = db.assessments.find_one({'_id': ObjectId(assessment_id)})
        if not assessment_data:
            return jsonify({'message': 'التقييم غير موجود!'}), 404
        
        # التحقق من صلاحيات المستخدم
        current_user = request.current_user
        if current_user['role'] == 'student' and str(assessment_data['user_id']) != str(current_user['_id']):
            return jsonify({'message': 'غير مصرح لك بالوصول إلى هذا التقييم!'}), 403
        
        # الحصول على معلومات المهمة
        task_data = db.tasks.find_one({'_id': assessment_data['task_id']})
        if task_data:
            task_data['_id'] = str(task_data['_id'])
            task_data['created_by'] = str(task_data['created_by']) if task_data['created_by'] else None
        
        # الحصول على معلومات المستخدم
        user_data = db.users.find_one({'_id': assessment_data['user_id']})
        if user_data:
            user_info = {
                '_id': str(user_data['_id']),
                'username': user_data['username'],
                'first_name': user_data.get('first_name', ''),
                'last_name': user_data.get('last_name', '')
            }
        else:
            user_info = None
        
        # تحويل ObjectId إلى سلسلة
        assessment_data['_id'] = str(assessment_data['_id'])
        assessment_data['task_id'] = str(assessment_data['task_id'])
        assessment_data['user_id'] = str(assessment_data['user_id'])
        
        return jsonify({
            'message': 'تم الحصول على معلومات التقييم بنجاح!',
            'assessment': assessment_data,
            'task': task_data,
            'user': user_info
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف التقييم غير صالح!'}), 400

@assessments_bp.route('/assessments/task/<task_id>/user/<user_id>', methods=['GET'])
@token_required
def get_assessment_by_task_and_user(task_id, user_id):
    """
    الحصول على تقييم لمهمة ومستخدم محددين
    """
    try:
        # التحقق من صلاحيات المستخدم
        current_user = request.current_user
        if current_user['role'] == 'student' and str(current_user['_id']) != user_id:
            return jsonify({'message': 'غير مصرح لك بالوصول إلى هذا التقييم!'}), 403
        
        # البحث عن التقييم
        assessment_data = db.assessments.find_one({
            'task_id': ObjectId(task_id),
            'user_id': ObjectId(user_id)
        })
        
        if not assessment_data:
            return jsonify({'message': 'التقييم غير موجود!'}), 404
        
        # تحويل ObjectId إلى سلسلة
        assessment_data['_id'] = str(assessment_data['_id'])
        assessment_data['task_id'] = str(assessment_data['task_id'])
        assessment_data['user_id'] = str(assessment_data['user_id'])
        
        return jsonify({
            'message': 'تم الحصول على معلومات التقييم بنجاح!',
            'assessment': assessment_data
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف المهمة أو المستخدم غير صالح!'}), 400

@assessments_bp.route('/assessments/task/<task_id>', methods=['GET'])
@token_required
def get_assessments_by_task(task_id):
    """
    الحصول على جميع التقييمات لمهمة محددة
    """
    try:
        # التحقق من وجود المهمة
        task = db.tasks.find_one({'_id': ObjectId(task_id)})
        if not task:
            return jsonify({'message': 'المهمة غير موجودة!'}), 404
        
        # التحقق من صلاحيات المستخدم
        current_user = request.current_user
        if current_user['role'] == 'student':
            # الطلاب يمكنهم رؤية تقييماتهم فقط
            assessments_cursor = db.assessments.find({
                'task_id': ObjectId(task_id),
                'user_id': current_user['_id']
            })
        elif current_user['role'] == 'teacher':
            # المعلمون يمكنهم رؤية تقييمات المهام التي أنشأوها فقط
            if str(task['created_by']) != str(current_user['_id']):
                return jsonify({'message': 'غير مصرح لك بالوصول إلى تقييمات هذه المهمة!'}), 403
            assessments_cursor = db.assessments.find({'task_id': ObjectId(task_id)})
        else:
            # المشرفون يمكنهم رؤية جميع التقييمات
            assessments_cursor = db.assessments.find({'task_id': ObjectId(task_id)})
        
        # تحويل النتائج إلى قائمة
        assessments = []
        for assessment in assessments_cursor:
            # تحويل ObjectId إلى سلسلة
            assessment['_id'] = str(assessment['_id'])
            assessment['task_id'] = str(assessment['task_id'])
            assessment['user_id'] = str(assessment['user_id'])
            
            # الحصول على معلومات المستخدم
            user_data = db.users.find_one({'_id': ObjectId(assessment['user_id'])})
            if user_data:
                assessment['user_info'] = {
                    'username': user_data['username'],
                    'first_name': user_data.get('first_name', ''),
                    'last_name': user_data.get('last_name', '')
                }
            
            assessments.append(assessment)
        
        return jsonify({
            'message': 'تم الحصول على تقييمات المهمة بنجاح!',
            'task_id': task_id,
            'assessments': assessments
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف المهمة غير صالح!'}), 400

@assessments_bp.route('/assessments/user/<user_id>', methods=['GET'])
@token_required
def get_assessments_by_user(user_id):
    """
    الحصول على جميع التقييمات لمستخدم محدد
    """
    try:
        # التحقق من صلاحيات المستخدم
        current_user = request.current_user
        if current_user['role'] == 'student' and str(current_user['_id']) != user_id:
            return jsonify({'message': 'غير مصرح لك بالوصول إلى تقييمات هذا المستخدم!'}), 403
        
        # البحث عن التقييمات
        assessments_cursor = db.assessments.find({'user_id': ObjectId(user_id)})
        
        # تحويل النتائج إلى قائمة
        assessments = []
        for assessment in assessments_cursor:
            # تحويل ObjectId إلى سلسلة
            assessment['_id'] = str(assessment['_id'])
            assessment['task_id'] = str(assessment['task_id'])
            assessment['user_id'] = str(assessment['user_id'])
            
            # الحصول على معلومات المهمة
            task_data = db.tasks.find_one({'_id': ObjectId(assessment['task_id'])})
            if task_data:
                assessment['task_info'] = {
                    'title': task_data['title'],
                    'subject': task_data['subject'],
                    'due_date': task_data.get('due_date')
                }
            
            assessments.append(assessment)
        
        return jsonify({
            'message': 'تم الحصول على تقييمات المستخدم بنجاح!',
            'user_id': user_id,
            'assessments': assessments
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف المستخدم غير صالح!'}), 400

@assessments_bp.route('/assessments/<assessment_id>/evaluate', methods=['POST'])
@token_required
def evaluate_assessment(assessment_id):
    """
    تقييم إجابة الطالب
    """
    # التحقق من صلاحيات المستخدم
    if request.current_user['role'] not in ['admin', 'teacher']:
        return jsonify({'message': 'غير مصرح لك بتقييم الإجابات!'}), 403
    
    try:
        # البحث عن التقييم
        assessment_data = db.assessments.find_one({'_id': ObjectId(assessment_id)})
        if not assessment_data:
            return jsonify({'message': 'التقييم غير موجود!'}), 404
        
        # التحقق من صلاحيات المعلم
        if request.current_user['role'] == 'teacher':
            # الحصول على معلومات المهمة
            task_data = db.tasks.find_one({'_id': assessment_data['task_id']})
            if not task_data or str(task_data['created_by']) != str(request.current_user['_id']):
                return jsonify({'message': 'غير مصرح لك بتقييم هذه الإجابة!'}), 403
        
        data = request.get_json()
        if not data:
            return jsonify({'message': 'لا توجد بيانات للتقييم!'}), 400
        
        # تحديث بيانات التقييم
        update_data = {
            'status': 'completed',
            'evaluated_at': datetime.utcnow()
        }
        
        # إضافة البيانات المقدمة
        if 'score' in data:
            update_data['score'] = data['score']
        if 'feedback' in data:
            update_data['feedback'] = data['feedback']
        if 'criteria_scores' in data:
            update_data['criteria_scores'] = data['criteria_scores']
        
        # إضافة التغذية الراجعة من الذكاء الاصطناعي إذا تم طلبها
        if data.get('use_ai_feedback', False):
            # الحصول على معلومات المهمة
            task_data = db.tasks.find_one({'_id': assessment_data['task_id']})
            
            if task_data:
                # توليد التغذية الراجعة من الذكاء الاصطناعي
                ai_feedback = llama_model.assess_answer(
                    answer=assessment_data['answer'],
                    task_description=task_data['description'],
                    criteria=task_data.get('criteria', [])
                )
                
                update_data['ai_feedback'] = ai_feedback
                
                # استخدام درجة الذكاء الاصطناعي إذا لم يتم تقديم درجة
                if 'score' not in update_data and 'overall_score' in ai_feedback:
                    update_data['score'] = ai_feedback['overall_score']
                
                # استخدام درجات المعايير من الذكاء الاصطناعي إذا لم يتم تقديمها
                if 'criteria_scores' not in update_data and 'criteria_scores' in ai_feedback:
                    update_data['criteria_scores'] = ai_feedback['criteria_scores']
        
        # تسجيل التقييم في البلوكتشين إذا تم طلبه
        if data.get('use_blockchain', False):
            blockchain_result = blockchain_manager.record_assessment({
                '_id': str(assessment_data['_id']),
                'task_id': str(assessment_data['task_id']),
                'user_id': str(assessment_data['user_id']),
                'score': update_data.get('score'),
                'answer': assessment_data['answer'],
                'submitted_at': assessment_data['submitted_at'],
                'evaluated_at': update_data['evaluated_at']
            })
            
            if blockchain_result['success']:
                update_data['blockchain_verification'] = blockchain_result['verification']
        
        # تحديث التقييم في قاعدة البيانات
        db.assessments.update_one(
            {'_id': ObjectId(assessment_id)},
            {'$set': update_data}
        )
        
        # الحصول على التقييم المحدث
        updated_assessment = db.assessments.find_one({'_id': ObjectId(assessment_id)})
        
        # تحويل ObjectId إلى سلسلة
        updated_assessment['_id'] = str(updated_assessment['_id'])
        updated_assessment['task_id'] = str(updated_assessment['task_id'])
        updated_assessment['user_id'] = str(updated_assessment['user_id'])
        
        return jsonify({
            'message': 'تم تقييم الإجابة بنجاح!',
            'assessment': updated_assessment
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف التقييم غير صالح!'}), 400

@assessments_bp.route('/assessments/<assessment_id>/ai-feedback', methods=['GET'])
@token_required
def get_ai_feedback(assessment_id):
    """
    الحصول على التغذية الراجعة من الذكاء الاصطناعي
    """
    try:
        # البحث عن التقييم
        assessment_data = db.assessments.find_one({'_id': ObjectId(assessment_id)})
        if not assessment_data:
            return jsonify({'message': 'التقييم غير موجود!'}), 404
        
        # التحقق من صلاحيات المستخدم
        current_user = request.current_user
        if current_user['role'] == 'student' and str(assessment_data['user_id']) != str(current_user['_id']):
            return jsonify({'message': 'غير مصرح لك بالوصول إلى هذا التقييم!'}), 403
        
        # الحصول على معلومات المهمة
        task_data = db.tasks.find_one({'_id': assessment_data['task_id']})
        if not task_data:
            return jsonify({'message': 'المهمة غير موجودة!'}), 404
        
        # توليد التغذية الراجعة من الذكاء الاصطناعي
        ai_feedback = llama_model.assess_answer(
            answer=assessment_data['answer'],
            task_description=task_data['description'],
            criteria=task_data.get('criteria', [])
        )
        
        # تحديث التقييم في قاعدة البيانات
        db.assessments.update_one(
            {'_id': ObjectId(assessment_id)},
            {'$set': {'ai_feedback': ai_feedback}}
        )
        
        return jsonify({
            'message': 'تم الحصول على التغذية الراجعة من الذكاء الاصطناعي بنجاح!',
            'assessment_id': assessment_id,
            'ai_feedback': ai_feedback
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف التقييم غير صالح!'}), 400

@assessments_bp.route('/assessments/<assessment_id>/verify', methods=['GET'])
@token_required
def verify_assessment(assessment_id):
    """
    التحقق من صحة التقييم باستخدام البلوكتشين
    """
    try:
        # البحث عن التقييم
        assessment_data = db.assessments.find_one({'_id': ObjectId(assessment_id)})
        if not assessment_data:
            return jsonify({'message': 'التقييم غير موجود!'}), 404
        
        # التحقق من وجود معلومات التحقق من البلوكتشين
        if 'blockchain_verification' not in assessment_data or not assessment_data['blockchain_verification']:
            return jsonify({
                'message': 'لا توجد معلومات تحقق من البلوكتشين لهذا التقييم!',
                'verified': False
            }), 200
        
        # التحقق من صحة التقييم باستخدام البلوكتشين
        block_hash = assessment_data['blockchain_verification'].get('block_hash')
        if not block_hash:
            return jsonify({
                'message': 'معلومات التحقق من البلوكتشين غير مكتملة!',
                'verified': False
            }), 200
        
        verification_result = blockchain_manager.verify_data(
            {
                'assessment_id': str(assessment_data['_id']),
                'task_id': str(assessment_data['task_id']),
                'user_id': str(assessment_data['user_id']),
                'score': assessment_data.get('score')
            },
            block_hash
        )
        
        return jsonify({
            'message': verification_result['message'],
            'verified': verification_result['verified'],
            'block': verification_result['block'],
            'assessment_id': assessment_id
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف التقييم غير صالح!'}), 400

