#!/usr/bin/env python3
"""
سكربت لاختبار قدرة التحمل للمنصة

يقوم هذا السكربت بمحاكاة حمل كبير على المنصة لاختبار قدرتها على التعامل مع
عدد كبير من المستخدمين المتزامنين.

كيفية الاستخدام:
1. قم بتشغيل السكربت: python stress_test.py
"""

import requests
import threading
import time
import random
import json
import argparse
import os
import sys
import logging
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

# إعداد السجلات
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("stress_test.log"),
        logging.StreamHandler()
    ]
)

# المتغيرات العامة
BASE_URL = "http://localhost:5000"
USERS = []
TASKS = []
XR_EXPERIENCES = []
TOKENS = {}
RESULTS = {
    "requests": 0,
    "successful_requests": 0,
    "failed_requests": 0,
    "response_times": [],
    "start_time": None,
    "end_time": None
}

def load_test_data():
    """تحميل بيانات الاختبار"""
    global USERS, TASKS, XR_EXPERIENCES
    
    data_dir = "performance_tests/test_data"
    
    try:
        # تحميل بيانات المستخدمين
        with open(f"{data_dir}/users.json", "r", encoding="utf-8") as f:
            USERS = json.load(f)
        
        # تحميل بيانات المهام
        with open(f"{data_dir}/tasks.json", "r", encoding="utf-8") as f:
            TASKS = json.load(f)
        
        # تحميل بيانات تجارب التعلم الغامرة
        with open(f"{data_dir}/xr_experiences.json", "r", encoding="utf-8") as f:
            XR_EXPERIENCES = json.load(f)
        
        logging.info(f"تم تحميل بيانات الاختبار: {len(USERS)} مستخدم، {len(TASKS)} مهمة، {len(XR_EXPERIENCES)} تجربة تعلم غامرة")
    except Exception as e:
        logging.error(f"فشل تحميل بيانات الاختبار: {e}")
        sys.exit(1)

def login_user(user):
    """تسجيل دخول المستخدم"""
    try:
        start_time = time.time()
        
        response = requests.post(
            f"{BASE_URL}/api/users/login",
            json={
                "username": user["username"],
                "password": "password123"
            },
            timeout=10
        )
        
        response_time = time.time() - start_time
        
        if response.status_code == 200:
            token = response.json().get("token")
            TOKENS[user["username"]] = token
            
            RESULTS["requests"] += 1
            RESULTS["successful_requests"] += 1
            RESULTS["response_times"].append(response_time)
            
            return True
        else:
            RESULTS["requests"] += 1
            RESULTS["failed_requests"] += 1
            RESULTS["response_times"].append(response_time)
            
            logging.warning(f"فشل تسجيل دخول المستخدم {user['username']}: {response.status_code} - {response.text}")
            return False
    except Exception as e:
        RESULTS["requests"] += 1
        RESULTS["failed_requests"] += 1
        
        logging.error(f"حدث خطأ أثناء تسجيل دخول المستخدم {user['username']}: {e}")
        return False

def view_profile(user):
    """عرض الملف الشخصي للمستخدم"""
    if user["username"] not in TOKENS:
        return False
    
    try:
        start_time = time.time()
        
        response = requests.get(
            f"{BASE_URL}/api/users/profile",
            headers={"Authorization": f"Bearer {TOKENS[user['username']]}"},
            timeout=10
        )
        
        response_time = time.time() - start_time
        
        if response.status_code == 200:
            RESULTS["requests"] += 1
            RESULTS["successful_requests"] += 1
            RESULTS["response_times"].append(response_time)
            
            return True
        else:
            RESULTS["requests"] += 1
            RESULTS["failed_requests"] += 1
            RESULTS["response_times"].append(response_time)
            
            logging.warning(f"فشل عرض الملف الشخصي للمستخدم {user['username']}: {response.status_code} - {response.text}")
            return False
    except Exception as e:
        RESULTS["requests"] += 1
        RESULTS["failed_requests"] += 1
        
        logging.error(f"حدث خطأ أثناء عرض الملف الشخصي للمستخدم {user['username']}: {e}")
        return False

def view_tasks(user):
    """عرض المهام التعليمية"""
    if user["username"] not in TOKENS:
        return False
    
    try:
        start_time = time.time()
        
        response = requests.get(
            f"{BASE_URL}/api/tasks",
            headers={"Authorization": f"Bearer {TOKENS[user['username']]}"},
            timeout=10
        )
        
        response_time = time.time() - start_time
        
        if response.status_code == 200:
            RESULTS["requests"] += 1
            RESULTS["successful_requests"] += 1
            RESULTS["response_times"].append(response_time)
            
            return True
        else:
            RESULTS["requests"] += 1
            RESULTS["failed_requests"] += 1
            RESULTS["response_times"].append(response_time)
            
            logging.warning(f"فشل عرض المهام للمستخدم {user['username']}: {response.status_code} - {response.text}")
            return False
    except Exception as e:
        RESULTS["requests"] += 1
        RESULTS["failed_requests"] += 1
        
        logging.error(f"حدث خطأ أثناء عرض المهام للمستخدم {user['username']}: {e}")
        return False

def view_task_details(user, task):
    """عرض تفاصيل مهمة تعليمية"""
    if user["username"] not in TOKENS:
        return False
    
    try:
        start_time = time.time()
        
        response = requests.get(
            f"{BASE_URL}/api/tasks/{task['id']}",
            headers={"Authorization": f"Bearer {TOKENS[user['username']]}"},
            timeout=10
        )
        
        response_time = time.time() - start_time
        
        if response.status_code == 200:
            RESULTS["requests"] += 1
            RESULTS["successful_requests"] += 1
            RESULTS["response_times"].append(response_time)
            
            return True
        else:
            RESULTS["requests"] += 1
            RESULTS["failed_requests"] += 1
            RESULTS["response_times"].append(response_time)
            
            logging.warning(f"فشل عرض تفاصيل المهمة {task['id']} للمستخدم {user['username']}: {response.status_code} - {response.text}")
            return False
    except Exception as e:
        RESULTS["requests"] += 1
        RESULTS["failed_requests"] += 1
        
        logging.error(f"حدث خطأ أثناء عرض تفاصيل المهمة {task['id']} للمستخدم {user['username']}: {e}")
        return False

def submit_assessment(user, task):
    """تقديم تقييم لمهمة تعليمية"""
    if user["username"] not in TOKENS:
        return False
    
    try:
        start_time = time.time()
        
        response = requests.post(
            f"{BASE_URL}/api/assessments",
            headers={"Authorization": f"Bearer {TOKENS[user['username']]}"},
            json={
                "task_id": task["id"],
                "content": f"هذه هي إجابتي على المهمة {task['title']}. أتمنى أن تكون صحيحة.",
                "attachments": []
            },
            timeout=10
        )
        
        response_time = time.time() - start_time
        
        if response.status_code == 200 or response.status_code == 201:
            RESULTS["requests"] += 1
            RESULTS["successful_requests"] += 1
            RESULTS["response_times"].append(response_time)
            
            return True
        else:
            RESULTS["requests"] += 1
            RESULTS["failed_requests"] += 1
            RESULTS["response_times"].append(response_time)
            
            logging.warning(f"فشل تقديم تقييم للمهمة {task['id']} للمستخدم {user['username']}: {response.status_code} - {response.text}")
            return False
    except Exception as e:
        RESULTS["requests"] += 1
        RESULTS["failed_requests"] += 1
        
        logging.error(f"حدث خطأ أثناء تقديم تقييم للمهمة {task['id']} للمستخدم {user['username']}: {e}")
        return False

def use_ai_assistant(user):
    """استخدام المساعد الذكي"""
    if user["username"] not in TOKENS:
        return False
    
    try:
        start_time = time.time()
        
        subject = random.choice(["رياضيات", "علوم", "لغة عربية", "لغة إنجليزية", "تاريخ"])
        
        response = requests.post(
            f"{BASE_URL}/api/ai/chat",
            headers={"Authorization": f"Bearer {TOKENS[user['username']]}"},
            json={
                "message": f"أريد مساعدة في مادة {subject}",
                "context": {
                    "subject": subject,
                    "previous_messages": []
                }
            },
            timeout=30  # زيادة المهلة الزمنية للمساعد الذكي
        )
        
        response_time = time.time() - start_time
        
        if response.status_code == 200:
            RESULTS["requests"] += 1
            RESULTS["successful_requests"] += 1
            RESULTS["response_times"].append(response_time)
            
            return True
        else:
            RESULTS["requests"] += 1
            RESULTS["failed_requests"] += 1
            RESULTS["response_times"].append(response_time)
            
            logging.warning(f"فشل استخدام المساعد الذكي للمستخدم {user['username']}: {response.status_code} - {response.text}")
            return False
    except Exception as e:
        RESULTS["requests"] += 1
        RESULTS["failed_requests"] += 1
        
        logging.error(f"حدث خطأ أثناء استخدام المساعد الذكي للمستخدم {user['username']}: {e}")
        return False

def use_xr_experience(user, experience):
    """استخدام تجربة تعلم غامرة"""
    if user["username"] not in TOKENS:
        return False
    
    try:
        # عرض تفاصيل التجربة
        start_time = time.time()
        
        response = requests.get(
            f"{BASE_URL}/api/xr/experience/{experience['id']}",
            headers={"Authorization": f"Bearer {TOKENS[user['username']]}"},
            timeout=10
        )
        
        response_time = time.time() - start_time
        
        if response.status_code == 200:
            RESULTS["requests"] += 1
            RESULTS["successful_requests"] += 1
            RESULTS["response_times"].append(response_time)
            
            # تحديث تقدم المستخدم
            start_time = time.time()
            
            response = requests.post(
                f"{BASE_URL}/api/xr/user-progress/{user['username']}/{experience['id']}",
                headers={"Authorization": f"Bearer {TOKENS[user['username']]}"},
                json={
                    "progress": random.randint(10, 100),
                    "completed": random.choice([True, False]),
                    "score": random.randint(0, 100),
                    "time_spent": random.randint(60, 3600)
                },
                timeout=10
            )
            
            response_time = time.time() - start_time
            
            if response.status_code == 200 or response.status_code == 201:
                RESULTS["requests"] += 1
                RESULTS["successful_requests"] += 1
                RESULTS["response_times"].append(response_time)
                
                return True
            else:
                RESULTS["requests"] += 1
                RESULTS["failed_requests"] += 1
                RESULTS["response_times"].append(response_time)
                
                logging.warning(f"فشل تحديث تقدم المستخدم {user['username']} في التجربة {experience['id']}: {response.status_code} - {response.text}")
                return False
        else:
            RESULTS["requests"] += 1
            RESULTS["failed_requests"] += 1
            RESULTS["response_times"].append(response_time)
            
            logging.warning(f"فشل عرض تفاصيل التجربة {experience['id']} للمستخدم {user['username']}: {response.status_code} - {response.text}")
            return False
    except Exception as e:
        RESULTS["requests"] += 1
        RESULTS["failed_requests"] += 1
        
        logging.error(f"حدث خطأ أثناء استخدام التجربة {experience['id']} للمستخدم {user['username']}: {e}")
        return False

def view_badges(user):
    """عرض الأوسمة"""
    if user["username"] not in TOKENS:
        return False
    
    try:
        start_time = time.time()
        
        response = requests.get(
            f"{BASE_URL}/api/badges/user/{user['username']}",
            headers={"Authorization": f"Bearer {TOKENS[user['username']]}"},
            timeout=10
        )
        
        response_time = time.time() - start_time
        
        if response.status_code == 200:
            RESULTS["requests"] += 1
            RESULTS["successful_requests"] += 1
            RESULTS["response_times"].append(response_time)
            
            return True
        else:
            RESULTS["requests"] += 1
            RESULTS["failed_requests"] += 1
            RESULTS["response_times"].append(response_time)
            
            logging.warning(f"فشل عرض الأوسمة للمستخدم {user['username']}: {response.status_code} - {response.text}")
            return False
    except Exception as e:
        RESULTS["requests"] += 1
        RESULTS["failed_requests"] += 1
        
        logging.error(f"حدث خطأ أثناء عرض الأوسمة للمستخدم {user['username']}: {e}")
        return False

def simulate_user_activity(user):
    """محاكاة نشاط المستخدم"""
    # تسجيل دخول المستخدم
    if not login_user(user):
        return
    
    # عرض الملف الشخصي
    view_profile(user)
    
    # عرض المهام
    view_tasks(user)
    
    # عرض تفاصيل مهمة عشوائية
    if TASKS:
        task = random.choice(TASKS)
        view_task_details(user, task)
        
        # تقديم تقييم للمهمة
        if random.random() < 0.3:  # 30% احتمالية تقديم تقييم
            submit_assessment(user, task)
    
    # استخدام المساعد الذكي
    if random.random() < 0.2:  # 20% احتمالية استخدام المساعد الذكي
        use_ai_assistant(user)
    
    # استخدام تجربة تعلم غامرة
    if XR_EXPERIENCES and random.random() < 0.1:  # 10% احتمالية استخدام تجربة تعلم غامرة
        experience = random.choice(XR_EXPERIENCES)
        use_xr_experience(user, experience)
    
    # عرض الأوسمة
    if random.random() < 0.1:  # 10% احتمالية عرض الأوسمة
        view_badges(user)

def run_stress_test(num_users, duration):
    """تشغيل اختبار الضغط"""
    logging.info(f"بدء اختبار الضغط مع {num_users} مستخدم لمدة {duration} ثانية")
    
    # تحميل بيانات الاختبار
    load_test_data()
    
    # تحديد وقت البدء
    RESULTS["start_time"] = time.time()
    
    # إنشاء مجموعة مستخدمين عشوائية
    test_users = random.sample(USERS, min(num_users, len(USERS)))
    
    # إنشاء مجمع مسارات
    with ThreadPoolExecutor(max_workers=num_users) as executor:
        # تشغيل محاكاة نشاط المستخدم لكل مستخدم
        futures = []
        for user in test_users:
            futures.append(executor.submit(simulate_user_activity, user))
        
        # انتظار انتهاء المدة المحددة
        start_time = time.time()
        while time.time() - start_time < duration:
            # عرض تقدم الاختبار
            elapsed = time.time() - start_time
            progress = min(elapsed / duration * 100, 100)
            
            logging.info(f"تقدم الاختبار: {progress:.2f}% - الطلبات: {RESULTS['requests']} - النجاح: {RESULTS['successful_requests']} - الفشل: {RESULTS['failed_requests']}")
            
            # انتظار ثانية واحدة
            time.sleep(1)
        
        # إلغاء جميع المهام المتبقية
        for future in futures:
            future.cancel()
    
    # تحديد وقت الانتهاء
    RESULTS["end_time"] = time.time()
    
    # عرض نتائج الاختبار
    show_results()

def show_results():
    """عرض نتائج الاختبار"""
    logging.info("نتائج اختبار الضغط:")
    
    # حساب المدة الإجمالية
    duration = RESULTS["end_time"] - RESULTS["start_time"]
    
    # حساب معدل الطلبات في الثانية
    requests_per_second = RESULTS["requests"] / duration
    
    # حساب متوسط وقت الاستجابة
    avg_response_time = sum(RESULTS["response_times"]) / len(RESULTS["response_times"]) if RESULTS["response_times"] else 0
    
    # حساب معدل النجاح
    success_rate = RESULTS["successful_requests"] / RESULTS["requests"] * 100 if RESULTS["requests"] > 0 else 0
    
    logging.info(f"المدة الإجمالية: {duration:.2f} ثانية")
    logging.info(f"إجمالي الطلبات: {RESULTS['requests']}")
    logging.info(f"الطلبات الناجحة: {RESULTS['successful_requests']}")
    logging.info(f"الطلبات الفاشلة: {RESULTS['failed_requests']}")
    logging.info(f"معدل النجاح: {success_rate:.2f}%")
    logging.info(f"معدل الطلبات في الثانية: {requests_per_second:.2f}")
    logging.info(f"متوسط وقت الاستجابة: {avg_response_time:.2f} ثانية")
    
    # حفظ النتائج في ملف JSON
    results_dir = "performance_tests/results"
    os.makedirs(results_dir, exist_ok=True)
    
    results_file = f"{results_dir}/stress_test_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    
    with open(results_file, "w", encoding="utf-8") as f:
        json.dump({
            "duration": duration,
            "total_requests": RESULTS["requests"],
            "successful_requests": RESULTS["successful_requests"],
            "failed_requests": RESULTS["failed_requests"],
            "success_rate": success_rate,
            "requests_per_second": requests_per_second,
            "avg_response_time": avg_response_time,
            "response_times": RESULTS["response_times"]
        }, f, ensure_ascii=False, indent=2)
    
    logging.info(f"تم حفظ النتائج في: {results_file}")

def main():
    """الدالة الرئيسية"""
    parser = argparse.ArgumentParser(description="اختبار قدرة التحمل للمنصة")
    parser.add_argument("--users", type=int, default=100, help="عدد المستخدمين المتزامنين")
    parser.add_argument("--duration", type=int, default=60, help="مدة الاختبار بالثواني")
    parser.add_argument("--url", type=str, default="http://localhost:5000", help="عنوان URL الأساسي للمنصة")
    
    args = parser.parse_args()
    
    global BASE_URL
    BASE_URL = args.url
    
    run_stress_test(args.users, args.duration)

if __name__ == "__main__":
    main()

