"""
مسارات API لتجارب التعلم الغامرة (XR) في منصة EduverseAI - قلعة BTEC
"""
from flask import Blueprint, request, jsonify
from bson import ObjectId, errors as bson_errors
from datetime import datetime
from src.models import db, XRExperience, UserXRExperience
from src.routes.users import token_required

# إنشاء Blueprint لتجارب التعلم الغامرة
xr_experiences_bp = Blueprint('xr_experiences', __name__)

@xr_experiences_bp.route('/xr-experiences', methods=['POST'])
@token_required
def create_xr_experience():
    """
    إنشاء تجربة تعلم غامرة جديدة
    """
    # التحقق من صلاحيات المستخدم
    if request.current_user['role'] not in ['admin', 'teacher']:
        return jsonify({'message': 'غير مصرح لك بإنشاء تجارب تعلم غامرة!'}), 403
    
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    if not data or not data.get('title') or not data.get('description') or not data.get('type_xr') or not data.get('subject') or not data.get('thumbnail_url'):
        return jsonify({'message': 'البيانات غير مكتملة!'}), 400
    
    # إنشاء كائن تجربة التعلم الغامرة
    xr_experience = XRExperience(
        title=data['title'],
        description=data['description'],
        type_xr=data['type_xr'],
        subject=data['subject'],
        thumbnail_url=data['thumbnail_url'],
        content_url=data.get('content_url'),
        requirements=data.get('requirements', {}),
        created_by=request.current_user['_id']
    )
    
    # إضافة البيانات الإضافية
    if 'difficulty' in data:
        xr_experience.difficulty = data['difficulty']
    if 'duration' in data:
        xr_experience.duration = data['duration']
    if 'tags' in data:
        xr_experience.tags = data['tags']
    if 'jordanian_theme' in data:
        xr_experience.jordanian_theme = data['jordanian_theme']
    if 'interactions' in data:
        xr_experience.interactions = data['interactions']
    if 'learning_objectives' in data:
        xr_experience.learning_objectives = data['learning_objectives']
    
    # حفظ تجربة التعلم الغامرة في قاعدة البيانات
    db.xr_experiences.insert_one(xr_experience.to_dict())
    
    return jsonify({
        'message': 'تم إنشاء تجربة التعلم الغامرة بنجاح!',
        'xr_experience': xr_experience.to_dict()
    }), 201

@xr_experiences_bp.route('/xr-experiences', methods=['GET'])
@token_required
def get_xr_experiences():
    """
    الحصول على قائمة تجارب التعلم الغامرة
    """
    # الحصول على معلمات البحث والترتيب والتصفح
    search = request.args.get('search', '')
    subject = request.args.get('subject', '')
    type_xr = request.args.get('type_xr', '')
    difficulty = request.args.get('difficulty', '')
    tags = request.args.get('tags', '')
    sort_by = request.args.get('sort_by', 'title')
    sort_order = int(request.args.get('sort_order', '1'))
    page = int(request.args.get('page', '1'))
    limit = int(request.args.get('limit', '10'))
    
    # بناء استعلام البحث
    query = {}
    if search:
        query['$or'] = [
            {'title': {'$regex': search, '$options': 'i'}},
            {'description': {'$regex': search, '$options': 'i'}},
            {'jordanian_theme': {'$regex': search, '$options': 'i'}}
        ]
    if subject:
        query['subject'] = subject
    if type_xr:
        query['type_xr'] = type_xr
    if difficulty:
        query['difficulty'] = difficulty
    if tags:
        query['tags'] = {'$in': tags.split(',')}
    
    # للمعلمين، عرض التجارب التي أنشأوها فقط
    if request.current_user['role'] == 'teacher':
        query['created_by'] = request.current_user['_id']
    
    # حساب عدد التجارب
    total = db.xr_experiences.count_documents(query)
    
    # الحصول على التجارب مع التصفح والترتيب
    xr_experiences_cursor = db.xr_experiences.find(query).sort(sort_by, sort_order).skip((page - 1) * limit).limit(limit)
    
    # تحويل النتائج إلى قائمة
    xr_experiences = []
    for xr_experience_data in xr_experiences_cursor:
        # تحويل ObjectId إلى سلسلة
        xr_experience_data['_id'] = str(xr_experience_data['_id'])
        xr_experience_data['created_by'] = str(xr_experience_data['created_by']) if xr_experience_data['created_by'] else None
        
        xr_experiences.append(xr_experience_data)
    
    return jsonify({
        'message': 'تم الحصول على قائمة تجارب التعلم الغامرة بنجاح!',
        'total': total,
        'page': page,
        'limit': limit,
        'pages': (total + limit - 1) // limit,
        'xr_experiences': xr_experiences
    }), 200

@xr_experiences_bp.route('/xr-experiences/<xr_experience_id>', methods=['GET'])
@token_required
def get_xr_experience(xr_experience_id):
    """
    الحصول على معلومات تجربة تعلم غامرة محددة
    """
    try:
        # البحث عن التجربة
        xr_experience_data = db.xr_experiences.find_one({'_id': ObjectId(xr_experience_id)})
        if not xr_experience_data:
            return jsonify({'message': 'تجربة التعلم الغامرة غير موجودة!'}), 404
        
        # تحويل ObjectId إلى سلسلة
        xr_experience_data['_id'] = str(xr_experience_data['_id'])
        xr_experience_data['created_by'] = str(xr_experience_data['created_by']) if xr_experience_data['created_by'] else None
        
        # الحصول على معلومات المنشئ
        if xr_experience_data['created_by']:
            creator = db.users.find_one({'_id': ObjectId(xr_experience_data['created_by'])})
            if creator:
                xr_experience_data['creator_info'] = {
                    'username': creator['username'],
                    'first_name': creator.get('first_name', ''),
                    'last_name': creator.get('last_name', '')
                }
        
        # الحصول على معلومات تقدم المستخدم الحالي في التجربة
        user_xr_experience = db.user_xr_experiences.find_one({
            'user_id': request.current_user['_id'],
            'experience_id': ObjectId(xr_experience_id)
        })
        
        if user_xr_experience:
            user_xr_experience['_id'] = str(user_xr_experience['_id'])
            user_xr_experience['user_id'] = str(user_xr_experience['user_id'])
            user_xr_experience['experience_id'] = str(user_xr_experience['experience_id'])
            xr_experience_data['user_progress'] = user_xr_experience
        
        return jsonify({
            'message': 'تم الحصول على معلومات تجربة التعلم الغامرة بنجاح!',
            'xr_experience': xr_experience_data
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف تجربة التعلم الغامرة غير صالح!'}), 400

@xr_experiences_bp.route('/xr-experiences/<xr_experience_id>', methods=['PUT'])
@token_required
def update_xr_experience(xr_experience_id):
    """
    تحديث تجربة تعلم غامرة محددة
    """
    try:
        # البحث عن التجربة
        xr_experience_data = db.xr_experiences.find_one({'_id': ObjectId(xr_experience_id)})
        if not xr_experience_data:
            return jsonify({'message': 'تجربة التعلم الغامرة غير موجودة!'}), 404
        
        # التحقق من صلاحيات المستخدم
        if request.current_user['role'] == 'student':
            return jsonify({'message': 'غير مصرح لك بتحديث تجارب التعلم الغامرة!'}), 403
        elif request.current_user['role'] == 'teacher' and str(xr_experience_data['created_by']) != str(request.current_user['_id']):
            return jsonify({'message': 'غير مصرح لك بتحديث هذه التجربة!'}), 403
        
        data = request.get_json()
        if not data:
            return jsonify({'message': 'لا توجد بيانات للتحديث!'}), 400
        
        # تحديد البيانات القابلة للتحديث
        update_data = {}
        allowed_fields = [
            'title', 'description', 'type_xr', 'subject', 'thumbnail_url',
            'content_url', 'requirements', 'difficulty', 'duration',
            'tags', 'jordanian_theme', 'interactions', 'learning_objectives'
        ]
        
        for field in allowed_fields:
            if field in data:
                update_data[field] = data[field]
        
        # تحديث تاريخ التحديث
        update_data['updated_at'] = datetime.utcnow()
        
        # تحديث التجربة في قاعدة البيانات
        if update_data:
            db.xr_experiences.update_one({'_id': ObjectId(xr_experience_id)}, {'$set': update_data})
        
        # الحصول على بيانات التجربة المحدثة
        updated_xr_experience = db.xr_experiences.find_one({'_id': ObjectId(xr_experience_id)})
        
        # تحويل ObjectId إلى سلسلة
        updated_xr_experience['_id'] = str(updated_xr_experience['_id'])
        updated_xr_experience['created_by'] = str(updated_xr_experience['created_by']) if updated_xr_experience['created_by'] else None
        
        return jsonify({
            'message': 'تم تحديث تجربة التعلم الغامرة بنجاح!',
            'xr_experience': updated_xr_experience
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف تجربة التعلم الغامرة غير صالح!'}), 400

@xr_experiences_bp.route('/xr-experiences/<xr_experience_id>', methods=['DELETE'])
@token_required
def delete_xr_experience(xr_experience_id):
    """
    حذف تجربة تعلم غامرة محددة
    """
    try:
        # البحث عن التجربة
        xr_experience_data = db.xr_experiences.find_one({'_id': ObjectId(xr_experience_id)})
        if not xr_experience_data:
            return jsonify({'message': 'تجربة التعلم الغامرة غير موجودة!'}), 404
        
        # التحقق من صلاحيات المستخدم
        if request.current_user['role'] == 'student':
            return jsonify({'message': 'غير مصرح لك بحذف تجارب التعلم الغامرة!'}), 403
        elif request.current_user['role'] == 'teacher' and str(xr_experience_data['created_by']) != str(request.current_user['_id']):
            return jsonify({'message': 'غير مصرح لك بحذف هذه التجربة!'}), 403
        
        # حذف علاقات المستخدمين بالتجربة
        db.user_xr_experiences.delete_many({'experience_id': ObjectId(xr_experience_id)})
        
        # حذف التجربة من المهام المرتبطة بها
        db.tasks.update_many(
            {'xr_experiences': xr_experience_id},
            {'$pull': {'xr_experiences': xr_experience_id}}
        )
        
        # حذف التجربة
        db.xr_experiences.delete_one({'_id': ObjectId(xr_experience_id)})
        
        return jsonify({
            'message': 'تم حذف تجربة التعلم الغامرة بنجاح!'
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف تجربة التعلم الغامرة غير صالح!'}), 400

@xr_experiences_bp.route('/xr-experiences/types', methods=['GET'])
@token_required
def get_xr_types():
    """
    الحصول على قائمة أنواع تجارب التعلم الغامرة
    """
    # الحصول على قائمة الأنواع الفريدة
    types = db.xr_experiences.distinct('type_xr')
    
    return jsonify({
        'message': 'تم الحصول على قائمة أنواع تجارب التعلم الغامرة بنجاح!',
        'types': types
    }), 200

@xr_experiences_bp.route('/xr-experiences/subjects', methods=['GET'])
@token_required
def get_xr_subjects():
    """
    الحصول على قائمة المواد الدراسية لتجارب التعلم الغامرة
    """
    # الحصول على قائمة المواد الدراسية الفريدة
    subjects = db.xr_experiences.distinct('subject')
    
    return jsonify({
        'message': 'تم الحصول على قائمة المواد الدراسية لتجارب التعلم الغامرة بنجاح!',
        'subjects': subjects
    }), 200

@xr_experiences_bp.route('/user-xr-experiences', methods=['POST'])
@token_required
def start_xr_experience():
    """
    بدء تجربة تعلم غامرة
    """
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    if not data or not data.get('experience_id'):
        return jsonify({'message': 'البيانات غير مكتملة!'}), 400
    
    try:
        experience_id = ObjectId(data['experience_id'])
        
        # التحقق من وجود التجربة
        xr_experience = db.xr_experiences.find_one({'_id': experience_id})
        if not xr_experience:
            return jsonify({'message': 'تجربة التعلم الغامرة غير موجودة!'}), 404
        
        # التحقق من عدم وجود علاقة سابقة
        existing_user_xr_experience = db.user_xr_experiences.find_one({
            'user_id': request.current_user['_id'],
            'experience_id': experience_id
        })
        
        if existing_user_xr_experience:
            # تحديث العلاقة الموجودة
            update_data = {
                'status': 'in_progress',
                'started_at': datetime.utcnow()
            }
            
            # تحديث العلاقة في قاعدة البيانات
            db.user_xr_experiences.update_one(
                {'_id': existing_user_xr_experience['_id']},
                {'$set': update_data}
            )
            
            # الحصول على العلاقة المحدثة
            user_xr_experience_data = db.user_xr_experiences.find_one({'_id': existing_user_xr_experience['_id']})
            
            # تحويل ObjectId إلى سلسلة
            user_xr_experience_data['_id'] = str(user_xr_experience_data['_id'])
            user_xr_experience_data['user_id'] = str(user_xr_experience_data['user_id'])
            user_xr_experience_data['experience_id'] = str(user_xr_experience_data['experience_id'])
            
            return jsonify({
                'message': 'تم إعادة بدء تجربة التعلم الغامرة بنجاح!',
                'user_xr_experience': user_xr_experience_data
            }), 200
        else:
            # إنشاء علاقة جديدة
            user_xr_experience = UserXRExperience(
                user_id=request.current_user['_id'],
                experience_id=experience_id,
                status='in_progress',
                progress=0,
                started_at=datetime.utcnow()
            )
            
            # حفظ العلاقة في قاعدة البيانات
            user_xr_experience_dict = user_xr_experience.to_dict()
            db.user_xr_experiences.insert_one(user_xr_experience_dict)
            
            # تحويل ObjectId إلى سلسلة
            user_xr_experience_dict['_id'] = str(user_xr_experience_dict['_id'])
            user_xr_experience_dict['user_id'] = str(user_xr_experience_dict['user_id'])
            user_xr_experience_dict['experience_id'] = str(user_xr_experience_dict['experience_id'])
            
            return jsonify({
                'message': 'تم بدء تجربة التعلم الغامرة بنجاح!',
                'user_xr_experience': user_xr_experience_dict
            }), 201
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف تجربة التعلم الغامرة غير صالح!'}), 400

@xr_experiences_bp.route('/user-xr-experiences/<user_xr_experience_id>', methods=['PUT'])
@token_required
def update_user_xr_experience(user_xr_experience_id):
    """
    تحديث تقدم المستخدم في تجربة تعلم غامرة
    """
    try:
        # البحث عن العلاقة
        user_xr_experience_data = db.user_xr_experiences.find_one({'_id': ObjectId(user_xr_experience_id)})
        if not user_xr_experience_data:
            return jsonify({'message': 'العلاقة غير موجودة!'}), 404
        
        # التحقق من صلاحيات المستخدم
        if str(user_xr_experience_data['user_id']) != str(request.current_user['_id']):
            return jsonify({'message': 'غير مصرح لك بتحديث هذه العلاقة!'}), 403
        
        data = request.get_json()
        if not data:
            return jsonify({'message': 'لا توجد بيانات للتحديث!'}), 400
        
        # تحديد البيانات القابلة للتحديث
        update_data = {}
        allowed_fields = ['status', 'progress', 'time_spent', 'interactions_count', 'achievements']
        
        for field in allowed_fields:
            if field in data:
                update_data[field] = data[field]
        
        # تحديث تاريخ الإكمال إذا تم تغيير الحالة إلى "completed"
        if 'status' in update_data and update_data['status'] == 'completed':
            update_data['completed_at'] = datetime.utcnow()
        
        # تحديث العلاقة في قاعدة البيانات
        if update_data:
            db.user_xr_experiences.update_one({'_id': ObjectId(user_xr_experience_id)}, {'$set': update_data})
        
        # الحصول على بيانات العلاقة المحدثة
        updated_user_xr_experience = db.user_xr_experiences.find_one({'_id': ObjectId(user_xr_experience_id)})
        
        # تحويل ObjectId إلى سلسلة
        updated_user_xr_experience['_id'] = str(updated_user_xr_experience['_id'])
        updated_user_xr_experience['user_id'] = str(updated_user_xr_experience['user_id'])
        updated_user_xr_experience['experience_id'] = str(updated_user_xr_experience['experience_id'])
        
        return jsonify({
            'message': 'تم تحديث تقدم المستخدم في تجربة التعلم الغامرة بنجاح!',
            'user_xr_experience': updated_user_xr_experience
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف العلاقة غير صالح!'}), 400

@xr_experiences_bp.route('/user-xr-experiences/user/<user_id>', methods=['GET'])
@token_required
def get_user_xr_experiences(user_id):
    """
    الحصول على جميع تجارب التعلم الغامرة لمستخدم محدد
    """
    try:
        # التحقق من صلاحيات المستخدم
        current_user = request.current_user
        if current_user['role'] == 'student' and str(current_user['_id']) != user_id:
            return jsonify({'message': 'غير مصرح لك بالوصول إلى تجارب هذا المستخدم!'}), 403
        
        # البحث عن العلاقات
        user_xr_experiences_cursor = db.user_xr_experiences.find({'user_id': ObjectId(user_id)})
        
        # تحويل النتائج إلى قائمة
        user_xr_experiences = []
        for user_xr_experience in user_xr_experiences_cursor:
            # تحويل ObjectId إلى سلسلة
            user_xr_experience['_id'] = str(user_xr_experience['_id'])
            user_xr_experience['user_id'] = str(user_xr_experience['user_id'])
            user_xr_experience['experience_id'] = str(user_xr_experience['experience_id'])
            
            # الحصول على معلومات التجربة
            xr_experience_data = db.xr_experiences.find_one({'_id': ObjectId(user_xr_experience['experience_id'])})
            if xr_experience_data:
                xr_experience_data['_id'] = str(xr_experience_data['_id'])
                xr_experience_data['created_by'] = str(xr_experience_data['created_by']) if xr_experience_data['created_by'] else None
                user_xr_experience['experience_info'] = xr_experience_data
            
            user_xr_experiences.append(user_xr_experience)
        
        return jsonify({
            'message': 'تم الحصول على تجارب التعلم الغامرة للمستخدم بنجاح!',
            'user_id': user_id,
            'user_xr_experiences': user_xr_experiences
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف المستخدم غير صالح!'}), 400

@xr_experiences_bp.route('/user-xr-experiences/experience/<experience_id>', methods=['GET'])
@token_required
def get_xr_experience_users(experience_id):
    """
    الحصول على جميع المستخدمين لتجربة تعلم غامرة محددة
    """
    try:
        # التحقق من صلاحيات المستخدم
        if request.current_user['role'] == 'student':
            return jsonify({'message': 'غير مصرح لك بالوصول إلى هذه المعلومات!'}), 403
        
        # التحقق من وجود التجربة
        xr_experience = db.xr_experiences.find_one({'_id': ObjectId(experience_id)})
        if not xr_experience:
            return jsonify({'message': 'تجربة التعلم الغامرة غير موجودة!'}), 404
        
        # التحقق من صلاحيات المعلم
        if request.current_user['role'] == 'teacher' and str(xr_experience['created_by']) != str(request.current_user['_id']):
            return jsonify({'message': 'غير مصرح لك بالوصول إلى هذه المعلومات!'}), 403
        
        # البحث عن العلاقات
        user_xr_experiences_cursor = db.user_xr_experiences.find({'experience_id': ObjectId(experience_id)})
        
        # تحويل النتائج إلى قائمة
        user_xr_experiences = []
        for user_xr_experience in user_xr_experiences_cursor:
            # تحويل ObjectId إلى سلسلة
            user_xr_experience['_id'] = str(user_xr_experience['_id'])
            user_xr_experience['user_id'] = str(user_xr_experience['user_id'])
            user_xr_experience['experience_id'] = str(user_xr_experience['experience_id'])
            
            # الحصول على معلومات المستخدم
            user_data = db.users.find_one({'_id': ObjectId(user_xr_experience['user_id'])})
            if user_data:
                user_xr_experience['user_info'] = {
                    'username': user_data['username'],
                    'first_name': user_data.get('first_name', ''),
                    'last_name': user_data.get('last_name', '')
                }
            
            user_xr_experiences.append(user_xr_experience)
        
        return jsonify({
            'message': 'تم الحصول على مستخدمي تجربة التعلم الغامرة بنجاح!',
            'experience_id': experience_id,
            'user_xr_experiences': user_xr_experiences
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف تجربة التعلم الغامرة غير صالح!'}), 400

