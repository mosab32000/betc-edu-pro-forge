#!/bin/bash
# سكربت لتحسين أداء قاعدة البيانات

# التأكد من وجود المتطلبات
command -v mongo >/dev/null 2>&1 || { echo "يرجى تثبيت MongoDB أولاً"; exit 1; }

# إنشاء الفهارس
echo "إنشاء الفهارس في قاعدة البيانات..."

# فهارس المستخدمين
mongo eduverse --eval '
db.users.createIndex({ "username": 1 }, { unique: true });
db.users.createIndex({ "email": 1 }, { unique: true });
db.users.createIndex({ "role": 1 });
'

# فهارس المهام
mongo eduverse --eval '
db.tasks.createIndex({ "subject": 1 });
db.tasks.createIndex({ "created_by": 1 });
db.tasks.createIndex({ "due_date": 1 });
db.tasks.createIndex({ "difficulty": 1 });
db.tasks.createIndex({ "tags": 1 });
'

# فهارس التقييمات
mongo eduverse --eval '
db.assessments.createIndex({ "task_id": 1 });
db.assessments.createIndex({ "student_id": 1 });
db.assessments.createIndex({ "status": 1 });
db.assessments.createIndex({ "submitted_at": 1 });
db.assessments.createIndex({ "evaluated_by": 1 });
'

# فهارس تجارب التعلم الغامرة
mongo eduverse --eval '
db.xr_experiences.createIndex({ "subject": 1 });
db.xr_experiences.createIndex({ "type": 1 });
db.xr_experiences.createIndex({ "difficulty": 1 });
db.xr_experiences.createIndex({ "tags": 1 });
'

# فهارس الأوسمة
mongo eduverse --eval '
db.badges.createIndex({ "category": 1 });
db.badges.createIndex({ "rarity": 1 });
'

# فهارس تقدم المستخدمين
mongo eduverse --eval '
db.user_progress.createIndex({ "user_id": 1 });
db.user_progress.createIndex({ "xr_id": 1 });
db.user_progress.createIndex({ "badge_id": 1 });
db.user_progress.createIndex({ "user_id": 1, "xr_id": 1 }, { unique: true });
'

echo "تم إنشاء الفهارس بنجاح."

# تحسين أداء قاعدة البيانات
echo "تحسين أداء قاعدة البيانات..."

# تكوين خيارات قاعدة البيانات
mongo eduverse --eval '
db.adminCommand({
    setParameter: 1,
    internalQueryExecMaxBlockingSortBytes: 104857600
});
'

echo "تم تحسين أداء قاعدة البيانات بنجاح."

