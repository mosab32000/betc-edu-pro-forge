#!/bin/bash
# سكربت لتحسين البنية التحتية للمنصة

echo "بدء تحسين البنية التحتية للمنصة..."

# 1. تحسين تكوين خادم الويب (Gunicorn)
echo "1. تحسين تكوين خادم الويب (Gunicorn)..."

cat > /home/ubuntu/eduverse_btec_api/gunicorn_config.py << 'EOL'
# تكوين Gunicorn لدعم 10,000 مستخدم متزامن

# عدد عمليات العمال
workers = 8  # عدد وحدات المعالجة المركزية * 2 + 1

# عدد المواضيع لكل عامل
threads = 4

# وقت الانتظار للطلبات
timeout = 60

# الحد الأقصى للطلبات المتزامنة
max_requests = 1000
max_requests_jitter = 50

# تكوين المخزن المؤقت للعمال
worker_class = 'gevent'
worker_connections = 1000

# تكوين الخادم
bind = '0.0.0.0:5000'
keepalive = 5

# تكوين السجلات
accesslog = 'logs/access.log'
errorlog = 'logs/error.log'
loglevel = 'info'

# تكوين الأداء
graceful_timeout = 30
EOL

echo "تم إنشاء ملف تكوين Gunicorn."

# 2. تحسين تكوين Redis للتخزين المؤقت
echo "2. تحسين تكوين Redis للتخزين المؤقت..."

mkdir -p /home/ubuntu/eduverse_btec_api/config
cat > /home/ubuntu/eduverse_btec_api/config/redis.conf << 'EOL'
# تكوين Redis للتخزين المؤقت

# إعدادات الذاكرة
maxmemory 1gb
maxmemory-policy allkeys-lru

# إعدادات الأداء
tcp-backlog 511
timeout 0
tcp-keepalive 300
databases 16

# إعدادات التخزين المؤقت
lazyfree-lazy-eviction yes
lazyfree-lazy-expire yes
lazyfree-lazy-server-del yes
replica-lazy-flush yes

# إعدادات الأمان
protected-mode yes
EOL

echo "تم إنشاء ملف تكوين Redis."

# 3. تحسين تكوين Nginx للتوازن الأمثل للحمل
echo "3. تحسين تكوين Nginx للتوازن الأمثل للحمل..."

cat > /home/ubuntu/eduverse_btec_api/config/nginx.conf << 'EOL'
user www-data;
worker_processes auto;
pid /run/nginx.pid;
include /etc/nginx/modules-enabled/*.conf;

events {
    worker_connections 4096;
    multi_accept on;
    use epoll;
}

http {
    # إعدادات أساسية
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    server_tokens off;

    # إعدادات المخزن المؤقت
    open_file_cache max=1000 inactive=20s;
    open_file_cache_valid 30s;
    open_file_cache_min_uses 2;
    open_file_cache_errors on;

    # إعدادات GZIP
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_buffers 16 8k;
    gzip_http_version 1.1;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

    # إعدادات الحد من معدل الطلبات
    limit_req_zone $binary_remote_addr zone=api_limit:10m rate=10r/s;
    limit_conn_zone $binary_remote_addr zone=addr:10m;

    # تكوين الخادم
    server {
        listen 80;
        server_name _;

        # إعدادات CORS
        add_header 'Access-Control-Allow-Origin' '*' always;
        add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS, PUT, DELETE' always;
        add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range,Authorization' always;
        add_header 'Access-Control-Expose-Headers' 'Content-Length,Content-Range' always;

        # المخزن المؤقت للملفات الثابتة
        location /static/ {
            alias /home/ubuntu/eduverse_btec_api/static/;
            expires 30d;
            add_header Cache-Control "public, max-age=2592000";
        }

        # المخزن المؤقت للصور
        location /media/ {
            alias /home/ubuntu/eduverse_btec_api/media/;
            expires 30d;
            add_header Cache-Control "public, max-age=2592000";
        }

        # توجيه طلبات API
        location /api/ {
            limit_req zone=api_limit burst=20 nodelay;
            limit_conn addr 10;
            
            proxy_pass http://backend;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            
            proxy_connect_timeout 5;
            proxy_send_timeout 60;
            proxy_read_timeout 60;
            
            proxy_buffering on;
            proxy_buffer_size 16k;
            proxy_buffers 8 16k;
            
            proxy_http_version 1.1;
            proxy_set_header Connection "";
        }

        # توجيه طلبات الواجهة الأمامية
        location / {
            root /home/ubuntu/eduverse-btec-frontend/dist;
            try_files $uri $uri/ /index.html;
            expires 1h;
            add_header Cache-Control "public, max-age=3600";
        }
    }

    # تكوين مجموعة الخوادم الخلفية
    upstream backend {
        least_conn;  # استخدام خوارزمية أقل اتصال
        server 127.0.0.1:5000 max_fails=3 fail_timeout=30s;
        server 127.0.0.1:5001 max_fails=3 fail_timeout=30s backup;
        keepalive 32;
    }
}
EOL

echo "تم إنشاء ملف تكوين Nginx."

# 4. تحسين تكوين MongoDB
echo "4. تحسين تكوين MongoDB..."

cat > /home/ubuntu/eduverse_btec_api/config/mongod.conf << 'EOL'
# تكوين MongoDB

# إعدادات الشبكة
net:
  port: 27017
  bindIp: 127.0.0.1

# إعدادات التخزين
storage:
  dbPath: /var/lib/mongodb
  journal:
    enabled: true
  wiredTiger:
    engineConfig:
      cacheSizeGB: 2
      journalCompressor: snappy
    collectionConfig:
      blockCompressor: snappy
    indexConfig:
      prefixCompression: true

# إعدادات الذاكرة
setParameter:
  internalQueryExecMaxBlockingSortBytes: 104857600

# إعدادات السجلات
systemLog:
  destination: file
  logAppend: true
  path: /var/log/mongodb/mongod.log

# إعدادات المعاملات
operationProfiling:
  mode: slowOp
  slowOpThresholdMs: 100
EOL

echo "تم إنشاء ملف تكوين MongoDB."

# 5. تحسين تكوين Kubernetes
echo "5. تحسين تكوين Kubernetes..."

cat > /home/ubuntu/eduverse_btec_api/kubernetes/deployment-optimized.yaml << 'EOL'
apiVersion: apps/v1
kind: Deployment
metadata:
  name: eduverse-app
  labels:
    app: eduverse
spec:
  replicas: 8  # زيادة عدد النسخ
  selector:
    matchLabels:
      app: eduverse
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 2
      maxUnavailable: 1
  template:
    metadata:
      labels:
        app: eduverse
    spec:
      containers:
      - name: eduverse-app
        image: eduverse-app:latest
        imagePullPolicy: Always
        ports:
        - containerPort: 5000
        resources:
          limits:
            cpu: "2"  # زيادة حد وحدة المعالجة المركزية
            memory: "2Gi"  # زيادة حد الذاكرة
          requests:
            cpu: "1"  # زيادة طلب وحدة المعالجة المركزية
            memory: "1Gi"  # زيادة طلب الذاكرة
        env:
        - name: FLASK_ENV
          value: "production"
        - name: MONGODB_URI
          valueFrom:
            secretKeyRef:
              name: eduverse-secrets
              key: mongodb-uri
        - name: REDIS_URI
          valueFrom:
            secretKeyRef:
              name: eduverse-secrets
              key: redis-uri
        - name: CACHE_TYPE
          value: "redis"  # تفعيل التخزين المؤقت
        - name: WORKERS
          value: "4"  # عدد العمال لكل حاوية
        livenessProbe:
          httpGet:
            path: /health
            port: 5000
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 5
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /health
            port: 5000
          initialDelaySeconds: 5
          periodSeconds: 5
          timeoutSeconds: 3
          failureThreshold: 2
        volumeMounts:
        - name: config-volume
          mountPath: /app/config
        - name: cache-volume
          mountPath: /app/cache
      volumes:
      - name: config-volume
        configMap:
          name: eduverse-config
      - name: cache-volume
        emptyDir: {}
---
apiVersion: v1
kind: Service
metadata:
  name: eduverse-service
  labels:
    app: eduverse
spec:
  selector:
    app: eduverse
  ports:
  - port: 80
    targetPort: 5000
  type: LoadBalancer
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: eduverse-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: eduverse-app
  minReplicas: 4
  maxReplicas: 16
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
  behavior:
    scaleUp:
      stabilizationWindowSeconds: 60
      policies:
      - type: Percent
        value: 100
        periodSeconds: 60
    scaleDown:
      stabilizationWindowSeconds: 300
      policies:
      - type: Percent
        value: 10
        periodSeconds: 60
EOL

echo "تم إنشاء ملف تكوين Kubernetes المحسن."

# 6. تحسين تكوين Redis للتخزين المؤقت في التطبيق
echo "6. تحسين تكوين التخزين المؤقت في التطبيق..."

cat > /home/ubuntu/eduverse_btec_api/src/cache.py << 'EOL'
"""
وحدة التخزين المؤقت للتطبيق

توفر هذه الوحدة وظائف التخزين المؤقت لتحسين أداء التطبيق.
"""

import os
import json
import hashlib
import time
from functools import wraps
from flask import request, current_app
import redis

# إنشاء اتصال Redis
redis_client = redis.Redis.from_url(
    os.environ.get('REDIS_URI', 'redis://localhost:6379/0'),
    decode_responses=True
)

def cache_key(prefix='', args=None, kwargs=None):
    """إنشاء مفتاح للتخزين المؤقت"""
    args_str = str(args) if args else ''
    kwargs_str = str(kwargs) if kwargs else ''
    
    # إضافة معلومات المستخدم إذا كان مصادقًا
    user_info = ''
    if hasattr(request, 'user') and request.user:
        user_info = str(request.user.id)
    
    # إنشاء مفتاح فريد
    key_base = f"{prefix}:{request.path}:{args_str}:{kwargs_str}:{user_info}"
    return hashlib.md5(key_base.encode()).hexdigest()

def cache(timeout=300, prefix='view'):
    """
    مزخرف للتخزين المؤقت
    
    يستخدم هذا المزخرف لتخزين نتائج الدالة في ذاكرة التخزين المؤقت.
    
    المعلمات:
        timeout (int): مدة صلاحية التخزين المؤقت بالثواني
        prefix (str): بادئة لمفتاح التخزين المؤقت
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # التحقق مما إذا كان التخزين المؤقت مفعلًا
            if not current_app.config.get('CACHE_ENABLED', True):
                return f(*args, **kwargs)
            
            # إنشاء مفتاح التخزين المؤقت
            key = cache_key(prefix, args, kwargs)
            
            # محاولة استرداد القيمة من التخزين المؤقت
            cached_value = redis_client.get(key)
            if cached_value:
                return json.loads(cached_value)
            
            # تنفيذ الدالة وتخزين النتيجة
            result = f(*args, **kwargs)
            
            # تخزين النتيجة في التخزين المؤقت
            try:
                redis_client.setex(key, timeout, json.dumps(result))
            except (TypeError, ValueError):
                # إذا لم يمكن تحويل النتيجة إلى JSON، تخطي التخزين المؤقت
                pass
            
            return result
        return decorated_function
    return decorator

def invalidate_cache(prefix='view', pattern=None):
    """
    إبطال التخزين المؤقت
    
    يستخدم هذا المزخرف لإبطال التخزين المؤقت عند تغيير البيانات.
    
    المعلمات:
        prefix (str): بادئة لمفتاح التخزين المؤقت
        pattern (str): نمط لمطابقة مفاتيح التخزين المؤقت
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # تنفيذ الدالة
            result = f(*args, **kwargs)
            
            # إبطال التخزين المؤقت
            if pattern:
                keys = redis_client.keys(pattern)
                if keys:
                    redis_client.delete(*keys)
            else:
                keys = redis_client.keys(f"{prefix}:*")
                if keys:
                    redis_client.delete(*keys)
            
            return result
        return decorated_function
    return decorator

def rate_limit(limit=100, per=60, prefix='ratelimit'):
    """
    مزخرف للحد من معدل الطلبات
    
    يستخدم هذا المزخرف للحد من عدد الطلبات لكل مستخدم.
    
    المعلمات:
        limit (int): الحد الأقصى لعدد الطلبات
        per (int): الفترة الزمنية بالثواني
        prefix (str): بادئة لمفتاح التخزين المؤقت
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # الحصول على عنوان IP للمستخدم
            ip = request.remote_addr
            
            # إنشاء مفتاح للحد من معدل الطلبات
            key = f"{prefix}:{ip}:{request.path}"
            
            # الحصول على عدد الطلبات الحالي
            current = redis_client.get(key)
            if current and int(current) >= limit:
                return {"error": "تجاوز الحد الأقصى لعدد الطلبات"}, 429
            
            # زيادة عدد الطلبات
            pipe = redis_client.pipeline()
            pipe.incr(key)
            pipe.expire(key, per)
            pipe.execute()
            
            # تنفيذ الدالة
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def cache_warmup(endpoints):
    """
    تهيئة التخزين المؤقت
    
    يستخدم هذا الدالة لتهيئة التخزين المؤقت للنقاط النهائية الشائعة.
    
    المعلمات:
        endpoints (list): قائمة بالنقاط النهائية للتهيئة
    """
    for endpoint in endpoints:
        try:
            # استدعاء النقطة النهائية لتهيئة التخزين المؤقت
            response = requests.get(endpoint)
            if response.status_code == 200:
                print(f"تم تهيئة التخزين المؤقت للنقطة النهائية: {endpoint}")
        except Exception as e:
            print(f"فشل تهيئة التخزين المؤقت للنقطة النهائية: {endpoint} - {str(e)}")
EOL

echo "تم إنشاء ملف تكوين التخزين المؤقت في التطبيق."

# 7. تحسين تكوين نموذج Llama 3
echo "7. تحسين تكوين نموذج Llama 3..."

cat > /home/ubuntu/eduverse_btec_api/src/ai/llama_config.py << 'EOL'
"""
تكوين نموذج Llama 3

يحتوي هذا الملف على تكوين نموذج Llama 3 المحسن للأداء.
"""

import os
import torch

# التحقق من وجود GPU
USE_GPU = torch.cuda.is_available()
GPU_LAYERS = 40 if USE_GPU else 0

# تكوين النموذج
MODEL_CONFIG = {
    # مسار النموذج
    "model_path": os.environ.get("LLAMA_MODEL_PATH", "/home/ubuntu/eduverse_btec_api/models/llama-3-8b-instruct.Q4_K_M.gguf"),
    
    # معلمات الذاكرة
    "n_ctx": 2048,  # حجم سياق النموذج
    "n_batch": 512,  # حجم الدفعة
    
    # معلمات المعالجة
    "n_threads": 8,  # عدد مسارات المعالجة
    "n_gpu_layers": GPU_LAYERS,  # عدد طبقات GPU
    
    # معلمات الذاكرة
    "use_mlock": True,  # استخدام mlock لمنع تبديل الذاكرة
    "use_mmap": True,  # استخدام mmap لتحميل النموذج
    
    # معلمات الاستدلال
    "embedding": False,  # تعطيل التضمين
    "last_n_tokens_size": 64,  # حجم آخر الرموز
    "verbose": False,  # تعطيل الإخراج المطول
}

# معلمات الاستدلال الافتراضية
DEFAULT_GENERATION_CONFIG = {
    "max_tokens": 256,  # الحد الأقصى لعدد الرموز
    "temperature": 0.7,  # درجة الحرارة
    "top_p": 0.95,  # احتمالية القمة
    "top_k": 40,  # أفضل k
    "repeat_penalty": 1.1,  # عقوبة التكرار
    "presence_penalty": 0.0,  # عقوبة الوجود
    "frequency_penalty": 0.0,  # عقوبة التكرار
    "stop": ["</s>", "User:", "Assistant:"],  # رموز التوقف
}

# تكوين التخزين المؤقت
CACHE_CONFIG = {
    "enabled": True,  # تفعيل التخزين المؤقت
    "timeout": 3600,  # مدة صلاحية التخزين المؤقت (1 ساعة)
    "prefix": "llama",  # بادئة مفتاح التخزين المؤقت
}

# تكوين مجمع الاستدلال
INFERENCE_POOL_CONFIG = {
    "max_workers": 4,  # الحد الأقصى لعدد العمال
    "max_queue_size": 100,  # الحد الأقصى لحجم قائمة الانتظار
}
EOL

echo "تم إنشاء ملف تكوين نموذج Llama 3."

# 8. تحسين تكوين مجمع الاتصال بقاعدة البيانات
echo "8. تحسين تكوين مجمع الاتصال بقاعدة البيانات..."

cat > /home/ubuntu/eduverse_btec_api/src/models/db_pool.py << 'EOL'
"""
مجمع الاتصال بقاعدة البيانات

يوفر هذا الملف مجمع اتصال لقاعدة البيانات لتحسين الأداء.
"""

import os
import time
import threading
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, OperationFailure

class DatabaseConnectionPool:
    """
    مجمع الاتصال بقاعدة البيانات
    
    يوفر هذا الصنف مجمع اتصال لقاعدة البيانات لتحسين الأداء.
    """
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(DatabaseConnectionPool, cls).__new__(cls)
                cls._instance._initialized = False
            return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        self._initialized = True
        self._connections = []
        self._in_use = {}
        self._lock = threading.Lock()
        
        # تكوين المجمع
        self.max_connections = int(os.environ.get("DB_MAX_CONNECTIONS", "20"))
        self.min_connections = int(os.environ.get("DB_MIN_CONNECTIONS", "5"))
        self.connection_timeout = int(os.environ.get("DB_CONNECTION_TIMEOUT", "30"))
        self.idle_timeout = int(os.environ.get("DB_IDLE_TIMEOUT", "300"))
        
        # إنشاء الاتصالات الأولية
        self._create_initial_connections()
        
        # بدء مؤقت التنظيف
        self._cleanup_timer = threading.Timer(60.0, self._cleanup_idle_connections)
        self._cleanup_timer.daemon = True
        self._cleanup_timer.start()
    
    def _create_initial_connections(self):
        """إنشاء الاتصالات الأولية"""
        for _ in range(self.min_connections):
            self._add_connection()
    
    def _add_connection(self):
        """إضافة اتصال جديد إلى المجمع"""
        try:
            # إنشاء اتصال جديد
            connection = MongoClient(
                os.environ.get("MONGODB_URI", "mongodb://localhost:27017/eduverse"),
                connectTimeoutMS=self.connection_timeout * 1000,
                serverSelectionTimeoutMS=self.connection_timeout * 1000,
                maxPoolSize=1,
                minPoolSize=1,
                maxIdleTimeMS=self.idle_timeout * 1000
            )
            
            # التحقق من الاتصال
            connection.admin.command('ping')
            
            # إضافة الاتصال إلى المجمع
            with self._lock:
                self._connections.append({
                    "connection": connection,
                    "created_at": time.time(),
                    "last_used": time.time()
                })
            
            return True
        except (ConnectionFailure, OperationFailure) as e:
            print(f"فشل إنشاء اتصال جديد: {str(e)}")
            return False
    
    def get_connection(self):
        """الحصول على اتصال من المجمع"""
        with self._lock:
            # البحث عن اتصال متاح
            for i, conn_info in enumerate(self._connections):
                if i not in self._in_use:
                    # تحديث وقت آخر استخدام
                    conn_info["last_used"] = time.time()
                    
                    # تعليم الاتصال كقيد الاستخدام
                    self._in_use[i] = time.time()
                    
                    return i, conn_info["connection"]
            
            # إذا لم يتم العثور على اتصال متاح، إنشاء اتصال جديد
            if len(self._connections) < self.max_connections:
                if self._add_connection():
                    i = len(self._connections) - 1
                    conn_info = self._connections[i]
                    
                    # تعليم الاتصال كقيد الاستخدام
                    self._in_use[i] = time.time()
                    
                    return i, conn_info["connection"]
            
            # إذا وصلنا إلى الحد الأقصى للاتصالات، انتظار اتصال متاح
            return None, None
    
    def release_connection(self, index):
        """إعادة اتصال إلى المجمع"""
        with self._lock:
            if index in self._in_use:
                del self._in_use[index]
    
    def _cleanup_idle_connections(self):
        """تنظيف الاتصالات الخاملة"""
        try:
            with self._lock:
                # الحصول على الوقت الحالي
                current_time = time.time()
                
                # تحديد الاتصالات الخاملة
                idle_connections = []
                for i, conn_info in enumerate(self._connections):
                    if i not in self._in_use and current_time - conn_info["last_used"] > self.idle_timeout:
                        idle_connections.append(i)
                
                # إغلاق الاتصالات الخاملة
                for i in reversed(idle_connections):
                    # التأكد من أن لدينا الحد الأدنى من الاتصالات
                    if len(self._connections) - len(idle_connections) < self.min_connections:
                        break
                    
                    # إغلاق الاتصال
                    try:
                        self._connections[i]["connection"].close()
                    except Exception:
                        pass
                    
                    # إزالة الاتصال من المجمع
                    del self._connections[i]
        finally:
            # إعادة جدولة المؤقت
            self._cleanup_timer = threading.Timer(60.0, self._cleanup_idle_connections)
            self._cleanup_timer.daemon = True
            self._cleanup_timer.start()
    
    def close_all_connections(self):
        """إغلاق جميع الاتصالات"""
        with self._lock:
            for conn_info in self._connections:
                try:
                    conn_info["connection"].close()
                except Exception:
                    pass
            
            self._connections = []
            self._in_use = {}
            
            # إلغاء المؤقت
            if self._cleanup_timer:
                self._cleanup_timer.cancel()

# إنشاء كائن مجمع الاتصال
db_pool = DatabaseConnectionPool()

def get_db_connection():
    """الحصول على اتصال من المجمع"""
    index, connection = db_pool.get_connection()
    if connection is None:
        # إذا لم يتم العثور على اتصال متاح، إنشاء اتصال مؤقت
        connection = MongoClient(
            os.environ.get("MONGODB_URI", "mongodb://localhost:27017/eduverse"),
            connectTimeoutMS=30000,
            serverSelectionTimeoutMS=30000
        )
        return None, connection
    
    return index, connection

def release_db_connection(index):
    """إعادة اتصال إلى المجمع"""
    if index is not None:
        db_pool.release_connection(index)
EOL

echo "تم إنشاء ملف تكوين مجمع الاتصال بقاعدة البيانات."

# 9. تحسين تكوين الخدمة
echo "9. تحسين تكوين الخدمة..."

cat > /home/ubuntu/eduverse_btec_api/src/config.py << 'EOL'
"""
تكوين التطبيق

يحتوي هذا الملف على تكوين التطبيق المحسن للأداء.
"""

import os
import multiprocessing

# إعدادات التطبيق
APP_CONFIG = {
    "DEBUG": os.environ.get("FLASK_ENV") == "development",
    "TESTING": False,
    "SECRET_KEY": os.environ.get("SECRET_KEY", "eduverse-btec-secret-key"),
    "PERMANENT_SESSION_LIFETIME": 86400,  # 24 ساعة
    "SESSION_TYPE": "redis",
    "SESSION_PERMANENT": True,
    "SESSION_USE_SIGNER": True,
    "SESSION_REDIS": os.environ.get("REDIS_URI", "redis://localhost:6379/1"),
}

# إعدادات قاعدة البيانات
DB_CONFIG = {
    "MONGODB_URI": os.environ.get("MONGODB_URI", "mongodb://localhost:27017/eduverse"),
    "DB_MAX_CONNECTIONS": int(os.environ.get("DB_MAX_CONNECTIONS", "20")),
    "DB_MIN_CONNECTIONS": int(os.environ.get("DB_MIN_CONNECTIONS", "5")),
    "DB_CONNECTION_TIMEOUT": int(os.environ.get("DB_CONNECTION_TIMEOUT", "30")),
    "DB_IDLE_TIMEOUT": int(os.environ.get("DB_IDLE_TIMEOUT", "300")),
}

# إعدادات التخزين المؤقت
CACHE_CONFIG = {
    "CACHE_TYPE": os.environ.get("CACHE_TYPE", "redis"),
    "CACHE_REDIS_URL": os.environ.get("REDIS_URI", "redis://localhost:6379/0"),
    "CACHE_DEFAULT_TIMEOUT": 300,
    "CACHE_KEY_PREFIX": "eduverse:",
    "CACHE_ENABLED": True,
}

# إعدادات الخادم
SERVER_CONFIG = {
    "HOST": "0.0.0.0",
    "PORT": int(os.environ.get("PORT", "5000")),
    "WORKERS": int(os.environ.get("WORKERS", str(multiprocessing.cpu_count() * 2 + 1))),
    "THREADS": int(os.environ.get("THREADS", "4")),
    "TIMEOUT": int(os.environ.get("TIMEOUT", "60")),
    "MAX_REQUESTS": int(os.environ.get("MAX_REQUESTS", "1000")),
    "MAX_REQUESTS_JITTER": int(os.environ.get("MAX_REQUESTS_JITTER", "50")),
    "WORKER_CLASS": os.environ.get("WORKER_CLASS", "gevent"),
    "WORKER_CONNECTIONS": int(os.environ.get("WORKER_CONNECTIONS", "1000")),
}

# إعدادات CORS
CORS_CONFIG = {
    "CORS_ORIGINS": os.environ.get("CORS_ORIGINS", "*"),
    "CORS_METHODS": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    "CORS_ALLOW_HEADERS": ["Content-Type", "Authorization"],
    "CORS_EXPOSE_HEADERS": ["Content-Length", "Content-Range"],
    "CORS_SUPPORTS_CREDENTIALS": True,
    "CORS_MAX_AGE": 86400,  # 24 ساعة
}

# إعدادات JWT
JWT_CONFIG = {
    "JWT_SECRET_KEY": os.environ.get("JWT_SECRET_KEY", "eduverse-btec-jwt-secret-key"),
    "JWT_ACCESS_TOKEN_EXPIRES": 86400,  # 24 ساعة
    "JWT_REFRESH_TOKEN_EXPIRES": 2592000,  # 30 يوم
    "JWT_BLACKLIST_ENABLED": True,
    "JWT_BLACKLIST_TOKEN_CHECKS": ["access", "refresh"],
}

# إعدادات الحد من معدل الطلبات
RATE_LIMIT_CONFIG = {
    "RATELIMIT_ENABLED": True,
    "RATELIMIT_STRATEGY": "fixed-window",
    "RATELIMIT_STORAGE_URL": os.environ.get("REDIS_URI", "redis://localhost:6379/2"),
    "RATELIMIT_DEFAULT": "100/hour",
    "RATELIMIT_HEADERS_ENABLED": True,
}

# إعدادات البلوكتشين
BLOCKCHAIN_CONFIG = {
    "BLOCKCHAIN_ENABLED": True,
    "BLOCKCHAIN_TYPE": os.environ.get("BLOCKCHAIN_TYPE", "ethereum"),
    "BLOCKCHAIN_URL": os.environ.get("BLOCKCHAIN_URL", "http://localhost:8545"),
    "BLOCKCHAIN_PRIVATE_KEY": os.environ.get("BLOCKCHAIN_PRIVATE_KEY", ""),
    "BLOCKCHAIN_CONTRACT_ADDRESS": os.environ.get("BLOCKCHAIN_CONTRACT_ADDRESS", ""),
}

# إعدادات الذكاء الاصطناعي
AI_CONFIG = {
    "AI_ENABLED": True,
    "AI_MODEL_TYPE": os.environ.get("AI_MODEL_TYPE", "llama"),
    "AI_MODEL_PATH": os.environ.get("AI_MODEL_PATH", "/home/ubuntu/eduverse_btec_api/models/llama-3-8b-instruct.Q4_K_M.gguf"),
    "AI_MAX_TOKENS": int(os.environ.get("AI_MAX_TOKENS", "256")),
    "AI_TEMPERATURE": float(os.environ.get("AI_TEMPERATURE", "0.7")),
    "AI_TOP_P": float(os.environ.get("AI_TOP_P", "0.95")),
    "AI_TOP_K": int(os.environ.get("AI_TOP_K", "40")),
    "AI_REPEAT_PENALTY": float(os.environ.get("AI_REPEAT_PENALTY", "1.1")),
}

# إعدادات XR
XR_CONFIG = {
    "XR_ENABLED": True,
    "XR_STORAGE_PATH": os.environ.get("XR_STORAGE_PATH", "/home/ubuntu/eduverse_btec_api/xr_storage"),
    "XR_MAX_FILE_SIZE": int(os.environ.get("XR_MAX_FILE_SIZE", "104857600")),  # 100 ميجابايت
    "XR_ALLOWED_EXTENSIONS": ["glb", "gltf", "usdz", "reality", "zip"],
}

# إعدادات السجلات
LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "standard": {
            "format": "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
        },
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "level": "INFO",
            "formatter": "standard",
            "stream": "ext://sys.stdout"
        },
        "file": {
            "class": "logging.handlers.RotatingFileHandler",
            "level": "INFO",
            "formatter": "standard",
            "filename": os.environ.get("LOG_FILE", "logs/eduverse.log"),
            "maxBytes": 10485760,  # 10 ميجابايت
            "backupCount": 10,
            "encoding": "utf8"
        },
    },
    "loggers": {
        "": {
            "handlers": ["console", "file"],
            "level": "INFO",
            "propagate": True
        },
        "werkzeug": {
            "handlers": ["console"],
            "level": "WARNING",
            "propagate": False
        },
    }
}
EOL

echo "تم إنشاء ملف تكوين الخدمة."

# 10. تحسين تكوين Docker Compose
echo "10. تحسين تكوين Docker Compose..."

cat > /home/ubuntu/eduverse_btec_api/docker-compose-optimized.yml << 'EOL'
version: '3.8'

services:
  # خدمة التطبيق
  app:
    build:
      context: .
      dockerfile: Dockerfile
    image: eduverse-app:latest
    container_name: eduverse-app
    restart: always
    ports:
      - "5000:5000"
    environment:
      - FLASK_ENV=production
      - MONGODB_URI=mongodb://mongo:27017/eduverse
      - REDIS_URI=redis://redis:6379/0
      - CACHE_TYPE=redis
      - WORKERS=4
      - THREADS=4
      - TIMEOUT=60
      - MAX_REQUESTS=1000
      - MAX_REQUESTS_JITTER=50
      - WORKER_CLASS=gevent
      - WORKER_CONNECTIONS=1000
      - DB_MAX_CONNECTIONS=20
      - DB_MIN_CONNECTIONS=5
    volumes:
      - ./logs:/app/logs
      - ./models:/app/models
      - ./xr_storage:/app/xr_storage
    depends_on:
      - mongo
      - redis
    deploy:
      resources:
        limits:
          cpus: '2'
          memory: 2G
        reservations:
          cpus: '1'
          memory: 1G
      replicas: 2
      update_config:
        parallelism: 1
        delay: 10s
        order: start-first
      restart_policy:
        condition: on-failure
        max_attempts: 3
        window: 120s
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:5000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 30s
    networks:
      - eduverse-network

  # خدمة قاعدة البيانات
  mongo:
    image: mongo:5.0
    container_name: eduverse-mongo
    restart: always
    ports:
      - "27017:27017"
    environment:
      - MONGO_INITDB_DATABASE=eduverse
    volumes:
      - mongo-data:/data/db
      - ./config/mongod.conf:/etc/mongod.conf
    command: ["--config", "/etc/mongod.conf"]
    deploy:
      resources:
        limits:
          cpus: '2'
          memory: 2G
        reservations:
          cpus: '0.5'
          memory: 512M
    healthcheck:
      test: echo 'db.runCommand("ping").ok' | mongo localhost:27017/test --quiet
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 30s
    networks:
      - eduverse-network

  # خدمة التخزين المؤقت
  redis:
    image: redis:6.2-alpine
    container_name: eduverse-redis
    restart: always
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data
      - ./config/redis.conf:/usr/local/etc/redis/redis.conf
    command: ["redis-server", "/usr/local/etc/redis/redis.conf"]
    deploy:
      resources:
        limits:
          cpus: '1'
          memory: 1G
        reservations:
          cpus: '0.2'
          memory: 256M
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 30s
    networks:
      - eduverse-network

  # خدمة التوازن الأمثل للحمل
  nginx:
    image: nginx:1.21-alpine
    container_name: eduverse-nginx
    restart: always
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./config/nginx.conf:/etc/nginx/nginx.conf
      - ./static:/usr/share/nginx/html/static
      - ./media:/usr/share/nginx/html/media
      - ./logs/nginx:/var/log/nginx
    depends_on:
      - app
    deploy:
      resources:
        limits:
          cpus: '1'
          memory: 512M
        reservations:
          cpus: '0.2'
          memory: 128M
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:80/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 30s
    networks:
      - eduverse-network

volumes:
  mongo-data:
  redis-data:

networks:
  eduverse-network:
    driver: bridge
EOL

echo "تم إنشاء ملف تكوين Docker Compose المحسن."

echo "تم الانتهاء من تحسين البنية التحتية للمنصة."

