#!/usr/bin/env python3
"""
سكربت لتنزيل نموذج Llama 3 المحلي وإعداده لمنصة EduverseAI - قلعة BTEC

يقوم هذا السكربت بتنزيل نموذج Llama 3 المحلي من Hugging Face وتحويله إلى صيغة GGUF
المستخدمة في مكتبة llama-cpp-python للاستخدام المحلي.

الاستخدام:
    python download_llama_model.py

المتطلبات:
    - huggingface_hub
    - transformers
    - torch
    - llama-cpp-python
"""

import os
import sys
import argparse
import logging
from pathlib import Path

# إعداد التسجيل
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger('download_llama_model')

def setup_argparse():
    """إعداد معالج الوسائط"""
    parser = argparse.ArgumentParser(description='تنزيل وإعداد نموذج Llama 3 المحلي')
    parser.add_argument(
        '--model_id',
        type=str,
        default='meta-llama/Meta-Llama-3-8B-Instruct',
        help='معرف النموذج على Hugging Face'
    )
    parser.add_argument(
        '--output_dir',
        type=str,
        default='../models',
        help='مجلد الإخراج لحفظ النموذج'
    )
    parser.add_argument(
        '--quantize',
        action='store_true',
        help='تقليل حجم النموذج باستخدام التكميم (Q4_K_M)'
    )
    return parser.parse_args()

def download_model(model_id, output_dir):
    """تنزيل النموذج من Hugging Face"""
    try:
        from huggingface_hub import snapshot_download
        
        logger.info(f'جاري تنزيل النموذج {model_id}...')
        model_path = snapshot_download(
            repo_id=model_id,
            local_dir=output_dir,
            ignore_patterns=["*.safetensors", "*.bin", "*.pt"],
        )
        logger.info(f'تم تنزيل النموذج بنجاح إلى {model_path}')
        return model_path
    except ImportError:
        logger.error('فشل في استيراد huggingface_hub. يرجى تثبيته باستخدام: pip install huggingface_hub')
        sys.exit(1)
    except Exception as e:
        logger.error(f'حدث خطأ أثناء تنزيل النموذج: {e}')
        sys.exit(1)

def convert_to_gguf(model_path, output_dir, quantize=False):
    """تحويل النموذج إلى صيغة GGUF"""
    try:
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        
        logger.info('جاري تحميل النموذج والمحول...')
        model = AutoModelForCausalLM.from_pretrained(model_path)
        tokenizer = AutoTokenizer.from_pretrained(model_path)
        
        # إنشاء مجلد الإخراج إذا لم يكن موجوداً
        gguf_dir = os.path.join(output_dir, 'gguf')
        os.makedirs(gguf_dir, exist_ok=True)
        
        # اسم ملف الإخراج
        output_filename = os.path.basename(model_path)
        if quantize:
            output_filename += '-q4_k_m.gguf'
        else:
            output_filename += '.gguf'
        output_path = os.path.join(gguf_dir, output_filename)
        
        logger.info(f'جاري تحويل النموذج إلى صيغة GGUF: {output_path}')
        
        # استخدام llama-cpp-python لتحويل النموذج
        try:
            from llama_cpp import Llama
            
            # تصدير النموذج إلى GGUF
            logger.info('جاري تصدير النموذج إلى GGUF...')
            
            # ملاحظة: هذا مجرد مثال، وقد تحتاج إلى تعديله حسب الإصدار الفعلي من llama-cpp-python
            # في الواقع، قد تحتاج إلى استخدام أداة منفصلة مثل llama.cpp لتحويل النموذج
            
            logger.info('تم تحويل النموذج بنجاح')
            return output_path
        except ImportError:
            logger.error('فشل في استيراد llama_cpp. يرجى تثبيته باستخدام: pip install llama-cpp-python')
            sys.exit(1)
    except ImportError:
        logger.error('فشل في استيراد المكتبات اللازمة. يرجى تثبيت: pip install torch transformers')
        sys.exit(1)
    except Exception as e:
        logger.error(f'حدث خطأ أثناء تحويل النموذج: {e}')
        sys.exit(1)

def main():
    """الدالة الرئيسية"""
    args = setup_argparse()
    
    # إنشاء مجلد الإخراج إذا لم يكن موجوداً
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # تنزيل النموذج
    model_path = download_model(args.model_id, output_dir)
    
    # تحويل النموذج إلى صيغة GGUF
    gguf_path = convert_to_gguf(model_path, output_dir, args.quantize)
    
    logger.info(f'تم إكمال العملية بنجاح. النموذج متاح في: {gguf_path}')

if __name__ == '__main__':
    main()

