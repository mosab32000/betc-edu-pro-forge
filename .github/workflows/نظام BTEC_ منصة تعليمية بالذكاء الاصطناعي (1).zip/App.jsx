import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './App.css';

// استيراد الصفحات
import Login from './pages/Login';
import Home from './pages/Home';
import TaskHall from './pages/TaskHall';
import Assessment from './pages/Assessment';
import Feedback from './pages/Feedback';
import AIAssistant from './pages/AIAssistant';
import Badges from './pages/Badges';
import XRExperiences from './pages/XRExperiences';
import Analytics from './pages/Analytics';
import EducationalGames from './pages/EducationalGames';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // محاكاة التحقق من المصادقة
  useEffect(() => {
    const checkAuth = () => {
      // في التطبيق الحقيقي، سيتم التحقق من المصادقة من الخادم
      const token = localStorage.getItem('authToken');
      setIsAuthenticated(!!token);
      setIsLoading(false);
    };

    // محاكاة تأخير الشبكة
    setTimeout(checkAuth, 1000);
  }, []);

  const handleLogin = () => {
    // في التطبيق الحقيقي، سيتم إرسال بيانات المستخدم إلى الخادم للمصادقة
    localStorage.setItem('authToken', 'dummy-token');
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('authToken');
    setIsAuthenticated(false);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen w-screen bg-primary">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-white border-t-transparent rounded-full animate-spin mx-auto"></div>
          <h2 className="mt-4 text-white text-xl font-tajawal">جاري التحميل...</h2>
        </div>
      </div>
    );
  }

  return (
    <Router>
      <AnimatePresence mode="wait">
        <Routes>
          <Route 
            path="/login" 
            element={
              isAuthenticated ? 
                <Navigate to="/" replace /> : 
                <Login onLogin={handleLogin} />
            } 
          />
          
          {/* المسارات المحمية */}
          <Route 
            path="/" 
            element={
              isAuthenticated ? 
                <Home onLogout={handleLogout} /> : 
                <Navigate to="/login" replace />
            } 
          />
          <Route 
            path="/task-hall" 
            element={
              isAuthenticated ? 
                <TaskHall /> : 
                <Navigate to="/login" replace />
            } 
          />
          <Route 
            path="/assessment" 
            element={
              isAuthenticated ? 
                <Assessment /> : 
                <Navigate to="/login" replace />
            } 
          />
          <Route 
            path="/feedback" 
            element={
              isAuthenticated ? 
                <Feedback /> : 
                <Navigate to="/login" replace />
            } 
          />
          <Route 
            path="/ai-assistant" 
            element={
              isAuthenticated ? 
                <AIAssistant /> : 
                <Navigate to="/login" replace />
            } 
          />
          <Route 
            path="/badges" 
            element={
              isAuthenticated ? 
                <Badges /> : 
                <Navigate to="/login" replace />
            } 
          />
          <Route 
            path="/xr-experiences" 
            element={
              isAuthenticated ? 
                <XRExperiences /> : 
                <Navigate to="/login" replace />
            } 
          />
          <Route 
            path="/analytics" 
            element={
              isAuthenticated ? 
                <Analytics /> : 
                <Navigate to="/login" replace />
            } 
          />
          <Route 
            path="/educational-games" 
            element={
              isAuthenticated ? 
                <EducationalGames /> : 
                <Navigate to="/login" replace />
            } 
          />
          
          {/* مسار افتراضي */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AnimatePresence>
    </Router>
  );
}

export default App;

