"""
نموذج المستخدم في منصة EduverseAI - قلعة BTEC
"""
from datetime import datetime
from bson import ObjectId

class User:
    """
    نموذج المستخدم في المنصة
    """
    def __init__(self, username, email, password_hash, role, first_name="", last_name="", 
                 profile_image="", created_at=None, updated_at=None, _id=None):
        """
        تهيئة كائن المستخدم
        
        المعلمات:
            username (str): اسم المستخدم الفريد
            email (str): البريد الإلكتروني للمستخدم
            password_hash (str): تجزئة كلمة المرور المشفرة
            role (str): دور المستخدم (طالب، معلم، مشرف)
            first_name (str): الاسم الأول للمستخدم
            last_name (str): الاسم الأخير للمستخدم
            profile_image (str): مسار صورة الملف الشخصي
            created_at (datetime): تاريخ إنشاء الحساب
            updated_at (datetime): تاريخ آخر تحديث للحساب
            _id (ObjectId): معرف المستخدم في قاعدة البيانات
        """
        self._id = _id if _id else ObjectId()
        self.username = username
        self.email = email
        self.password_hash = password_hash
        self.role = role
        self.first_name = first_name
        self.last_name = last_name
        self.profile_image = profile_image
        self.created_at = created_at if created_at else datetime.utcnow()
        self.updated_at = updated_at if updated_at else datetime.utcnow()
        
        # بيانات إضافية حسب نوع المستخدم
        self.badges = []  # الأوسمة المكتسبة
        self.points = 0   # نقاط المستخدم
        self.level = 1    # مستوى المستخدم
        self.completed_tasks = []  # المهام المكتملة
        self.active_tasks = []     # المهام النشطة
        
    def to_dict(self):
        """
        تحويل كائن المستخدم إلى قاموس
        
        العائد:
            dict: قاموس يمثل المستخدم
        """
        return {
            "_id": str(self._id),
            "username": self.username,
            "email": self.email,
            "role": self.role,
            "first_name": self.first_name,
            "last_name": self.last_name,
            "profile_image": self.profile_image,
            "badges": self.badges,
            "points": self.points,
            "level": self.level,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data):
        """
        إنشاء كائن مستخدم من قاموس
        
        المعلمات:
            data (dict): قاموس يحتوي على بيانات المستخدم
            
        العائد:
            User: كائن المستخدم
        """
        _id = ObjectId(data["_id"]) if "_id" in data else None
        created_at = datetime.fromisoformat(data["created_at"]) if "created_at" in data else None
        updated_at = datetime.fromisoformat(data["updated_at"]) if "updated_at" in data else None
        
        user = cls(
            username=data.get("username"),
            email=data.get("email"),
            password_hash=data.get("password_hash", ""),
            role=data.get("role"),
            first_name=data.get("first_name", ""),
            last_name=data.get("last_name", ""),
            profile_image=data.get("profile_image", ""),
            created_at=created_at,
            updated_at=updated_at,
            _id=_id
        )
        
        user.badges = data.get("badges", [])
        user.points = data.get("points", 0)
        user.level = data.get("level", 1)
        user.completed_tasks = data.get("completed_tasks", [])
        user.active_tasks = data.get("active_tasks", [])
        
        return user

