import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  HomeIcon,
  ArrowLeftIcon,
  BarChart3Icon,
  PieChartIcon,
  LineChartIcon,
  CalendarIcon,
  FilterIcon,
  BrainIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  LineChart, 
  Line, 
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend,
  ResponsiveContainer 
} from 'recharts';

const Analytics = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState('30');
  const [summaryData, setSummaryData] = useState({});
  const [performanceData, setPerformanceData] = useState([]);
  const [gradesDistribution, setGradesDistribution] = useState([]);
  const [btecCriteria, setBtecCriteria] = useState([]);
  const [engagementData, setEngagementData] = useState([]);

  useEffect(() => {
    // محاكاة تحميل البيانات
    const loadData = async () => {
      setIsLoading(true);
      try {
        // محاكاة تأخير الشبكة
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // بيانات وهمية للعرض
        setSummaryData({
          totalStudents: 25,
          averageScore: 85,
          completionRate: 78
        });
        
        setPerformanceData([
          { month: 'يناير', score: 65 },
          { month: 'فبراير', score: 70 },
          { month: 'مارس', score: 62 },
          { month: 'أبريل', score: 75 },
          { month: 'مايو', score: 80 },
          { month: 'يونيو', score: 85 }
        ]);
        
        setGradesDistribution([
          { name: 'ممتاز', value: 45, color: '#1F4287' },
          { name: 'جيد جداً', value: 28, color: '#009975' },
          { name: 'جيد', value: 20, color: '#30BFBF' },
          { name: 'مقبول', value: 7, color: '#D4AF37' }
        ]);
        
        setBtecCriteria([
          { name: 'P', value: 75 },
          { name: 'M', value: 60 },
          { name: 'D', value: 40 }
        ]);
        
        // بيانات مصفوفة الحرارة للمشاركة
        const days = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
        const hours = ['8ص', '10ص', '12م', '2م', '4م', '6م', '8م'];
        
        const heatmapData = [];
        for (let i = 0; i < days.length; i++) {
          for (let j = 0; j < hours.length; j++) {
            const value = Math.floor(Math.random() * 5); // 0-4 للمشاركة
            heatmapData.push({
              day: days[i],
              hour: hours[j],
              value: value
            });
          }
        }
        
        setEngagementData(heatmapData);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadData();
  }, [selectedPeriod]);

  // تغيير الفترة الزمنية
  const handlePeriodChange = (value) => {
    setSelectedPeriod(value);
    // في التطبيق الحقيقي، سيتم إعادة تحميل البيانات بناءً على الفترة المحددة
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 1000);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* شريط التنقل العلوي */}
      <header className="bg-primary text-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <Link to="/" className="ml-2">
              <Button variant="ghost" size="icon" className="text-white hover:bg-primary-foreground/10">
                <ArrowLeftIcon className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-bold">لوحة التحليلات</h1>
          </div>
          
          <Link to="/">
            <Button variant="ghost" size="icon" className="text-white hover:bg-primary-foreground/10">
              <HomeIcon className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
              <p className="mt-4 text-muted-foreground">جاري تحميل البيانات...</p>
            </div>
          </div>
        ) : (
          <>
            {/* شريط التصفية */}
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-primary">تحليلات الأداء</h2>
              
              <div className="flex items-center">
                <div className="flex items-center ml-4">
                  <CalendarIcon className="h-4 w-4 ml-2 text-muted-foreground" />
                  <Select value={selectedPeriod} onValueChange={handlePeriodChange}>
                    <SelectTrigger className="w-[140px]">
                      <SelectValue placeholder="اختر الفترة" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7">آخر 7 أيام</SelectItem>
                      <SelectItem value="30">آخر 30 يوماً</SelectItem>
                      <SelectItem value="90">آخر 3 أشهر</SelectItem>
                      <SelectItem value="180">آخر 6 أشهر</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Button variant="outline" size="sm" className="flex items-center">
                  <FilterIcon className="h-4 w-4 ml-1" />
                  <span>تصفية</span>
                </Button>
              </div>
            </div>
            
            {/* بطاقات الملخص */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="bg-white rounded-lg shadow-md p-4"
              >
                <h3 className="text-muted-foreground text-sm mb-2">إجمالي الطلاب</h3>
                <p className="text-3xl font-bold text-primary">{summaryData.totalStudents}</p>
                <p className="text-xs text-muted-foreground mt-1">طالب</p>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.1 }}
                className="bg-white rounded-lg shadow-md p-4"
              >
                <h3 className="text-muted-foreground text-sm mb-2">معدل الدرجات</h3>
                <p className="text-3xl font-bold text-primary">{summaryData.averageScore}%</p>
                <p className="text-xs text-green-500 mt-1">+5% من الشهر الماضي</p>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.2 }}
                className="bg-white rounded-lg shadow-md p-4"
              >
                <h3 className="text-muted-foreground text-sm mb-2">نسبة الإكمال</h3>
                <p className="text-3xl font-bold text-primary">{summaryData.completionRate}%</p>
                <p className="text-xs text-green-500 mt-1">+3% من الشهر الماضي</p>
              </motion.div>
            </div>
            
            {/* الرسوم البيانية */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              {/* أداء الطلاب */}
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
                className="bg-white rounded-lg shadow-md p-4"
              >
                <h3 className="text-lg font-bold text-primary mb-4 flex items-center">
                  <LineChartIcon className="h-5 w-5 ml-2" />
                  أداء الطلاب
                </h3>
                
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={performanceData}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis domain={[0, 100]} />
                      <Tooltip />
                      <Line 
                        type="monotone" 
                        dataKey="score" 
                        stroke="#1F4287" 
                        strokeWidth={2}
                        activeDot={{ r: 8 }} 
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </motion.div>
              
              {/* توزيع الدرجات */}
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="bg-white rounded-lg shadow-md p-4"
              >
                <h3 className="text-lg font-bold text-primary mb-4 flex items-center">
                  <PieChartIcon className="h-5 w-5 ml-2" />
                  توزيع الدرجات
                </h3>
                
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={gradesDistribution}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {gradesDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </motion.div>
              
              {/* معايير BTEC */}
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="bg-white rounded-lg shadow-md p-4"
              >
                <h3 className="text-lg font-bold text-primary mb-4 flex items-center">
                  <BarChart3Icon className="h-5 w-5 ml-2" />
                  معايير BTEC
                </h3>
                
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={btecCriteria}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis domain={[0, 100]} />
                      <Tooltip />
                      <Bar dataKey="value" fill="#009975" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </motion.div>
              
              {/* رؤى الذكاء الاصطناعي */}
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="bg-white rounded-lg shadow-md p-4"
              >
                <h3 className="text-lg font-bold text-primary mb-4 flex items-center">
                  <BrainIcon className="h-5 w-5 ml-2" />
                  رؤى الذكاء الاصطناعي
                </h3>
                
                <div className="space-y-4">
                  <div className="bg-muted/20 p-3 rounded-lg">
                    <h4 className="font-medium text-primary mb-1">تحسين الأداء</h4>
                    <p className="text-sm text-muted-foreground">
                      يواجه الطلاب صعوبة في معيار D. يُقترح توفير موارد إضافية وأمثلة توضيحية.
                    </p>
                  </div>
                  
                  <div className="bg-muted/20 p-3 rounded-lg">
                    <h4 className="font-medium text-primary mb-1">أنماط المشاركة</h4>
                    <p className="text-sm text-muted-foreground">
                      أعلى معدلات المشاركة تكون في فترة المساء. يُقترح جدولة الأنشطة التفاعلية في هذه الأوقات.
                    </p>
                  </div>
                  
                  <div className="bg-muted/20 p-3 rounded-lg">
                    <h4 className="font-medium text-primary mb-1">تحسين المحتوى</h4>
                    <p className="text-sm text-muted-foreground">
                      المحتوى المرئي والتفاعلي يحقق نتائج أفضل. يُقترح زيادة استخدام الرسوم البيانية والفيديوهات.
                    </p>
                  </div>
                </div>
              </motion.div>
            </div>
            
            {/* مشاركة الطلاب (مصفوفة الحرارة) */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="bg-white rounded-lg shadow-md p-4 mb-6"
            >
              <h3 className="text-lg font-bold text-primary mb-4">مشاركة الطلاب</h3>
              
              <div className="grid grid-cols-8 gap-1">
                <div className="col-span-1"></div>
                {['8ص', '10ص', '12م', '2م', '4م', '6م', '8م'].map((hour, index) => (
                  <div key={index} className="text-center text-xs text-muted-foreground">
                    {hour}
                  </div>
                ))}
                
                {['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'].map((day, dayIndex) => (
                  <>
                    <div key={`day-${dayIndex}`} className="text-xs text-muted-foreground">
                      {day}
                    </div>
                    {[0, 1, 2, 3, 4, 5, 6].map((hourIndex) => {
                      const value = Math.floor(Math.random() * 5); // 0-4 للمشاركة
                      let bgColor;
                      switch (value) {
                        case 0: bgColor = 'bg-muted/20'; break;
                        case 1: bgColor = 'bg-green-100'; break;
                        case 2: bgColor = 'bg-green-200'; break;
                        case 3: bgColor = 'bg-green-300'; break;
                        case 4: bgColor = 'bg-green-400'; break;
                        default: bgColor = 'bg-muted/20';
                      }
                      return (
                        <div 
                          key={`cell-${dayIndex}-${hourIndex}`} 
                          className={`h-6 ${bgColor} rounded-sm`}
                          title={`${day} ${['8ص', '10ص', '12م', '2م', '4م', '6م', '8م'][hourIndex]}: ${value}`}
                        ></div>
                      );
                    })}
                  </>
                ))}
              </div>
              
              <div className="flex justify-end mt-2">
                <div className="flex items-center text-xs text-muted-foreground">
                  <span className="ml-1">أقل</span>
                  <div className="flex">
                    <div className="h-3 w-3 bg-muted/20"></div>
                    <div className="h-3 w-3 bg-green-100"></div>
                    <div className="h-3 w-3 bg-green-200"></div>
                    <div className="h-3 w-3 bg-green-300"></div>
                    <div className="h-3 w-3 bg-green-400"></div>
                  </div>
                  <span className="mr-1">أكثر</span>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </main>

      <footer className="bg-primary/80 text-white p-4 text-center">
        <p className="text-sm">© 2025 EduverseAI - قلعة BTEC. جميع الحقوق محفوظة.</p>
      </footer>
    </div>
  );
};

export default Analytics;

