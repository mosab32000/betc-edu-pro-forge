"""
إدارة تكامل نموذج Llama 3 المحلي لمنصة EduverseAI - قلعة BTEC
"""
import os
import json
from typing import Dict, List, Any, Optional
from datetime import datetime
import threading
import queue
from dotenv import load_dotenv

# تحميل متغيرات البيئة
load_dotenv()

# استيراد المكتبات اللازمة لنموذج Llama 3
try:
    from llama_cpp import Llama
    LLAMA_AVAILABLE = True
except ImportError:
    LLAMA_AVAILABLE = False
    print("تحذير: لم يتم العثور على مكتبة llama_cpp. سيتم استخدام محاكاة النموذج.")

class LlamaModel:
    """
    فئة إدارة نموذج Llama 3 المحلي
    """
    _instance = None
    _lock = threading.Lock()
    _request_queue = queue.Queue()
    _response_queues = {}
    _worker_thread = None
    
    def __new__(cls):
        """
        تطبيق نمط Singleton لضمان وجود نسخة واحدة فقط من النموذج
        """
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super(LlamaModel, cls).__new__(cls)
                    cls._instance._initialize_model()
                    cls._instance._start_worker()
        return cls._instance
    
    def _initialize_model(self):
        """
        تهيئة نموذج Llama 3 المحلي
        """
        self.model_path = os.getenv("LLAMA_MODEL_PATH", "./models/llama-3-8b-instruct.Q5_K_M.gguf")
        self.model_loaded = False
        self.model = None
        
        # محاولة تحميل النموذج إذا كانت المكتبة متاحة والملف موجود
        if LLAMA_AVAILABLE and os.path.exists(self.model_path):
            try:
                self.model = Llama(
                    model_path=self.model_path,
                    n_ctx=4096,  # حجم سياق النموذج
                    n_gpu_layers=-1,  # استخدام أقصى عدد ممكن من طبقات GPU
                    verbose=False
                )
                self.model_loaded = True
                print(f"تم تحميل نموذج Llama 3 بنجاح من {self.model_path}")
            except Exception as e:
                print(f"فشل تحميل نموذج Llama 3: {str(e)}")
        else:
            print(f"لم يتم العثور على ملف النموذج في {self.model_path}. سيتم استخدام محاكاة النموذج.")
    
    def _start_worker(self):
        """
        بدء مؤشر ترابط العامل لمعالجة الطلبات
        """
        if self._worker_thread is None:
            self._worker_thread = threading.Thread(target=self._process_requests, daemon=True)
            self._worker_thread.start()
    
    def _process_requests(self):
        """
        معالجة طلبات النموذج في مؤشر ترابط منفصل
        """
        while True:
            request_id, prompt, params = self._request_queue.get()
            try:
                response = self._generate_response(prompt, params)
                self._response_queues[request_id].put((True, response))
            except Exception as e:
                self._response_queues[request_id].put((False, str(e)))
            finally:
                self._request_queue.task_done()
    
    def _generate_response(self, prompt: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        توليد استجابة من نموذج Llama 3
        
        المعلمات:
            prompt (str): النص المدخل للنموذج
            params (Dict[str, Any]): معلمات التوليد
            
        العائد:
            Dict[str, Any]: الاستجابة المولدة
        """
        start_time = datetime.now()
        
        if self.model_loaded and self.model:
            # استخدام النموذج الفعلي إذا كان متاحاً
            max_tokens = params.get("max_tokens", 512)
            temperature = params.get("temperature", 0.7)
            top_p = params.get("top_p", 0.9)
            
            response = self.model(
                prompt,
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=top_p,
                echo=False
            )
            
            generated_text = response["choices"][0]["text"]
            
        else:
            # محاكاة استجابة النموذج للاختبار
            import time
            import random
            
            # تأخير عشوائي لمحاكاة وقت المعالجة
            time.sleep(random.uniform(0.5, 2.0))
            
            # محاكاة استجابة بناءً على نوع الطلب
            if "تقييم" in prompt or "assessment" in prompt.lower():
                generated_text = self._simulate_assessment_feedback()
            elif "مساعدة" in prompt or "help" in prompt.lower():
                generated_text = self._simulate_help_response(prompt)
            else:
                generated_text = self._simulate_general_response(prompt)
        
        end_time = datetime.now()
        processing_time = (end_time - start_time).total_seconds()
        
        return {
            "generated_text": generated_text,
            "processing_time": processing_time,
            "timestamp": datetime.now().isoformat(),
            "model": "Llama 3 (8B)" if self.model_loaded else "Llama 3 Simulation"
        }
    
    def _simulate_assessment_feedback(self) -> str:
        """
        محاكاة تغذية راجعة للتقييم
        """
        return """
        # تحليل الإجابة
        
        ## نقاط القوة
        - تحليل شامل للعوامل الداخلية والخارجية للشركة
        - استخدام أمثلة واقعية لدعم التحليل
        - تنظيم جيد للمحتوى وتسلسل منطقي للأفكار
        
        ## مجالات التحسين
        - يمكن تعميق تحليل التهديدات المحتملة
        - إضافة المزيد من الأرقام والإحصاءات لدعم التحليل
        - توسيع قسم التوصيات مع خطوات عملية أكثر تحديداً
        
        ## توصيات للتحسين
        1. قم بإضافة دراسة حالة مقارنة مع شركة منافسة
        2. عزز تحليل الفرص بأمثلة من السوق المحلي
        3. قدم جدولاً زمنياً مقترحاً لتنفيذ التوصيات
        
        الدرجة المقترحة: 85/100
        """
    
    def _simulate_help_response(self, prompt: str) -> str:
        """
        محاكاة استجابة مساعدة
        """
        return f"""
        أهلاً بك في المساعد الذكي لمنصة EduverseAI - قلعة BTEC!
        
        بخصوص استفسارك حول "{prompt.strip()}"، إليك بعض المعلومات المفيدة:
        
        يمكنك البدء بمراجعة المصادر التالية:
        1. دليل المستخدم في قسم "الموارد التعليمية"
        2. الفيديوهات التوضيحية في مكتبة الوسائط
        3. الأسئلة الشائعة في صفحة الدعم
        
        إذا كنت تواجه صعوبة محددة، يرجى توضيح المشكلة بشكل أكثر تفصيلاً وسأقدم لك مساعدة مخصصة.
        
        هل هناك شيء آخر يمكنني مساعدتك به؟
        """
    
    def _simulate_general_response(self, prompt: str) -> str:
        """
        محاكاة استجابة عامة
        """
        return f"""
        شكراً لتواصلك مع المساعد الذكي لمنصة EduverseAI - قلعة BTEC.
        
        استناداً إلى طلبك: "{prompt.strip()}"
        
        أقترح عليك استكشاف الموضوعات التالية في المنصة:
        - مقدمة في تحليل الأعمال
        - أساسيات التخطيط الاستراتيجي
        - تقنيات التحليل المالي
        
        يمكنك أيضاً الاستفادة من تجارب التعلم الغامرة المتاحة في قسم "تجارب XR" والتي تقدم محاكاة تفاعلية للمفاهيم النظرية.
        
        هل ترغب في معرفة المزيد عن أي من هذه الموضوعات؟
        """
    
    def generate_async(self, prompt: str, params: Dict[str, Any] = None) -> str:
        """
        توليد استجابة بشكل غير متزامن
        
        المعلمات:
            prompt (str): النص المدخل للنموذج
            params (Dict[str, Any]): معلمات التوليد
            
        العائد:
            str: معرف الطلب
        """
        if params is None:
            params = {}
        
        request_id = f"req_{datetime.now().timestamp()}"
        self._response_queues[request_id] = queue.Queue()
        self._request_queue.put((request_id, prompt, params))
        
        return request_id
    
    def get_response(self, request_id: str, timeout: int = 30) -> Dict[str, Any]:
        """
        الحصول على استجابة لطلب غير متزامن
        
        المعلمات:
            request_id (str): معرف الطلب
            timeout (int): مهلة الانتظار بالثواني
            
        العائد:
            Dict[str, Any]: الاستجابة المولدة
        """
        if request_id not in self._response_queues:
            raise ValueError(f"معرف الطلب غير صالح: {request_id}")
        
        try:
            success, result = self._response_queues[request_id].get(timeout=timeout)
            del self._response_queues[request_id]
            
            if success:
                return result
            else:
                raise RuntimeError(f"فشل توليد الاستجابة: {result}")
        except queue.Empty:
            raise TimeoutError(f"انتهت مهلة انتظار الاستجابة للطلب: {request_id}")
    
    def generate(self, prompt: str, params: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        توليد استجابة بشكل متزامن
        
        المعلمات:
            prompt (str): النص المدخل للنموذج
            params (Dict[str, Any]): معلمات التوليد
            
        العائد:
            Dict[str, Any]: الاستجابة المولدة
        """
        if params is None:
            params = {}
        
        request_id = self.generate_async(prompt, params)
        return self.get_response(request_id)
    
    def assess_answer(self, answer: str, task_description: str, criteria: List[str] = None) -> Dict[str, Any]:
        """
        تقييم إجابة الطالب
        
        المعلمات:
            answer (str): إجابة الطالب
            task_description (str): وصف المهمة
            criteria (List[str]): معايير التقييم
            
        العائد:
            Dict[str, Any]: نتائج التقييم
        """
        if criteria is None:
            criteria = ["دقة المحتوى", "التنظيم", "الأسلوب", "الإبداع"]
        
        criteria_str = "\n".join([f"- {c}" for c in criteria])
        
        prompt = f"""
        # مهمة التقييم
        
        ## وصف المهمة:
        {task_description}
        
        ## معايير التقييم:
        {criteria_str}
        
        ## إجابة الطالب:
        {answer}
        
        # المطلوب:
        قم بتقييم إجابة الطالب بناءً على المعايير المذكورة. قدم تحليلاً مفصلاً يتضمن:
        1. نقاط القوة في الإجابة
        2. مجالات التحسين
        3. توصيات محددة للتحسين
        4. درجة مقترحة من 100
        5. درجة لكل معيار من معايير التقييم من 10
        
        قدم تقييمك بتنسيق JSON.
        """
        
        params = {
            "max_tokens": 1024,
            "temperature": 0.3,
            "top_p": 0.9
        }
        
        response = self.generate(prompt, params)
        
        # محاولة استخراج JSON من الاستجابة
        try:
            # البحث عن بداية ونهاية JSON في النص
            generated_text = response["generated_text"]
            json_start = generated_text.find("{")
            json_end = generated_text.rfind("}") + 1
            
            if json_start >= 0 and json_end > json_start:
                json_str = generated_text[json_start:json_end]
                assessment_data = json.loads(json_str)
            else:
                # إذا لم يتم العثور على JSON، إنشاء هيكل بديل
                assessment_data = self._parse_assessment_text(generated_text, criteria)
            
            # إضافة البيانات الأصلية من الاستجابة
            assessment_data["processing_time"] = response["processing_time"]
            assessment_data["timestamp"] = response["timestamp"]
            assessment_data["model"] = response["model"]
            
            return assessment_data
            
        except json.JSONDecodeError:
            # إذا فشل تحليل JSON، إنشاء هيكل بديل
            assessment_data = self._parse_assessment_text(response["generated_text"], criteria)
            
            # إضافة البيانات الأصلية من الاستجابة
            assessment_data["processing_time"] = response["processing_time"]
            assessment_data["timestamp"] = response["timestamp"]
            assessment_data["model"] = response["model"]
            
            return assessment_data
    
    def _parse_assessment_text(self, text: str, criteria: List[str]) -> Dict[str, Any]:
        """
        تحليل نص التقييم وتحويله إلى هيكل بيانات
        
        المعلمات:
            text (str): نص التقييم
            criteria (List[str]): معايير التقييم
            
        العائد:
            Dict[str, Any]: هيكل بيانات التقييم
        """
        # استخراج الأقسام الرئيسية من النص
        strengths = []
        improvements = []
        recommendations = []
        overall_score = 0
        criteria_scores = {}
        
        # البحث عن نقاط القوة
        if "نقاط القوة" in text:
            strengths_section = text.split("نقاط القوة")[1].split("مجالات التحسين")[0]
            strengths = [s.strip() for s in strengths_section.split("-") if s.strip()]
        
        # البحث عن مجالات التحسين
        if "مجالات التحسين" in text:
            improvements_section = text.split("مجالات التحسين")[1].split("توصيات")[0]
            improvements = [s.strip() for s in improvements_section.split("-") if s.strip()]
        
        # البحث عن التوصيات
        if "توصيات" in text:
            recommendations_section = text.split("توصيات")[1].split("الدرجة")[0]
            recommendations = [s.strip() for s in recommendations_section.split("\n") if s.strip() and s[0].isdigit()]
        
        # البحث عن الدرجة
        import re
        score_match = re.search(r"الدرجة[^0-9]*([0-9]+)[^0-9]*100", text)
        if score_match:
            overall_score = int(score_match.group(1))
        
        # تعيين درجات افتراضية للمعايير
        for criterion in criteria:
            criteria_scores[criterion] = 7 + (overall_score % 30) // 10
        
        return {
            "strengths": strengths,
            "improvements": improvements,
            "recommendations": recommendations,
            "overall_score": overall_score,
            "criteria_scores": criteria_scores
        }
    
    def generate_ai_help(self, query: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        توليد مساعدة ذكية للمستخدم
        
        المعلمات:
            query (str): استفسار المستخدم
            context (Dict[str, Any]): سياق المستخدم والمهمة
            
        العائد:
            Dict[str, Any]: المساعدة المولدة
        """
        if context is None:
            context = {}
        
        # استخراج معلومات السياق
        user_info = context.get("user_info", {})
        task_info = context.get("task_info", {})
        
        # بناء سياق المستخدم
        user_context = ""
        if user_info:
            user_context = f"""
            معلومات المستخدم:
            - الاسم: {user_info.get('first_name', '')} {user_info.get('last_name', '')}
            - المستوى: {user_info.get('level', 1)}
            - عدد المهام المكتملة: {len(user_info.get('completed_tasks', []))}
            """
        
        # بناء سياق المهمة
        task_context = ""
        if task_info:
            task_context = f"""
            معلومات المهمة الحالية:
            - العنوان: {task_info.get('title', '')}
            - الوصف: {task_info.get('description', '')}
            - المادة: {task_info.get('subject', '')}
            - تاريخ الاستحقاق: {task_info.get('due_date', '')}
            """
        
        prompt = f"""
        # طلب المساعدة
        
        ## استفسار المستخدم:
        {query}
        
        {user_context}
        
        {task_context}
        
        # المطلوب:
        قدم مساعدة مفيدة ومخصصة للمستخدم بناءً على استفساره والسياق المتاح. يجب أن تكون المساعدة:
        1. واضحة ومباشرة
        2. مرتبطة بالسياق
        3. تقدم إرشادات عملية
        4. تشجع على التفكير النقدي
        
        قدم إجابتك بتنسيق مناسب مع عناوين وفقرات منظمة.
        """
        
        params = {
            "max_tokens": 512,
            "temperature": 0.7,
            "top_p": 0.9
        }
        
        response = self.generate(prompt, params)
        
        return {
            "query": query,
            "response": response["generated_text"],
            "processing_time": response["processing_time"],
            "timestamp": response["timestamp"],
            "model": response["model"]
        }


# إنشاء كائن نموذج Llama للاستخدام في جميع أنحاء التطبيق
llama_model = LlamaModel()

# تصدير كائن النموذج
__all__ = ['llama_model']

