/**
 * خدمات API لمنصة EduverseAI - قلعة BTEC
 */

// عنوان API الأساسي
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

/**
 * الدالة الأساسية لإرسال طلبات API
 * @param {string} endpoint - نقطة النهاية للطلب
 * @param {string} method - طريقة الطلب (GET, POST, PUT, DELETE)
 * @param {object} data - البيانات المرسلة مع الطلب
 * @param {boolean} withAuth - هل يتطلب الطلب مصادقة
 * @returns {Promise} - وعد بنتيجة الطلب
 */
const apiRequest = async (endpoint, method = 'GET', data = null, withAuth = true) => {
  const url = `${API_BASE_URL}${endpoint}`;
  
  const headers = {
    'Content-Type': 'application/json',
  };
  
  // إضافة رمز المصادقة إذا كان مطلوباً
  if (withAuth) {
    const token = localStorage.getItem('token');
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    } else {
      // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن لديه رمز مصادقة
      window.location.href = '/login';
      return;
    }
  }
  
  const options = {
    method,
    headers,
    body: data ? JSON.stringify(data) : null,
  };
  
  try {
    const response = await fetch(url, options);
    
    // التحقق من حالة الاستجابة
    if (response.status === 401) {
      // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا كانت المصادقة غير صالحة
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
      return;
    }
    
    const result = await response.json();
    
    if (!response.ok) {
      throw new Error(result.message || 'حدث خطأ أثناء الاتصال بالخادم');
    }
    
    return result;
  } catch (error) {
    console.error('خطأ في طلب API:', error);
    throw error;
  }
};

/**
 * خدمات المستخدمين
 */
export const authService = {
  // تسجيل الدخول
  login: (credentials) => apiRequest('/users/login', 'POST', credentials, false),
  
  // تسجيل مستخدم جديد
  register: (userData) => apiRequest('/users/register', 'POST', userData, false),
  
  // الحصول على معلومات المستخدم الحالي
  getCurrentUser: () => apiRequest('/users/profile'),
  
  // تحديث معلومات المستخدم
  updateProfile: (userData) => apiRequest('/users/profile', 'PUT', userData),
  
  // تسجيل الخروج
  logout: () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/login';
  }
};

/**
 * خدمات المهام التعليمية
 */
export const tasksService = {
  // الحصول على قائمة المهام
  getTasks: (filters = {}) => apiRequest('/tasks', 'GET', filters),
  
  // الحصول على مهمة محددة
  getTask: (taskId) => apiRequest(`/tasks/${taskId}`),
  
  // إنشاء مهمة جديدة
  createTask: (taskData) => apiRequest('/tasks', 'POST', taskData),
  
  // تحديث مهمة
  updateTask: (taskId, taskData) => apiRequest(`/tasks/${taskId}`, 'PUT', taskData),
  
  // حذف مهمة
  deleteTask: (taskId) => apiRequest(`/tasks/${taskId}`, 'DELETE')
};

/**
 * خدمات التقييمات
 */
export const assessmentsService = {
  // تقديم إجابة لمهمة
  submitAnswer: (taskId, answerData) => apiRequest('/assessments', 'POST', { task_id: taskId, ...answerData }),
  
  // الحصول على تقييم محدد
  getAssessment: (assessmentId) => apiRequest(`/assessments/${assessmentId}`),
  
  // تقييم إجابة الطالب
  evaluateAnswer: (assessmentId, evaluationData) => apiRequest(`/assessments/${assessmentId}/evaluate`, 'POST', evaluationData),
  
  // الحصول على التغذية الراجعة من الذكاء الاصطناعي
  getAIFeedback: (assessmentId) => apiRequest(`/assessments/${assessmentId}/ai-feedback`),
  
  // الحصول على تقييمات المستخدم
  getUserAssessments: () => apiRequest('/assessments/user')
};

/**
 * خدمات الأوسمة
 */
export const badgesService = {
  // الحصول على قائمة الأوسمة
  getBadges: () => apiRequest('/badges'),
  
  // الحصول على وسام محدد
  getBadge: (badgeId) => apiRequest(`/badges/${badgeId}`),
  
  // الحصول على أوسمة المستخدم
  getUserBadges: () => apiRequest('/badges/user')
};

/**
 * خدمات تجارب التعلم الغامرة (XR)
 */
export const xrService = {
  // الحصول على قائمة تجارب التعلم الغامرة
  getXRExperiences: () => apiRequest('/xr-experiences'),
  
  // الحصول على تجربة تعلم غامرة محددة
  getXRExperience: (experienceId) => apiRequest(`/xr-experiences/${experienceId}`),
  
  // بدء تجربة تعلم غامرة
  startXRExperience: (experienceId) => apiRequest('/user-xr-experiences', 'POST', { experience_id: experienceId }),
  
  // تحديث تقدم تجربة تعلم غامرة
  updateXRProgress: (experienceId, progress) => apiRequest(`/user-xr-experiences/${experienceId}`, 'PUT', { progress })
};

/**
 * خدمات الذكاء الاصطناعي
 */
export const aiService = {
  // محادثة مع المساعد الذكي
  chat: (message, conversationHistory = []) => apiRequest('/ai/chat', 'POST', { message, conversation_history: conversationHistory }),
  
  // تحليل إجابة الطالب
  analyzeAnswer: (answer, taskDescription, criteria = []) => apiRequest('/ai/analyze-answer', 'POST', { answer, task_description: taskDescription, criteria }),
  
  // توليد تغذية راجعة للطالب
  generateFeedback: (answer, taskDescription, score, criteria = []) => apiRequest('/ai/generate-feedback', 'POST', { answer, task_description: taskDescription, score, criteria }),
  
  // توليد أسئلة حول موضوع معين
  generateQuestions: (subject, topic, difficulty = 'medium', count = 5) => apiRequest('/ai/generate-questions', 'POST', { subject, topic, difficulty, count }),
  
  // تلخيص محتوى
  summarizeContent: (content, maxLength = 200) => apiRequest('/ai/summarize-content', 'POST', { content, max_length: maxLength }),
  
  // شرح مفهوم
  explainConcept: (concept, subject, level = 'intermediate') => apiRequest('/ai/explain-concept', 'POST', { concept, subject, level }),
  
  // توليد مسار تعلم مخصص
  generateLearningPath: (subject, goal, userLevel = 'intermediate') => apiRequest('/ai/generate-learning-path', 'POST', { subject, goal, user_level: userLevel })
};

/**
 * خدمات البلوكتشين
 */
export const blockchainService = {
  // التحقق من صحة البيانات باستخدام البلوكتشين
  verifyData: (data, blockHash) => apiRequest('/blockchain/verify', 'POST', { data, block_hash: blockHash }),
  
  // الحصول على شهادة محددة
  getCertificate: (certificateId) => apiRequest(`/blockchain/certificates/${certificateId}`),
  
  // الحصول على شهادات المستخدم
  getUserCertificates: () => apiRequest('/blockchain/certificates/user'),
  
  // التحقق من صحة شهادة
  verifyCertificate: (certificateId) => apiRequest(`/blockchain/certificates/${certificateId}/verify`),
  
  // الحصول على حالة البلوكتشين
  getBlockchainStatus: () => apiRequest('/blockchain/status')
};

export default {
  authService,
  tasksService,
  assessmentsService,
  badgesService,
  xrService,
  aiService,
  blockchainService
};

