"""
مسارات API للذكاء الاصطناعي في منصة EduverseAI - قلعة BTEC
"""

from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
from ..ai.llama_service import get_llama_service
import logging

# إعداد التسجيل
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# إنشاء Blueprint للذكاء الاصطناعي
ai_bp = Blueprint('ai', __name__, url_prefix='/api/ai')

@ai_bp.route('/chat', methods=['POST'])
@cross_origin()
def chat():
    """
    واجهة برمجية للدردشة مع المساعد الذكي
    
    المدخلات:
        - message: رسالة المستخدم
        - conversation_id: معرف المحادثة (اختياري)
        - max_tokens: الحد الأقصى لعدد الرموز في الاستجابة (اختياري)
        - temperature: درجة الحرارة للتوليد (اختياري)
    
    المخرجات:
        - response: استجابة المساعد الذكي
        - conversation_id: معرف المحادثة
    """
    try:
        data = request.get_json()
        
        if not data or 'message' not in data:
            return jsonify({
                'error': 'يجب توفير رسالة المستخدم'
            }), 400
        
        message = data['message']
        conversation_id = data.get('conversation_id', None)
        max_tokens = data.get('max_tokens', 512)
        temperature = data.get('temperature', 0.7)
        
        # الحصول على خدمة Llama
        llama_service = get_llama_service()
        
        # توليد الاستجابة
        response = llama_service.generate_response(
            prompt=message,
            max_tokens=max_tokens,
            temperature=temperature
        )
        
        # إنشاء معرف محادثة جديد إذا لم يتم توفيره
        if conversation_id is None:
            import uuid
            conversation_id = str(uuid.uuid4())
        
        return jsonify({
            'response': response,
            'conversation_id': conversation_id
        })
    except Exception as e:
        logger.error(f"حدث خطأ أثناء معالجة طلب الدردشة: {e}")
        return jsonify({
            'error': 'حدث خطأ أثناء معالجة طلبك',
            'details': str(e)
        }), 500

@ai_bp.route('/feedback', methods=['POST'])
@cross_origin()
def provide_feedback():
    """
    واجهة برمجية لتقديم تغذية راجعة ذكية على إجابة الطالب
    
    المدخلات:
        - student_answer: إجابة الطالب
        - correct_answer: الإجابة الصحيحة أو النموذجية
        - criteria: معايير التقييم
    
    المخرجات:
        - feedback: التغذية الراجعة
    """
    try:
        data = request.get_json()
        
        if not data or 'student_answer' not in data or 'correct_answer' not in data or 'criteria' not in data:
            return jsonify({
                'error': 'يجب توفير إجابة الطالب والإجابة الصحيحة ومعايير التقييم'
            }), 400
        
        student_answer = data['student_answer']
        correct_answer = data['correct_answer']
        criteria = data['criteria']
        
        # الحصول على خدمة Llama
        llama_service = get_llama_service()
        
        # تقديم التغذية الراجعة
        feedback = llama_service.provide_feedback(
            student_answer=student_answer,
            correct_answer=correct_answer,
            criteria=criteria
        )
        
        return jsonify(feedback)
    except Exception as e:
        logger.error(f"حدث خطأ أثناء معالجة طلب التغذية الراجعة: {e}")
        return jsonify({
            'error': 'حدث خطأ أثناء معالجة طلبك',
            'details': str(e)
        }), 500

@ai_bp.route('/generate-content', methods=['POST'])
@cross_origin()
def generate_content():
    """
    واجهة برمجية لتوليد محتوى تعليمي
    
    المدخلات:
        - topic: موضوع المحتوى
        - content_type: نوع المحتوى
        - difficulty_level: مستوى الصعوبة
        - language: لغة المحتوى (اختياري)
    
    المخرجات:
        - content: المحتوى التعليمي المولد
    """
    try:
        data = request.get_json()
        
        if not data or 'topic' not in data or 'content_type' not in data or 'difficulty_level' not in data:
            return jsonify({
                'error': 'يجب توفير موضوع المحتوى ونوعه ومستوى الصعوبة'
            }), 400
        
        topic = data['topic']
        content_type = data['content_type']
        difficulty_level = data['difficulty_level']
        language = data.get('language', 'ar')
        
        # الحصول على خدمة Llama
        llama_service = get_llama_service()
        
        # توليد المحتوى التعليمي
        content = llama_service.generate_educational_content(
            topic=topic,
            content_type=content_type,
            difficulty_level=difficulty_level,
            language=language
        )
        
        return jsonify({
            'content': content
        })
    except Exception as e:
        logger.error(f"حدث خطأ أثناء معالجة طلب توليد المحتوى: {e}")
        return jsonify({
            'error': 'حدث خطأ أثناء معالجة طلبك',
            'details': str(e)
        }), 500

@ai_bp.route('/analyze-performance', methods=['POST'])
@cross_origin()
def analyze_performance():
    """
    واجهة برمجية لتحليل أداء الطالب
    
    المدخلات:
        - performance_data: بيانات أداء الطالب
    
    المخرجات:
        - analysis: تحليل الأداء والتوصيات
    """
    try:
        data = request.get_json()
        
        if not data or 'performance_data' not in data:
            return jsonify({
                'error': 'يجب توفير بيانات أداء الطالب'
            }), 400
        
        performance_data = data['performance_data']
        
        # الحصول على خدمة Llama
        llama_service = get_llama_service()
        
        # تحليل أداء الطالب
        analysis = llama_service.analyze_student_performance(
            performance_data=performance_data
        )
        
        return jsonify(analysis)
    except Exception as e:
        logger.error(f"حدث خطأ أثناء معالجة طلب تحليل الأداء: {e}")
        return jsonify({
            'error': 'حدث خطأ أثناء معالجة طلبك',
            'details': str(e)
        }), 500

