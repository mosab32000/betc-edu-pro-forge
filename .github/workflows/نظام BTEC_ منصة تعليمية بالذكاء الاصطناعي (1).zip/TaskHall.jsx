import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  HomeIcon,
  ArrowLeftIcon,
  CheckCircleIcon,
  ClockIcon,
  AlertCircleIcon,
  ChevronLeftIcon,
  FilterIcon,
  SearchIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';

const TaskHall = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [tasks, setTasks] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('all');

  useEffect(() => {
    // محاكاة تحميل البيانات
    const loadData = async () => {
      setIsLoading(true);
      try {
        // محاكاة تأخير الشبكة
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // بيانات وهمية للعرض
        setTasks([
          {
            id: 1,
            title: 'تقرير عن تأثير التكنولوجيا على الأعمال',
            description: 'اكتب تقريراً يتناول كيفية تأثير التكنولوجيا الحديثة على قطاع الأعمال',
            dueDate: '2025-06-15',
            status: 'completed',
            score: 85,
            subject: 'إدارة الأعمال',
            priority: 'high'
          },
          {
            id: 2,
            title: 'تحليل SWOT لشركة ناشئة',
            description: 'قم بإجراء تحليل SWOT لشركة ناشئة في مجال التكنولوجيا',
            dueDate: '2025-06-20',
            status: 'in_progress',
            progress: 60,
            subject: 'إدارة الأعمال',
            priority: 'medium'
          },
          {
            id: 3,
            title: 'تصميم خطة تسويقية',
            description: 'قم بتصميم خطة تسويقية لمنتج جديد في السوق',
            dueDate: '2025-06-25',
            status: 'pending',
            subject: 'التسويق',
            priority: 'high'
          },
          {
            id: 4,
            title: 'تحليل البيانات المالية',
            description: 'قم بتحليل البيانات المالية لشركة وتقديم توصيات لتحسين الأداء',
            dueDate: '2025-07-05',
            status: 'pending',
            subject: 'المالية',
            priority: 'low'
          },
          {
            id: 5,
            title: 'دراسة حالة: شركة أمازون',
            description: 'قم بإعداد دراسة حالة تحليلية لشركة أمازون وعوامل نجاحها',
            dueDate: '2025-06-18',
            status: 'in_progress',
            progress: 25,
            subject: 'إدارة الأعمال',
            priority: 'medium'
          }
        ]);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadData();
  }, []);

  // تصفية المهام حسب الحالة
  const filteredTasks = tasks.filter(task => {
    if (activeTab === 'all') return true;
    if (activeTab === 'pending') return task.status === 'pending';
    if (activeTab === 'in_progress') return task.status === 'in_progress';
    if (activeTab === 'completed') return task.status === 'completed';
    return true;
  }).filter(task => 
    task.title.includes(searchQuery) || 
    task.description.includes(searchQuery) ||
    task.subject.includes(searchQuery)
  );

  // تأثيرات الحركة للبطاقات
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100
      }
    }
  };

  // تحويل التاريخ إلى تنسيق عربي
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return date.toLocaleDateString('ar-JO', options);
  };

  // حساب الأيام المتبقية
  const getDaysRemaining = (dateString) => {
    const dueDate = new Date(dateString);
    const today = new Date();
    const diffTime = dueDate - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* شريط التنقل العلوي */}
      <header className="bg-primary text-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <Link to="/" className="ml-2">
              <Button variant="ghost" size="icon" className="text-white hover:bg-primary-foreground/10">
                <ArrowLeftIcon className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-bold">قاعة المهام</h1>
          </div>
          
          <Link to="/">
            <Button variant="ghost" size="icon" className="text-white hover:bg-primary-foreground/10">
              <HomeIcon className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
              <p className="mt-4 text-muted-foreground">جاري تحميل المهام...</p>
            </div>
          </div>
        ) : (
          <>
            {/* شريط البحث والتصفية */}
            <div className="flex items-center mb-6">
              <div className="relative flex-1">
                <SearchIcon className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="ابحث عن المهام..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-3 pr-10 text-right"
                />
              </div>
              <Button variant="outline" size="icon" className="mr-2">
                <FilterIcon className="h-4 w-4" />
              </Button>
            </div>
            
            {/* علامات التبويب للتصفية */}
            <Tabs defaultValue="all" className="mb-6" onValueChange={setActiveTab}>
              <TabsList className="bg-muted w-full justify-start">
                <TabsTrigger value="all">الكل</TabsTrigger>
                <TabsTrigger value="pending">قيد الانتظار</TabsTrigger>
                <TabsTrigger value="in_progress">قيد التنفيذ</TabsTrigger>
                <TabsTrigger value="completed">مكتملة</TabsTrigger>
              </TabsList>
              
              <TabsContent value="all" className="mt-4">
                <TaskList tasks={filteredTasks} />
              </TabsContent>
              
              <TabsContent value="pending" className="mt-4">
                <TaskList tasks={filteredTasks} />
              </TabsContent>
              
              <TabsContent value="in_progress" className="mt-4">
                <TaskList tasks={filteredTasks} />
              </TabsContent>
              
              <TabsContent value="completed" className="mt-4">
                <TaskList tasks={filteredTasks} />
              </TabsContent>
            </Tabs>
          </>
        )}
      </main>

      <footer className="bg-primary/80 text-white p-4 text-center">
        <p className="text-sm">© 2025 EduverseAI - قلعة BTEC. جميع الحقوق محفوظة.</p>
      </footer>
    </div>
  );
  
  // مكون قائمة المهام
  function TaskList({ tasks }) {
    if (tasks.length === 0) {
      return (
        <div className="text-center py-8">
          <p className="text-muted-foreground">لا توجد مهام متاحة</p>
        </div>
      );
    }
    
    return (
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="space-y-4"
      >
        {tasks.map((task) => (
          <TaskCard key={task.id} task={task} />
        ))}
      </motion.div>
    );
  }
  
  // مكون بطاقة المهمة
  function TaskCard({ task }) {
    const daysRemaining = getDaysRemaining(task.dueDate);
    
    // تحديد لون وأيقونة الحالة
    let statusColor, statusIcon, statusText;
    switch (task.status) {
      case 'completed':
        statusColor = 'bg-green-100 text-green-800';
        statusIcon = <CheckCircleIcon className="h-4 w-4 ml-1" />;
        statusText = 'مكتملة';
        break;
      case 'in_progress':
        statusColor = 'bg-blue-100 text-blue-800';
        statusIcon = <ClockIcon className="h-4 w-4 ml-1" />;
        statusText = 'قيد التنفيذ';
        break;
      default:
        statusColor = 'bg-amber-100 text-amber-800';
        statusIcon = <AlertCircleIcon className="h-4 w-4 ml-1" />;
        statusText = 'قيد الانتظار';
    }
    
    // تحديد لون الأولوية
    let priorityColor;
    switch (task.priority) {
      case 'high':
        priorityColor = 'bg-red-100 text-red-800';
        break;
      case 'medium':
        priorityColor = 'bg-amber-100 text-amber-800';
        break;
      default:
        priorityColor = 'bg-green-100 text-green-800';
    }
    
    return (
      <motion.div
        variants={itemVariants}
        whileHover={{ scale: 1.01 }}
        className="bg-white rounded-lg shadow-md overflow-hidden transition-all hover:shadow-lg"
      >
        <div className="p-4">
          <div className="flex justify-between items-start mb-2">
            <h3 className="text-lg font-bold text-primary">{task.title}</h3>
            <div className="flex">
              <span className={`${priorityColor} text-xs px-2 py-1 rounded-full ml-2`}>
                {task.priority === 'high' ? 'عالية' : task.priority === 'medium' ? 'متوسطة' : 'منخفضة'}
              </span>
              <span className={`${statusColor} text-xs px-2 py-1 rounded-full flex items-center`}>
                {statusIcon}
                {statusText}
              </span>
            </div>
          </div>
          
          <p className="text-muted-foreground mb-3">{task.description}</p>
          
          {task.status === 'in_progress' && (
            <div className="mb-3">
              <div className="flex justify-between text-xs text-muted-foreground mb-1">
                <span>التقدم</span>
                <span>{task.progress}%</span>
              </div>
              <Progress value={task.progress} className="h-1.5" />
            </div>
          )}
          
          <div className="flex justify-between items-center">
            <div>
              <span className="text-xs text-muted-foreground">المادة: {task.subject}</span>
            </div>
            
            <div className="flex items-center">
              <div className="text-xs text-muted-foreground ml-4">
                <span>تاريخ التسليم: {formatDate(task.dueDate)}</span>
                {task.status !== 'completed' && daysRemaining > 0 && (
                  <span className="mr-2 text-amber-600">
                    (متبقي {daysRemaining} {daysRemaining === 1 ? 'يوم' : 'أيام'})
                  </span>
                )}
                {task.status !== 'completed' && daysRemaining <= 0 && (
                  <span className="mr-2 text-red-600">
                    (متأخرة)
                  </span>
                )}
              </div>
              
              <Link to={task.status === 'completed' ? '/feedback' : '/assessment'}>
                <Button 
                  variant={task.status === 'completed' ? 'outline' : 'default'} 
                  size="sm"
                  className="flex items-center"
                >
                  {task.status === 'completed' ? 'عرض التقييم' : 'بدء المهمة'}
                  <ChevronLeftIcon className="h-4 w-4 mr-1" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </motion.div>
    );
  }
};

export default TaskHall;

