import { createContext, useContext, useState, useEffect } from 'react';
import { authService } from '../services/api';

// إنشاء سياق المصادقة
const AuthContext = createContext();

/**
 * مزود سياق المصادقة
 * @param {object} props - خصائص المكون
 * @returns {JSX.Element} - مكون مزود سياق المصادقة
 */
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // التحقق من حالة المصادقة عند تحميل التطبيق
  useEffect(() => {
    const checkAuthStatus = async () => {
      try {
        const token = localStorage.getItem('token');
        
        if (!token) {
          setLoading(false);
          return;
        }
        
        // محاولة الحصول على معلومات المستخدم الحالي
        const userData = await authService.getCurrentUser();
        setUser(userData.user);
      } catch (err) {
        console.error('خطأ في التحقق من حالة المصادقة:', err);
        localStorage.removeItem('token');
        localStorage.removeItem('user');
      } finally {
        setLoading(false);
      }
    };
    
    checkAuthStatus();
  }, []);
  
  /**
   * تسجيل الدخول
   * @param {string} username - اسم المستخدم
   * @param {string} password - كلمة المرور
   * @returns {Promise} - وعد بنتيجة تسجيل الدخول
   */
  const login = async (username, password) => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await authService.login({ username, password });
      
      // حفظ رمز المصادقة ومعلومات المستخدم
      localStorage.setItem('token', response.token);
      localStorage.setItem('user', JSON.stringify(response.user));
      
      setUser(response.user);
      return response;
    } catch (err) {
      setError(err.message || 'فشل تسجيل الدخول');
      throw err;
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * تسجيل مستخدم جديد
   * @param {object} userData - بيانات المستخدم الجديد
   * @returns {Promise} - وعد بنتيجة التسجيل
   */
  const register = async (userData) => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await authService.register(userData);
      
      // حفظ رمز المصادقة ومعلومات المستخدم
      localStorage.setItem('token', response.token);
      localStorage.setItem('user', JSON.stringify(response.user));
      
      setUser(response.user);
      return response;
    } catch (err) {
      setError(err.message || 'فشل تسجيل المستخدم');
      throw err;
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * تحديث معلومات المستخدم
   * @param {object} userData - بيانات المستخدم المحدثة
   * @returns {Promise} - وعد بنتيجة التحديث
   */
  const updateProfile = async (userData) => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await authService.updateProfile(userData);
      
      // تحديث معلومات المستخدم المخزنة
      localStorage.setItem('user', JSON.stringify(response.user));
      
      setUser(response.user);
      return response;
    } catch (err) {
      setError(err.message || 'فشل تحديث الملف الشخصي');
      throw err;
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * تسجيل الخروج
   */
  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
  };
  
  // القيمة التي سيتم توفيرها للمكونات
  const value = {
    user,
    loading,
    error,
    login,
    register,
    updateProfile,
    logout,
    isAuthenticated: !!user
  };
  
  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

/**
 * استخدام سياق المصادقة
 * @returns {object} - قيمة سياق المصادقة
 */
export const useAuth = () => {
  const context = useContext(AuthContext);
  
  if (!context) {
    throw new Error('useAuth يجب استخدامه داخل AuthProvider');
  }
  
  return context;
};

export default AuthContext;

