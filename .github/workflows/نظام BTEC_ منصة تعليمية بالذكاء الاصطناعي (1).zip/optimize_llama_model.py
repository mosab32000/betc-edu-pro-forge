#!/usr/bin/env python3
"""
سكربت لتحسين أداء نموذج Llama 3 المحلي

يقوم هذا السكربت بتحسين أداء نموذج Llama 3 المحلي من خلال تقليص حجم النموذج
وتكوين المعلمات المثلى للاستدلال.

كيفية الاستخدام:
1. قم بتشغيل السكربت: python optimize_llama_model.py
"""

import os
import sys
import json
import subprocess
import time
import psutil
import argparse
from pathlib import Path

def print_header(title):
    """طباعة عنوان منسق"""
    print("\n" + "=" * 80)
    print(f" {title} ".center(80, "="))
    print("=" * 80 + "\n")

def check_requirements():
    """التحقق من وجود المتطلبات"""
    print_header("التحقق من المتطلبات")
    
    requirements = {
        "llama-cpp-python": False,
        "torch": False,
        "numpy": False,
        "psutil": False
    }
    
    try:
        import llama_cpp
        requirements["llama-cpp-python"] = True
        print("✓ تم العثور على مكتبة llama-cpp-python")
    except ImportError:
        print("✗ لم يتم العثور على مكتبة llama-cpp-python")
    
    try:
        import torch
        requirements["torch"] = True
        print(f"✓ تم العثور على مكتبة torch (الإصدار: {torch.__version__})")
        
        # التحقق من وجود GPU
        if torch.cuda.is_available():
            print(f"✓ تم العثور على GPU: {torch.cuda.get_device_name(0)}")
            print(f"  - عدد وحدات GPU: {torch.cuda.device_count()}")
            print(f"  - ذاكرة GPU المتاحة: {torch.cuda.get_device_properties(0).total_memory / (1024**3):.2f} GB")
        else:
            print("✗ لم يتم العثور على GPU")
    except ImportError:
        print("✗ لم يتم العثور على مكتبة torch")
    
    try:
        import numpy
        requirements["numpy"] = True
        print(f"✓ تم العثور على مكتبة numpy (الإصدار: {numpy.__version__})")
    except ImportError:
        print("✗ لم يتم العثور على مكتبة numpy")
    
    try:
        import psutil
        requirements["psutil"] = True
        print(f"✓ تم العثور على مكتبة psutil (الإصدار: {psutil.__version__})")
    except ImportError:
        print("✗ لم يتم العثور على مكتبة psutil")
    
    # التحقق من ذاكرة النظام
    mem = psutil.virtual_memory()
    print(f"ذاكرة النظام: {mem.total / (1024**3):.2f} GB")
    
    return all(requirements.values())

def find_model_file():
    """البحث عن ملف النموذج"""
    print_header("البحث عن ملف النموذج")
    
    # المسارات المحتملة للنموذج
    potential_paths = [
        "/home/ubuntu/eduverse_btec_api/models",
        "/home/ubuntu/models",
        "/home/ubuntu/eduverse_btec_api/src/ai/models",
        "/home/ubuntu/eduverse_btec_api/src/models"
    ]
    
    # امتدادات ملفات النموذج
    model_extensions = [".gguf", ".ggml", ".bin"]
    
    # البحث عن ملفات النموذج
    model_files = []
    
    for path in potential_paths:
        if os.path.exists(path):
            for root, dirs, files in os.walk(path):
                for file in files:
                    if any(file.endswith(ext) for ext in model_extensions):
                        model_files.append(os.path.join(root, file))
    
    if model_files:
        print(f"تم العثور على {len(model_files)} ملف نموذج:")
        for i, model_file in enumerate(model_files, 1):
            print(f"{i}. {model_file} ({os.path.getsize(model_file) / (1024**3):.2f} GB)")
        
        # إذا تم العثور على ملف واحد فقط، قم بإرجاعه
        if len(model_files) == 1:
            return model_files[0]
        
        # اطلب من المستخدم اختيار ملف النموذج
        while True:
            try:
                choice = int(input("\nاختر رقم ملف النموذج: "))
                if 1 <= choice <= len(model_files):
                    return model_files[choice - 1]
                else:
                    print("اختيار غير صالح. يرجى إدخال رقم صحيح.")
            except ValueError:
                print("اختيار غير صالح. يرجى إدخال رقم صحيح.")
    else:
        print("لم يتم العثور على أي ملف نموذج.")
        
        # اطلب من المستخدم إدخال مسار ملف النموذج
        model_path = input("\nأدخل المسار الكامل لملف النموذج: ")
        if os.path.exists(model_path):
            return model_path
        else:
            print(f"الملف غير موجود: {model_path}")
            return None

def analyze_model(model_path):
    """تحليل النموذج"""
    print_header("تحليل النموذج")
    
    if not model_path or not os.path.exists(model_path):
        print("مسار النموذج غير صالح.")
        return None
    
    model_size = os.path.getsize(model_path) / (1024**3)  # بالجيجابايت
    model_name = os.path.basename(model_path)
    model_dir = os.path.dirname(model_path)
    
    print(f"اسم النموذج: {model_name}")
    print(f"حجم النموذج: {model_size:.2f} GB")
    print(f"مسار النموذج: {model_path}")
    
    # تحليل نوع النموذج
    if model_name.endswith(".gguf"):
        model_type = "GGUF"
    elif model_name.endswith(".ggml"):
        model_type = "GGML"
    else:
        model_type = "غير معروف"
    
    print(f"نوع النموذج: {model_type}")
    
    # تحليل معلمات النموذج
    model_params = {}
    
    if "7b" in model_name.lower():
        model_params["size"] = "7B"
        model_params["recommended_ram"] = 8
    elif "13b" in model_name.lower():
        model_params["size"] = "13B"
        model_params["recommended_ram"] = 16
    elif "70b" in model_name.lower():
        model_params["size"] = "70B"
        model_params["recommended_ram"] = 64
    else:
        model_params["size"] = "غير معروف"
        model_params["recommended_ram"] = model_size * 2
    
    print(f"حجم المعلمات: {model_params['size']}")
    print(f"الذاكرة الموصى بها: {model_params['recommended_ram']} GB")
    
    # التحقق من كفاية الذاكرة
    mem = psutil.virtual_memory()
    if mem.total / (1024**3) < model_params["recommended_ram"]:
        print(f"⚠️ تحذير: ذاكرة النظام ({mem.total / (1024**3):.2f} GB) أقل من الذاكرة الموصى بها ({model_params['recommended_ram']} GB)")
    
    return {
        "path": model_path,
        "name": model_name,
        "dir": model_dir,
        "size": model_size,
        "type": model_type,
        "params": model_params
    }

def optimize_model_config(model_info):
    """تحسين تكوين النموذج"""
    print_header("تحسين تكوين النموذج")
    
    if not model_info:
        print("معلومات النموذج غير متوفرة.")
        return None
    
    # الحصول على معلومات النظام
    mem = psutil.virtual_memory()
    cpu_count = psutil.cpu_count(logical=False)
    
    # تحديد عدد مسارات المعالجة
    n_threads = min(cpu_count, 8)
    
    # تحديد حجم السياق
    context_size = 2048
    
    # تحديد عدد طبقات GPU
    n_gpu_layers = 0
    
    # التحقق من وجود GPU
    try:
        import torch
        if torch.cuda.is_available():
            gpu_mem = torch.cuda.get_device_properties(0).total_memory / (1024**3)
            print(f"ذاكرة GPU المتاحة: {gpu_mem:.2f} GB")
            
            # تحديد عدد طبقات GPU بناءً على ذاكرة GPU المتاحة
            if gpu_mem >= 24:
                n_gpu_layers = 100  # استخدام جميع الطبقات
            elif gpu_mem >= 16:
                n_gpu_layers = 60
            elif gpu_mem >= 8:
                n_gpu_layers = 40
            elif gpu_mem >= 4:
                n_gpu_layers = 20
            else:
                n_gpu_layers = 0
    except (ImportError, AttributeError):
        pass
    
    # تكوين النموذج
    config = {
        "model_path": model_info["path"],
        "n_ctx": context_size,
        "n_threads": n_threads,
        "n_gpu_layers": n_gpu_layers,
        "use_mlock": True,
        "use_mmap": True,
        "embedding": False,
        "last_n_tokens_size": 64,
        "verbose": False
    }
    
    print("تكوين النموذج المحسن:")
    print(f"- مسار النموذج: {config['model_path']}")
    print(f"- حجم السياق: {config['n_ctx']}")
    print(f"- عدد مسارات المعالجة: {config['n_threads']}")
    print(f"- عدد طبقات GPU: {config['n_gpu_layers']}")
    
    # حفظ التكوين في ملف
    config_dir = os.path.dirname(model_info["path"])
    config_path = os.path.join(config_dir, "llama_config.json")
    
    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)
    
    print(f"\nتم حفظ التكوين في: {config_path}")
    
    return config

def test_model_performance(config):
    """اختبار أداء النموذج"""
    print_header("اختبار أداء النموذج")
    
    if not config:
        print("تكوين النموذج غير متوفر.")
        return None
    
    try:
        from llama_cpp import Llama
        
        print("تحميل النموذج...")
        start_time = time.time()
        
        llm = Llama(
            model_path=config["model_path"],
            n_ctx=config["n_ctx"],
            n_threads=config["n_threads"],
            n_gpu_layers=config["n_gpu_layers"],
            use_mlock=config["use_mlock"],
            use_mmap=config["use_mmap"],
            embedding=config["embedding"],
            last_n_tokens_size=config["last_n_tokens_size"],
            verbose=config["verbose"]
        )
        
        load_time = time.time() - start_time
        print(f"تم تحميل النموذج في {load_time:.2f} ثانية")
        
        # اختبار الاستدلال
        print("\nاختبار الاستدلال...")
        
        prompts = [
            "ما هي أهمية التعليم في تطوير المجتمع؟",
            "اشرح مفهوم الذكاء الاصطناعي بطريقة مبسطة.",
            "ما هي فوائد استخدام التكنولوجيا في التعليم؟"
        ]
        
        results = []
        
        for i, prompt in enumerate(prompts, 1):
            print(f"\nاختبار {i}: {prompt}")
            
            start_time = time.time()
            output = llm(
                prompt,
                max_tokens=100,
                temperature=0.7,
                top_p=0.95,
                repeat_penalty=1.1,
                top_k=40
            )
            inference_time = time.time() - start_time
            
            print(f"وقت الاستدلال: {inference_time:.2f} ثانية")
            print(f"الناتج: {output['choices'][0]['text'][:100]}...")
            
            results.append({
                "prompt": prompt,
                "inference_time": inference_time,
                "tokens_per_second": 100 / inference_time
            })
        
        # حساب متوسط الأداء
        avg_inference_time = sum(r["inference_time"] for r in results) / len(results)
        avg_tokens_per_second = sum(r["tokens_per_second"] for r in results) / len(results)
        
        print("\nملخص الأداء:")
        print(f"متوسط وقت الاستدلال: {avg_inference_time:.2f} ثانية")
        print(f"متوسط الرموز في الثانية: {avg_tokens_per_second:.2f}")
        
        return {
            "load_time": load_time,
            "avg_inference_time": avg_inference_time,
            "avg_tokens_per_second": avg_tokens_per_second,
            "results": results
        }
    
    except Exception as e:
        print(f"حدث خطأ أثناء اختبار النموذج: {e}")
        return None

def create_service_config(model_info, config):
    """إنشاء ملف تكوين الخدمة"""
    print_header("إنشاء ملف تكوين الخدمة")
    
    if not model_info or not config:
        print("معلومات النموذج أو التكوين غير متوفرة.")
        return None
    
    # إنشاء مسار الخدمة
    service_dir = os.path.join(os.path.dirname(model_info["path"]), "service")
    os.makedirs(service_dir, exist_ok=True)
    
    # إنشاء ملف app.py
    app_content = """from flask import Flask, request, jsonify
from llama_cpp import Llama
import os
import json
import time

app = Flask(__name__)

# تحميل تكوين النموذج
with open("llama_config.json", "r") as f:
    config = json.load(f)

# تحميل النموذج
llm = Llama(
    model_path=config["model_path"],
    n_ctx=config["n_ctx"],
    n_threads=config["n_threads"],
    n_gpu_layers=config["n_gpu_layers"],
    use_mlock=config["use_mlock"],
    use_mmap=config["use_mmap"],
    embedding=config["embedding"],
    last_n_tokens_size=config["last_n_tokens_size"],
    verbose=config["verbose"]
)

@app.route("/health", methods=["GET"])
def health():
    """فحص صحة الخدمة"""
    return jsonify({"status": "ok"})

@app.route("/generate", methods=["POST"])
def generate():
    """توليد نص باستخدام النموذج"""
    data = request.json
    
    if not data or "prompt" not in data:
        return jsonify({"error": "يجب توفير المطالبة (prompt)"}), 400
    
    prompt = data["prompt"]
    max_tokens = data.get("max_tokens", 100)
    temperature = data.get("temperature", 0.7)
    top_p = data.get("top_p", 0.95)
    repeat_penalty = data.get("repeat_penalty", 1.1)
    top_k = data.get("top_k", 40)
    
    start_time = time.time()
    
    output = llm(
        prompt,
        max_tokens=max_tokens,
        temperature=temperature,
        top_p=top_p,
        repeat_penalty=repeat_penalty,
        top_k=top_k
    )
    
    inference_time = time.time() - start_time
    
    return jsonify({
        "text": output["choices"][0]["text"],
        "inference_time": inference_time,
        "tokens": len(output["choices"][0]["text"].split())
    })

@app.route("/embedding", methods=["POST"])
def embedding():
    """الحصول على تضمين النص"""
    data = request.json
    
    if not data or "text" not in data:
        return jsonify({"error": "يجب توفير النص (text)"}), 400
    
    text = data["text"]
    
    if not config["embedding"]:
        return jsonify({"error": "التضمين غير مفعل في تكوين النموذج"}), 400
    
    start_time = time.time()
    
    embedding = llm.embed(text)
    
    inference_time = time.time() - start_time
    
    return jsonify({
        "embedding": embedding.tolist(),
        "inference_time": inference_time
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
"""
    
    app_path = os.path.join(service_dir, "app.py")
    with open(app_path, "w") as f:
        f.write(app_content)
    
    # إنشاء ملف Dockerfile
    dockerfile_content = """FROM python:3.11-slim

WORKDIR /app

# تثبيت المتطلبات
RUN apt-get update && apt-get install -y \\
    build-essential \\
    cmake \\
    && rm -rf /var/lib/apt/lists/*

# نسخ ملفات التطبيق
COPY app.py .
COPY requirements.txt .

# نسخ ملف تكوين النموذج
COPY ../llama_config.json .

# نسخ ملف النموذج
COPY ../{model_name} .

# تثبيت المتطلبات
RUN pip install --no-cache-dir -r requirements.txt

# تشغيل التطبيق
CMD ["python", "app.py"]
""".format(model_name=os.path.basename(model_info["path"]))
    
    dockerfile_path = os.path.join(service_dir, "Dockerfile")
    with open(dockerfile_path, "w") as f:
        f.write(dockerfile_content)
    
    # إنشاء ملف requirements.txt
    requirements_content = """flask==2.3.3
llama-cpp-python==0.2.11
gunicorn==21.2.0
"""
    
    requirements_path = os.path.join(service_dir, "requirements.txt")
    with open(requirements_path, "w") as f:
        f.write(requirements_content)
    
    # إنشاء ملف docker-compose.yml
    docker_compose_content = """version: '3.8'

services:
  llama-service:
    build: .
    ports:
      - "5000:5000"
    volumes:
      - ./:/app
    deploy:
      resources:
        limits:
          cpus: '4'
          memory: 16G
"""
    
    docker_compose_path = os.path.join(service_dir, "docker-compose.yml")
    with open(docker_compose_path, "w") as f:
        f.write(docker_compose_content)
    
    print(f"تم إنشاء ملفات تكوين الخدمة في: {service_dir}")
    print(f"- {app_path}")
    print(f"- {dockerfile_path}")
    print(f"- {requirements_path}")
    print(f"- {docker_compose_path}")
    
    return service_dir

def main():
    """الدالة الرئيسية"""
    print_header("تحسين أداء نموذج Llama 3 المحلي")
    
    # التحقق من المتطلبات
    if not check_requirements():
        print("يرجى تثبيت المتطلبات المفقودة قبل المتابعة.")
        return
    
    # البحث عن ملف النموذج
    model_path = find_model_file()
    if not model_path:
        print("لم يتم العثور على ملف النموذج. يرجى تحديد مسار النموذج يدويًا.")
        return
    
    # تحليل النموذج
    model_info = analyze_model(model_path)
    if not model_info:
        print("فشل تحليل النموذج.")
        return
    
    # تحسين تكوين النموذج
    config = optimize_model_config(model_info)
    if not config:
        print("فشل تحسين تكوين النموذج.")
        return
    
    # اختبار أداء النموذج
    performance = test_model_performance(config)
    if not performance:
        print("فشل اختبار أداء النموذج.")
    
    # إنشاء ملف تكوين الخدمة
    service_dir = create_service_config(model_info, config)
    if not service_dir:
        print("فشل إنشاء ملف تكوين الخدمة.")
    
    print_header("ملخص التحسينات")
    print(f"1. تم تحليل النموذج: {model_info['name']} ({model_info['size']} GB)")
    print(f"2. تم تحسين تكوين النموذج: {config['n_threads']} مسار معالجة، {config['n_gpu_layers']} طبقة GPU")
    
    if performance:
        print(f"3. تم اختبار أداء النموذج: {performance['avg_tokens_per_second']:.2f} رمز في الثانية")
    
    if service_dir:
        print(f"4. تم إنشاء ملف تكوين الخدمة: {service_dir}")
    
    print("\nتم تحسين أداء نموذج Llama 3 المحلي بنجاح.")

if __name__ == "__main__":
    main()

