"""
نموذج تجارب التعلم الغامرة (XR) في منصة EduverseAI - قلعة BTEC
"""
from datetime import datetime
from bson import ObjectId

class XRExperience:
    """
    نموذج تجربة التعلم الغامرة في المنصة
    """
    def __init__(self, title, description, type_xr, subject, thumbnail_url, 
                 content_url=None, requirements=None, created_by=None, 
                 created_at=None, updated_at=None, _id=None):
        """
        تهيئة كائن تجربة التعلم الغامرة
        
        المعلمات:
            title (str): عنوان التجربة
            description (str): وصف التجربة
            type_xr (str): نوع التجربة (ar, vr, mr)
            subject (str): المادة الدراسية المرتبطة بالتجربة
            thumbnail_url (str): مسار الصورة المصغرة للتجربة
            content_url (str): مسار محتوى التجربة
            requirements (dict): متطلبات تشغيل التجربة
            created_by (ObjectId): معرف المستخدم الذي أنشأ التجربة
            created_at (datetime): تاريخ إنشاء التجربة
            updated_at (datetime): تاريخ آخر تحديث للتجربة
            _id (ObjectId): معرف التجربة في قاعدة البيانات
        """
        self._id = _id if _id else ObjectId()
        self.title = title
        self.description = description
        self.type_xr = type_xr
        self.subject = subject
        self.thumbnail_url = thumbnail_url
        self.content_url = content_url
        self.requirements = requirements if requirements else {}
        self.created_by = created_by
        self.created_at = created_at if created_at else datetime.utcnow()
        self.updated_at = updated_at if updated_at else datetime.utcnow()
        
        # بيانات إضافية للتجربة
        self.difficulty = "medium"  # مستوى صعوبة التجربة (easy, medium, hard)
        self.duration = 15  # مدة التجربة بالدقائق
        self.tags = []  # وسوم التجربة
        self.jordanian_theme = ""  # الموضوع الأردني المرتبط بالتجربة
        self.interactions = []  # التفاعلات المتاحة في التجربة
        self.learning_objectives = []  # أهداف التعلم
        
    def to_dict(self):
        """
        تحويل كائن التجربة إلى قاموس
        
        العائد:
            dict: قاموس يمثل التجربة
        """
        return {
            "_id": str(self._id),
            "title": self.title,
            "description": self.description,
            "type_xr": self.type_xr,
            "subject": self.subject,
            "thumbnail_url": self.thumbnail_url,
            "content_url": self.content_url,
            "requirements": self.requirements,
            "created_by": str(self.created_by) if self.created_by else None,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "difficulty": self.difficulty,
            "duration": self.duration,
            "tags": self.tags,
            "jordanian_theme": self.jordanian_theme,
            "interactions": self.interactions,
            "learning_objectives": self.learning_objectives
        }
    
    @classmethod
    def from_dict(cls, data):
        """
        إنشاء كائن تجربة من قاموس
        
        المعلمات:
            data (dict): قاموس يحتوي على بيانات التجربة
            
        العائد:
            XRExperience: كائن التجربة
        """
        _id = ObjectId(data["_id"]) if "_id" in data else None
        created_by = ObjectId(data["created_by"]) if "created_by" in data and data["created_by"] else None
        created_at = datetime.fromisoformat(data["created_at"]) if "created_at" in data else None
        updated_at = datetime.fromisoformat(data["updated_at"]) if "updated_at" in data else None
        
        experience = cls(
            title=data.get("title"),
            description=data.get("description"),
            type_xr=data.get("type_xr"),
            subject=data.get("subject"),
            thumbnail_url=data.get("thumbnail_url"),
            content_url=data.get("content_url"),
            requirements=data.get("requirements", {}),
            created_by=created_by,
            created_at=created_at,
            updated_at=updated_at,
            _id=_id
        )
        
        experience.difficulty = data.get("difficulty", "medium")
        experience.duration = data.get("duration", 15)
        experience.tags = data.get("tags", [])
        experience.jordanian_theme = data.get("jordanian_theme", "")
        experience.interactions = data.get("interactions", [])
        experience.learning_objectives = data.get("learning_objectives", [])
        
        return experience


class UserXRExperience:
    """
    نموذج العلاقة بين المستخدم وتجربة التعلم الغامرة
    """
    def __init__(self, user_id, experience_id, status="not_started", progress=0, 
                 started_at=None, completed_at=None, _id=None):
        """
        تهيئة كائن العلاقة بين المستخدم والتجربة
        
        المعلمات:
            user_id (ObjectId): معرف المستخدم
            experience_id (ObjectId): معرف التجربة
            status (str): حالة التجربة (not_started, in_progress, completed)
            progress (int): نسبة التقدم في التجربة
            started_at (datetime): تاريخ بدء التجربة
            completed_at (datetime): تاريخ إكمال التجربة
            _id (ObjectId): معرف العلاقة في قاعدة البيانات
        """
        self._id = _id if _id else ObjectId()
        self.user_id = user_id
        self.experience_id = experience_id
        self.status = status
        self.progress = progress
        self.started_at = started_at
        self.completed_at = completed_at
        
        # بيانات إضافية للعلاقة
        self.time_spent = 0  # الوقت المستغرق في التجربة بالدقائق
        self.interactions_count = 0  # عدد التفاعلات
        self.achievements = []  # الإنجازات المحققة في التجربة
        
    def to_dict(self):
        """
        تحويل كائن العلاقة إلى قاموس
        
        العائد:
            dict: قاموس يمثل العلاقة
        """
        return {
            "_id": str(self._id),
            "user_id": str(self.user_id),
            "experience_id": str(self.experience_id),
            "status": self.status,
            "progress": self.progress,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "time_spent": self.time_spent,
            "interactions_count": self.interactions_count,
            "achievements": self.achievements
        }
    
    @classmethod
    def from_dict(cls, data):
        """
        إنشاء كائن علاقة من قاموس
        
        المعلمات:
            data (dict): قاموس يحتوي على بيانات العلاقة
            
        العائد:
            UserXRExperience: كائن العلاقة
        """
        _id = ObjectId(data["_id"]) if "_id" in data else None
        user_id = ObjectId(data["user_id"]) if "user_id" in data else None
        experience_id = ObjectId(data["experience_id"]) if "experience_id" in data else None
        started_at = datetime.fromisoformat(data["started_at"]) if "started_at" in data and data["started_at"] else None
        completed_at = datetime.fromisoformat(data["completed_at"]) if "completed_at" in data and data["completed_at"] else None
        
        user_experience = cls(
            user_id=user_id,
            experience_id=experience_id,
            status=data.get("status", "not_started"),
            progress=data.get("progress", 0),
            started_at=started_at,
            completed_at=completed_at,
            _id=_id
        )
        
        user_experience.time_spent = data.get("time_spent", 0)
        user_experience.interactions_count = data.get("interactions_count", 0)
        user_experience.achievements = data.get("achievements", [])
        
        return user_experience

