"""
مسارات API لتجارب التعلم الغامرة (XR) في منصة EduverseAI - قلعة BTEC
"""

from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
from ..xr.xr_service import get_xr_service
import logging

# إعداد التسجيل
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# إنشاء Blueprint لتجارب التعلم الغامرة
xr_bp = Blueprint('xr', __name__, url_prefix='/api/xr')

@xr_bp.route('/experiences', methods=['GET'])
@cross_origin()
def get_all_experiences():
    """
    واجهة برمجية للحصول على جميع تجارب التعلم الغامرة
    
    المخرجات:
        - جميع تجارب التعلم الغامرة
    """
    try:
        # الحصول على خدمة تجارب التعلم الغامرة
        xr_service = get_xr_service()
        
        # الحصول على جميع التجارب
        experiences = xr_service.get_all_experiences()
        
        return jsonify(experiences)
    except Exception as e:
        logger.error(f"حدث خطأ أثناء معالجة طلب الحصول على جميع تجارب التعلم الغامرة: {e}")
        return jsonify({
            'error': 'حدث خطأ أثناء معالجة طلبك',
            'details': str(e)
        }), 500

@xr_bp.route('/experiences/<experience_type>', methods=['GET'])
@cross_origin()
def get_experiences_by_type(experience_type):
    """
    واجهة برمجية للحصول على تجارب التعلم الغامرة حسب النوع
    
    المدخلات:
        - experience_type: نوع التجربة (ar, vr, mr)
    
    المخرجات:
        - تجارب التعلم الغامرة من النوع المحدد
    """
    try:
        # التحقق من صحة النوع
        if experience_type not in ['ar', 'vr', 'mr']:
            return jsonify({
                'error': 'نوع التجربة غير صالح. يجب أن يكون ar أو vr أو mr'
            }), 400
        
        # الحصول على خدمة تجارب التعلم الغامرة
        xr_service = get_xr_service()
        
        # الحصول على التجارب حسب النوع
        experiences = xr_service.get_experiences_by_type(experience_type)
        
        return jsonify(experiences)
    except Exception as e:
        logger.error(f"حدث خطأ أثناء معالجة طلب الحصول على تجارب التعلم الغامرة حسب النوع: {e}")
        return jsonify({
            'error': 'حدث خطأ أثناء معالجة طلبك',
            'details': str(e)
        }), 500

@xr_bp.route('/experience/<experience_id>', methods=['GET'])
@cross_origin()
def get_experience_by_id(experience_id):
    """
    واجهة برمجية للحصول على تجربة تعلم غامرة حسب المعرف
    
    المدخلات:
        - experience_id: معرف التجربة
    
    المخرجات:
        - تجربة التعلم الغامرة
    """
    try:
        # الحصول على خدمة تجارب التعلم الغامرة
        xr_service = get_xr_service()
        
        # الحصول على التجربة حسب المعرف
        experience = xr_service.get_experience_by_id(experience_id)
        
        if experience is None:
            return jsonify({
                'error': f'لم يتم العثور على تجربة بالمعرف: {experience_id}'
            }), 404
        
        return jsonify(experience)
    except Exception as e:
        logger.error(f"حدث خطأ أثناء معالجة طلب الحصول على تجربة التعلم الغامرة حسب المعرف: {e}")
        return jsonify({
            'error': 'حدث خطأ أثناء معالجة طلبك',
            'details': str(e)
        }), 500

@xr_bp.route('/experience', methods=['POST'])
@cross_origin()
def add_experience():
    """
    واجهة برمجية لإضافة تجربة تعلم غامرة جديدة
    
    المدخلات:
        - بيانات التجربة
    
    المخرجات:
        - بيانات التجربة المضافة
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'error': 'يجب توفير بيانات التجربة'
            }), 400
        
        # الحصول على خدمة تجارب التعلم الغامرة
        xr_service = get_xr_service()
        
        # إضافة التجربة
        experience = xr_service.add_experience(data)
        
        return jsonify(experience), 201
    except ValueError as e:
        logger.error(f"حدث خطأ في التحقق من صحة البيانات أثناء معالجة طلب إضافة تجربة التعلم الغامرة: {e}")
        return jsonify({
            'error': str(e)
        }), 400
    except Exception as e:
        logger.error(f"حدث خطأ أثناء معالجة طلب إضافة تجربة التعلم الغامرة: {e}")
        return jsonify({
            'error': 'حدث خطأ أثناء معالجة طلبك',
            'details': str(e)
        }), 500

@xr_bp.route('/experience/<experience_id>', methods=['PUT'])
@cross_origin()
def update_experience(experience_id):
    """
    واجهة برمجية لتحديث تجربة تعلم غامرة
    
    المدخلات:
        - experience_id: معرف التجربة
        - بيانات التجربة المحدثة
    
    المخرجات:
        - بيانات التجربة المحدثة
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'error': 'يجب توفير بيانات التجربة المحدثة'
            }), 400
        
        # الحصول على خدمة تجارب التعلم الغامرة
        xr_service = get_xr_service()
        
        # تحديث التجربة
        experience = xr_service.update_experience(experience_id, data)
        
        if experience is None:
            return jsonify({
                'error': f'لم يتم العثور على تجربة بالمعرف: {experience_id}'
            }), 404
        
        return jsonify(experience)
    except Exception as e:
        logger.error(f"حدث خطأ أثناء معالجة طلب تحديث تجربة التعلم الغامرة: {e}")
        return jsonify({
            'error': 'حدث خطأ أثناء معالجة طلبك',
            'details': str(e)
        }), 500

@xr_bp.route('/experience/<experience_id>', methods=['DELETE'])
@cross_origin()
def delete_experience(experience_id):
    """
    واجهة برمجية لحذف تجربة تعلم غامرة
    
    المدخلات:
        - experience_id: معرف التجربة
    
    المخرجات:
        - رسالة نجاح أو فشل
    """
    try:
        # الحصول على خدمة تجارب التعلم الغامرة
        xr_service = get_xr_service()
        
        # حذف التجربة
        success = xr_service.delete_experience(experience_id)
        
        if not success:
            return jsonify({
                'error': f'لم يتم العثور على تجربة بالمعرف: {experience_id}'
            }), 404
        
        return jsonify({
            'message': f'تم حذف التجربة بنجاح: {experience_id}'
        })
    except Exception as e:
        logger.error(f"حدث خطأ أثناء معالجة طلب حذف تجربة التعلم الغامرة: {e}")
        return jsonify({
            'error': 'حدث خطأ أثناء معالجة طلبك',
            'details': str(e)
        }), 500

@xr_bp.route('/user-progress/<user_id>', methods=['GET'])
@cross_origin()
def get_user_progress(user_id):
    """
    واجهة برمجية للحصول على تقدم المستخدم
    
    المدخلات:
        - user_id: معرف المستخدم
    
    المخرجات:
        - تقدم المستخدم
    """
    try:
        # الحصول على خدمة تجارب التعلم الغامرة
        xr_service = get_xr_service()
        
        # الحصول على تقدم المستخدم
        progress = xr_service.get_user_progress(user_id)
        
        return jsonify(progress)
    except Exception as e:
        logger.error(f"حدث خطأ أثناء معالجة طلب الحصول على تقدم المستخدم: {e}")
        return jsonify({
            'error': 'حدث خطأ أثناء معالجة طلبك',
            'details': str(e)
        }), 500

@xr_bp.route('/user-progress/<user_id>/<experience_id>', methods=['POST'])
@cross_origin()
def update_user_progress(user_id, experience_id):
    """
    واجهة برمجية لتحديث تقدم المستخدم
    
    المدخلات:
        - user_id: معرف المستخدم
        - experience_id: معرف التجربة
        - بيانات التقدم
    
    المخرجات:
        - تقدم المستخدم المحدث
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'error': 'يجب توفير بيانات التقدم'
            }), 400
        
        # الحصول على خدمة تجارب التعلم الغامرة
        xr_service = get_xr_service()
        
        # تحديث تقدم المستخدم
        progress = xr_service.update_user_progress(user_id, experience_id, data)
        
        return jsonify(progress)
    except Exception as e:
        logger.error(f"حدث خطأ أثناء معالجة طلب تحديث تقدم المستخدم: {e}")
        return jsonify({
            'error': 'حدث خطأ أثناء معالجة طلبك',
            'details': str(e)
        }), 500

@xr_bp.route('/recommended/<user_id>', methods=['GET'])
@cross_origin()
def get_recommended_experiences(user_id):
    """
    واجهة برمجية للحصول على تجارب التعلم الغامرة الموصى بها للمستخدم
    
    المدخلات:
        - user_id: معرف المستخدم
        - limit: الحد الأقصى لعدد التجارب الموصى بها (اختياري)
    
    المخرجات:
        - قائمة بتجارب التعلم الغامرة الموصى بها
    """
    try:
        # الحصول على الحد الأقصى لعدد التجارب الموصى بها
        limit = request.args.get('limit', default=5, type=int)
        
        # الحصول على خدمة تجارب التعلم الغامرة
        xr_service = get_xr_service()
        
        # الحصول على التجارب الموصى بها
        experiences = xr_service.get_recommended_experiences(user_id, limit)
        
        return jsonify(experiences)
    except Exception as e:
        logger.error(f"حدث خطأ أثناء معالجة طلب الحصول على تجارب التعلم الغامرة الموصى بها: {e}")
        return jsonify({
            'error': 'حدث خطأ أثناء معالجة طلبك',
            'details': str(e)
        }), 500

@xr_bp.route('/content/<experience_id>', methods=['GET'])
@cross_origin()
def get_experience_content(experience_id):
    """
    واجهة برمجية للحصول على محتوى تجربة التعلم الغامرة
    
    المدخلات:
        - experience_id: معرف التجربة
    
    المخرجات:
        - محتوى التجربة
    """
    try:
        # الحصول على خدمة تجارب التعلم الغامرة
        xr_service = get_xr_service()
        
        # الحصول على محتوى التجربة
        content = xr_service.get_experience_content(experience_id)
        
        return jsonify(content)
    except ValueError as e:
        logger.error(f"حدث خطأ في التحقق من صحة البيانات أثناء معالجة طلب الحصول على محتوى تجربة التعلم الغامرة: {e}")
        return jsonify({
            'error': str(e)
        }), 404
    except Exception as e:
        logger.error(f"حدث خطأ أثناء معالجة طلب الحصول على محتوى تجربة التعلم الغامرة: {e}")
        return jsonify({
            'error': 'حدث خطأ أثناء معالجة طلبك',
            'details': str(e)
        }), 500

