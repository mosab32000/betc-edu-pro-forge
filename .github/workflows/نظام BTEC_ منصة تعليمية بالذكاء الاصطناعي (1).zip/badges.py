"""
مسارات API للأوسمة والإنجازات في منصة EduverseAI - قلعة BTEC
"""
from flask import Blueprint, request, jsonify
from bson import ObjectId, errors as bson_errors
from datetime import datetime
from src.models import db, Badge, UserBadge, blockchain_manager
from src.routes.users import token_required

# إنشاء Blueprint للأوسمة
badges_bp = Blueprint('badges', __name__)

@badges_bp.route('/badges', methods=['POST'])
@token_required
def create_badge():
    """
    إنشاء وسام جديد
    """
    # التحقق من صلاحيات المستخدم
    if request.current_user['role'] not in ['admin', 'teacher']:
        return jsonify({'message': 'غير مصرح لك بإنشاء أوسمة!'}), 403
    
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    if not data or not data.get('name') or not data.get('description') or not data.get('image_url') or not data.get('category'):
        return jsonify({'message': 'البيانات غير مكتملة!'}), 400
    
    # التحقق من عدم وجود وسام بنفس الاسم
    if db.badges.find_one({'name': data['name']}):
        return jsonify({'message': 'يوجد وسام بنفس الاسم بالفعل!'}), 400
    
    # إنشاء كائن الوسام
    badge = Badge(
        name=data['name'],
        description=data['description'],
        image_url=data['image_url'],
        category=data['category'],
        requirements=data.get('requirements', {}),
        points=data.get('points', 0)
    )
    
    # إضافة البيانات الإضافية
    if 'rarity' in data:
        badge.rarity = data['rarity']
    if 'is_hidden' in data:
        badge.is_hidden = data['is_hidden']
    if 'jordanian_theme' in data:
        badge.jordanian_theme = data['jordanian_theme']
    
    # حفظ الوسام في قاعدة البيانات
    db.badges.insert_one(badge.to_dict())
    
    return jsonify({
        'message': 'تم إنشاء الوسام بنجاح!',
        'badge': badge.to_dict()
    }), 201

@badges_bp.route('/badges', methods=['GET'])
@token_required
def get_badges():
    """
    الحصول على قائمة الأوسمة
    """
    # الحصول على معلمات البحث والترتيب والتصفح
    search = request.args.get('search', '')
    category = request.args.get('category', '')
    rarity = request.args.get('rarity', '')
    sort_by = request.args.get('sort_by', 'name')
    sort_order = int(request.args.get('sort_order', '1'))
    page = int(request.args.get('page', '1'))
    limit = int(request.args.get('limit', '10'))
    
    # بناء استعلام البحث
    query = {}
    if search:
        query['$or'] = [
            {'name': {'$regex': search, '$options': 'i'}},
            {'description': {'$regex': search, '$options': 'i'}},
            {'jordanian_theme': {'$regex': search, '$options': 'i'}}
        ]
    if category:
        query['category'] = category
    if rarity:
        query['rarity'] = rarity
    
    # للطلاب، إخفاء الأوسمة المخفية
    if request.current_user['role'] == 'student':
        query['is_hidden'] = False
    
    # حساب عدد الأوسمة
    total = db.badges.count_documents(query)
    
    # الحصول على الأوسمة مع التصفح والترتيب
    badges_cursor = db.badges.find(query).sort(sort_by, sort_order).skip((page - 1) * limit).limit(limit)
    
    # تحويل النتائج إلى قائمة
    badges = []
    for badge_data in badges_cursor:
        # تحويل ObjectId إلى سلسلة
        badge_data['_id'] = str(badge_data['_id'])
        badges.append(badge_data)
    
    return jsonify({
        'message': 'تم الحصول على قائمة الأوسمة بنجاح!',
        'total': total,
        'page': page,
        'limit': limit,
        'pages': (total + limit - 1) // limit,
        'badges': badges
    }), 200

@badges_bp.route('/badges/<badge_id>', methods=['GET'])
@token_required
def get_badge(badge_id):
    """
    الحصول على معلومات وسام محدد
    """
    try:
        # البحث عن الوسام
        badge_data = db.badges.find_one({'_id': ObjectId(badge_id)})
        if not badge_data:
            return jsonify({'message': 'الوسام غير موجود!'}), 404
        
        # التحقق من صلاحيات المستخدم للأوسمة المخفية
        if badge_data.get('is_hidden', False) and request.current_user['role'] == 'student':
            return jsonify({'message': 'غير مصرح لك بالوصول إلى هذا الوسام!'}), 403
        
        # تحويل ObjectId إلى سلسلة
        badge_data['_id'] = str(badge_data['_id'])
        
        return jsonify({
            'message': 'تم الحصول على معلومات الوسام بنجاح!',
            'badge': badge_data
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف الوسام غير صالح!'}), 400

@badges_bp.route('/badges/<badge_id>', methods=['PUT'])
@token_required
def update_badge(badge_id):
    """
    تحديث وسام محدد
    """
    # التحقق من صلاحيات المستخدم
    if request.current_user['role'] not in ['admin', 'teacher']:
        return jsonify({'message': 'غير مصرح لك بتحديث الأوسمة!'}), 403
    
    try:
        # البحث عن الوسام
        badge_data = db.badges.find_one({'_id': ObjectId(badge_id)})
        if not badge_data:
            return jsonify({'message': 'الوسام غير موجود!'}), 404
        
        data = request.get_json()
        if not data:
            return jsonify({'message': 'لا توجد بيانات للتحديث!'}), 400
        
        # تحديد البيانات القابلة للتحديث
        update_data = {}
        allowed_fields = [
            'name', 'description', 'image_url', 'category', 'requirements',
            'points', 'rarity', 'is_hidden', 'jordanian_theme'
        ]
        
        for field in allowed_fields:
            if field in data:
                update_data[field] = data[field]
        
        # التحقق من عدم وجود وسام آخر بنفس الاسم
        if 'name' in update_data and update_data['name'] != badge_data['name']:
            existing_badge = db.badges.find_one({'name': update_data['name']})
            if existing_badge:
                return jsonify({'message': 'يوجد وسام آخر بنفس الاسم!'}), 400
        
        # تحديث تاريخ التحديث
        update_data['updated_at'] = datetime.utcnow()
        
        # تحديث الوسام في قاعدة البيانات
        if update_data:
            db.badges.update_one({'_id': ObjectId(badge_id)}, {'$set': update_data})
        
        # الحصول على بيانات الوسام المحدثة
        updated_badge = db.badges.find_one({'_id': ObjectId(badge_id)})
        
        # تحويل ObjectId إلى سلسلة
        updated_badge['_id'] = str(updated_badge['_id'])
        
        return jsonify({
            'message': 'تم تحديث الوسام بنجاح!',
            'badge': updated_badge
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف الوسام غير صالح!'}), 400

@badges_bp.route('/badges/<badge_id>', methods=['DELETE'])
@token_required
def delete_badge(badge_id):
    """
    حذف وسام محدد
    """
    # التحقق من صلاحيات المستخدم
    if request.current_user['role'] != 'admin':
        return jsonify({'message': 'غير مصرح لك بحذف الأوسمة!'}), 403
    
    try:
        # البحث عن الوسام
        badge_data = db.badges.find_one({'_id': ObjectId(badge_id)})
        if not badge_data:
            return jsonify({'message': 'الوسام غير موجود!'}), 404
        
        # حذف علاقات المستخدمين بالوسام
        db.user_badges.delete_many({'badge_id': ObjectId(badge_id)})
        
        # حذف الوسام
        db.badges.delete_one({'_id': ObjectId(badge_id)})
        
        return jsonify({
            'message': 'تم حذف الوسام بنجاح!'
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف الوسام غير صالح!'}), 400

@badges_bp.route('/badges/categories', methods=['GET'])
@token_required
def get_badge_categories():
    """
    الحصول على قائمة فئات الأوسمة
    """
    # الحصول على قائمة الفئات الفريدة
    categories = db.badges.distinct('category')
    
    return jsonify({
        'message': 'تم الحصول على قائمة فئات الأوسمة بنجاح!',
        'categories': categories
    }), 200

@badges_bp.route('/badges/rarities', methods=['GET'])
@token_required
def get_badge_rarities():
    """
    الحصول على قائمة ندرة الأوسمة
    """
    # الحصول على قائمة الندرة الفريدة
    rarities = db.badges.distinct('rarity')
    
    return jsonify({
        'message': 'تم الحصول على قائمة ندرة الأوسمة بنجاح!',
        'rarities': rarities
    }), 200

@badges_bp.route('/user-badges', methods=['POST'])
@token_required
def award_badge():
    """
    منح وسام لمستخدم
    """
    # التحقق من صلاحيات المستخدم
    if request.current_user['role'] not in ['admin', 'teacher']:
        return jsonify({'message': 'غير مصرح لك بمنح الأوسمة!'}), 403
    
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    if not data or not data.get('user_id') or not data.get('badge_id'):
        return jsonify({'message': 'البيانات غير مكتملة!'}), 400
    
    try:
        user_id = ObjectId(data['user_id'])
        badge_id = ObjectId(data['badge_id'])
        
        # التحقق من وجود المستخدم
        user = db.users.find_one({'_id': user_id})
        if not user:
            return jsonify({'message': 'المستخدم غير موجود!'}), 404
        
        # التحقق من وجود الوسام
        badge = db.badges.find_one({'_id': badge_id})
        if not badge:
            return jsonify({'message': 'الوسام غير موجود!'}), 404
        
        # التحقق من عدم وجود علاقة سابقة
        existing_user_badge = db.user_badges.find_one({
            'user_id': user_id,
            'badge_id': badge_id
        })
        
        if existing_user_badge:
            return jsonify({'message': 'المستخدم حاصل على هذا الوسام بالفعل!'}), 400
        
        # إنشاء كائن العلاقة
        user_badge = UserBadge(
            user_id=user_id,
            badge_id=badge_id
        )
        
        # إضافة البيانات الإضافية
        if 'progress' in data:
            user_badge.progress = data['progress']
        
        # حفظ العلاقة في قاعدة البيانات
        user_badge_dict = user_badge.to_dict()
        db.user_badges.insert_one(user_badge_dict)
        
        # تسجيل الوسام في البلوكتشين إذا تم طلبه
        if data.get('use_blockchain', False):
            blockchain_result = blockchain_manager.record_badge(user_badge_dict)
            
            if blockchain_result['success']:
                db.user_badges.update_one(
                    {'_id': user_badge_dict['_id']},
                    {'$set': {'blockchain_verification': blockchain_result['verification']}}
                )
                user_badge_dict['blockchain_verification'] = blockchain_result['verification']
        
        # تحديث نقاط المستخدم
        db.users.update_one(
            {'_id': user_id},
            {'$inc': {'points': badge['points']}}
        )
        
        # تحويل ObjectId إلى سلسلة
        user_badge_dict['_id'] = str(user_badge_dict['_id'])
        user_badge_dict['user_id'] = str(user_badge_dict['user_id'])
        user_badge_dict['badge_id'] = str(user_badge_dict['badge_id'])
        
        return jsonify({
            'message': 'تم منح الوسام للمستخدم بنجاح!',
            'user_badge': user_badge_dict
        }), 201
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف المستخدم أو الوسام غير صالح!'}), 400

@badges_bp.route('/user-badges/<user_badge_id>', methods=['GET'])
@token_required
def get_user_badge(user_badge_id):
    """
    الحصول على معلومات علاقة مستخدم بوسام محددة
    """
    try:
        # البحث عن العلاقة
        user_badge_data = db.user_badges.find_one({'_id': ObjectId(user_badge_id)})
        if not user_badge_data:
            return jsonify({'message': 'العلاقة غير موجودة!'}), 404
        
        # التحقق من صلاحيات المستخدم
        current_user = request.current_user
        if current_user['role'] == 'student' and str(user_badge_data['user_id']) != str(current_user['_id']):
            return jsonify({'message': 'غير مصرح لك بالوصول إلى هذه العلاقة!'}), 403
        
        # الحصول على معلومات الوسام
        badge_data = db.badges.find_one({'_id': user_badge_data['badge_id']})
        if badge_data:
            badge_data['_id'] = str(badge_data['_id'])
        
        # الحصول على معلومات المستخدم
        user_data = db.users.find_one({'_id': user_badge_data['user_id']})
        if user_data:
            user_info = {
                '_id': str(user_data['_id']),
                'username': user_data['username'],
                'first_name': user_data.get('first_name', ''),
                'last_name': user_data.get('last_name', '')
            }
        else:
            user_info = None
        
        # تحويل ObjectId إلى سلسلة
        user_badge_data['_id'] = str(user_badge_data['_id'])
        user_badge_data['user_id'] = str(user_badge_data['user_id'])
        user_badge_data['badge_id'] = str(user_badge_data['badge_id'])
        
        return jsonify({
            'message': 'تم الحصول على معلومات العلاقة بنجاح!',
            'user_badge': user_badge_data,
            'badge': badge_data,
            'user': user_info
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف العلاقة غير صالح!'}), 400

@badges_bp.route('/user-badges/<user_badge_id>/verify', methods=['GET'])
@token_required
def verify_user_badge(user_badge_id):
    """
    التحقق من صحة علاقة مستخدم بوسام باستخدام البلوكتشين
    """
    try:
        # البحث عن العلاقة
        user_badge_data = db.user_badges.find_one({'_id': ObjectId(user_badge_id)})
        if not user_badge_data:
            return jsonify({'message': 'العلاقة غير موجودة!'}), 404
        
        # التحقق من وجود معلومات التحقق من البلوكتشين
        if 'blockchain_verification' not in user_badge_data or not user_badge_data['blockchain_verification']:
            return jsonify({
                'message': 'لا توجد معلومات تحقق من البلوكتشين لهذه العلاقة!',
                'verified': False
            }), 200
        
        # التحقق من صحة العلاقة باستخدام البلوكتشين
        block_hash = user_badge_data['blockchain_verification'].get('block_hash')
        if not block_hash:
            return jsonify({
                'message': 'معلومات التحقق من البلوكتشين غير مكتملة!',
                'verified': False
            }), 200
        
        verification_result = blockchain_manager.verify_data(
            {
                'user_badge_id': str(user_badge_data['_id']),
                'user_id': str(user_badge_data['user_id']),
                'badge_id': str(user_badge_data['badge_id'])
            },
            block_hash
        )
        
        return jsonify({
            'message': verification_result['message'],
            'verified': verification_result['verified'],
            'block': verification_result['block'],
            'user_badge_id': user_badge_id
        }), 200
    except bson_errors.InvalidId:
        return jsonify({'message': 'معرف العلاقة غير صالح!'}), 400

